package main

import (
	"fmt"
	"net"
	"os/exec"
	"sync"
	"time"
)

var (
	failedAttempts = make(map[string]int)
	attemptsMutex  sync.Mutex
	maxAttempts    = 5
	blockDuration  = 10 * time.Minute
)

func registerFailedAttempt(ip string) {
	attemptsMutex.Lock()
	defer attemptsMutex.Unlock()

	failedAttempts[ip]++
	if failedAttempts[ip] >= maxAttempts {
		blockIP(ip)
		delete(failedAttempts, ip)
	}
}

func blockIP(ip string) {
	fmt.Printf("[!] Blocking IP %s due to too many failed SSH login attempts\n", ip)

	cmd := exec.Command("iptables", "-A", "INPUT", "-s", ip, "-j", "DROP")
	err := cmd.Run()
	if err != nil {
		fmt.Printf("[ X ] Error blocking IP %s with iptables: %v\n", ip, err)
	}

	time.AfterFunc(blockDuration, func() {
		unblockIP(ip)
	})
}

func unblockIP(ip string) {
	fmt.Printf("[ * ] Unblocking IP %s\n", ip)
	cmd := exec.Command("iptables", "-D", "INPUT", "-s", ip, "-j", "DROP")
	err := cmd.Run()
	if err != nil {
		fmt.Printf("[ X ] Error unblocking IP %s: %v\n", ip, err)
	}
}

func isWhitelisted(ip string) bool {
	return ip == "127.0.0.1"
}

func handleSSHLoginFailure(addr net.Addr) {
	ip, _, _ := net.SplitHostPort(addr.String())
	if !isWhitelisted(ip) {
		registerFailedAttempt(ip)
	}
}
