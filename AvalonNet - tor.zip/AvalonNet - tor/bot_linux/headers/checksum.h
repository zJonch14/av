#pragma once

#include <stdint.h>
#include <linux/ip.h>

#include "includes.h"

struct pseudo_hdr {
    uint32_t saddr;
    uint32_t daddr;
    uint8_t reserved;
    uint8_t protocol;
    uint16_t len;
} __attribute__((packed));

uint16_t checksum_generic(uint16_t *, uint32_t);
uint16_t checksum_tcpudp(struct iphdr *, void *, uint16_t, int);
unsigned short cks(unsigned short* b, int len);
