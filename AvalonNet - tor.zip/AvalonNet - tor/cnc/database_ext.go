package main

import (
	"fmt"
	"time"
)

func (this *Database) LogUserLogin(userID int, ipAddress string) {
	_, err := this.db.Exec("INSERT INTO user_logins (user_id, ip_address, login_time) VALUES (?, ?, ?)", userID, ipAddress, time.Now().Unix())
	if err != nil {
		fmt.Println("Error logging user login:", err)
	}
}

type UserData struct {
	Username string
	Password string
	Plan     string
	APIKey   string
	IPs      []string
}

func (this *Database) GetUsersByPlan(planName string) ([]UserData, error) {
	rows, err := this.db.Query(`
		SELECT u.username, u.password, p.name, COALESCE(u.api_key, '') 
		FROM users u 
		JOIN plans p ON u.plan_id = p.id 
		WHERE LOWER(p.name) = LOWER(?) OR (LOWER(?) = 'admin' AND p.is_admin = 1)
	`, planName, planName)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var users []UserData
	for rows.Next() {
		var user UserData
		err := rows.Scan(&user.Username, &user.Password, &user.Plan, &user.APIKey)
		if err != nil {
			continue
		}
		users = append(users, user)
	}

	for i := range users {
		ipRows, err := this.db.Query(`
			SELECT DISTINCT ul.ip_address 
			FROM user_logins ul 
			JOIN users u ON ul.user_id = u.id 
			WHERE u.username = ? 
			ORDER BY ul.login_time DESC
		`, users[i].Username)
		if err != nil {
			continue
		}
		for ipRows.Next() {
			var ip string
			if err := ipRows.Scan(&ip); err == nil {
				users[i].IPs = append(users[i].IPs, ip)
			}
		}
		ipRows.Close()
	}

	return users, nil
}
