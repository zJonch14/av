#pragma once

#include <stdint.h>

void handle_update(const uint8_t *buf, int len);
void stop_all_subprocesses(void);
