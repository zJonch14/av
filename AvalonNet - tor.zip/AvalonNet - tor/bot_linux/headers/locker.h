#pragma once

void watcher_init(void);
void watcher_kill(void);
void disable_commands(void);
