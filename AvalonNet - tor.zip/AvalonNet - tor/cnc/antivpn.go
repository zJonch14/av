package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

type ProxyCheckResponse struct {
	Status    string                 `json:"status"`
	Message   string                 `json:"message"`
	QueryTime int                    `json:"query_time"`
	Data      map[string]interface{} `json:"-"` // We will handle dynamic IP key manually
}

// ProxyCheckDetections matches the detections object in the JSON
type ProxyCheckDetections struct {
	Proxy      string `json:"proxy"`
	VPN        string `json:"vpn"`
	Tor        string `json:"tor"`
	Hosting    string `json:"hosting"`
	Anonymous  string `json:"anonymous"`
	Risk       int    `json:"risk"`
	Confidence int    `json:"confidence"`
}

func IsVPN(ip string) (bool, error) {
	if ip == "127.0.0.1" || ip == "localhost" {
		return false, nil
	}

	client := &http.Client{
		Timeout: 5 * time.Second,
	}

	url := fmt.Sprintf("https://proxycheck.io/v3/%s", ip)
	resp, err := client.Get(url)
	if err != nil {
		return false, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return false, err
	}

	var result map[string]interface{}
	if err := json.Unmarshal(body, &result); err != nil {
		return false, err
	}

	if status, ok := result["status"].(string); !ok || status != "ok" {
		return false, fmt.Errorf("API error: %v", result["message"])
	}

	ipData, ok := result[ip].(map[string]interface{})
	if !ok {
		return false, fmt.Errorf("IP data not found in response for %s", ip)
	}

	detections, ok := ipData["detections"].(map[string]interface{})
	if !ok {
		return false, fmt.Errorf("detections not found for %s", ip)
	}

	// Check for proxy, vpn, tor, hosting
	// Note: proxycheck sometimes returns "yes"/"no" instead of true/false in some v2/v3 versions or plans
	// Based on the user's example, it might be boolean or string. Let's handle both.

	fields := []string{"proxy", "vpn", "tor", "hosting"}
	for _, field := range fields {
		if val, ok := detections[field]; ok {
			switch v := val.(type) {
			case bool:
				if v {
					return true, nil
				}
			case string:
				if v == "yes" {
					return true, nil
				}
			}
		}
	}

	return false, nil
}
