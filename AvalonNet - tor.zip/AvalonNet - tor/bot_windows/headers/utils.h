#pragma once
#include "includes.h"

uint32_t util_local_addr(void);
void get_bot_id(char *buf);
void util_persistence(void);
void util_single_instance(void);
void util_cleanup(char *path);
BOOL util_is_admin(void);
void util_elevate(void);


void util_memset(void *dst, uint8_t val, uint32_t len);

void util_memcpy(void *dst, const void *src, uint32_t len);
int util_strlen(const char *str);
void util_strcpy(char *dst, const char *src);
void util_strncpy(char *dst, const char *src, uint32_t len);
int util_strcmp(const char *str1, const char *str2);
int util_atoi(const char *str);
char *util_strstr(const char *haystack, const char *needle);
char *util_strchr(const char *str, int c);
char *util_strtok(char *str, const char *delim);
