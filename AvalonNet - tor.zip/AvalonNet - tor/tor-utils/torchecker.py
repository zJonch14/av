import socket
import struct
import sys
import concurrent.futures

DEST_ADDR = "duckduckgogg42xjoc72x3sjasowoarfbgcmvfimaftt6twagswzczad.onion"
DEST_PORT = 443

def check_proxy(proxy_str):
    proxy_str = proxy_str.strip()
    if not proxy_str:
        return None

    if ":" in proxy_str:
        proxy_ip, proxy_port = proxy_str.split(":")
        proxy_port = int(proxy_port)
    else:
        proxy_ip = proxy_str
        proxy_port = 9050

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5)
        
        s.connect((proxy_ip, proxy_port))

        s.sendall(b"\x05\x01\x00")
        resp = s.recv(2)
        if resp != b"\x05\x00":
            return f"[-] {proxy_ip}:{proxy_port} -> No soporta SOCKS5 sin auth"

        addr_bytes = DEST_ADDR.encode()
        payload = b"\x05\x01\x00\x03" + bytes([len(addr_bytes)]) + addr_bytes + struct.pack(">H", DEST_PORT)
        s.sendall(payload)
        
        conn_resp = s.recv(10)
        if conn_resp[1] == 0:
            return f"{proxy_ip}:{proxy_port} -> FUNCIONA (Onion OK)"
        else:
            return f"[!] {proxy_ip}:{proxy_port} -> Proxy activo pero fallo Onion (Error: {conn_resp[1]})"

    except Exception as e:
        return f"[-] {proxy_ip}:{proxy_port} -> Down ({str(e)})"
    finally:
        s.close()

def main():
    if len(sys.argv) < 2:
        print("Uso: python3 torchecker.py <archivo_proxies.txt>")
        sys.exit(1)

    filename = sys.argv[1]
    try:
        with open(filename, "r") as f:
            proxies = f.readlines()
    except FileNotFoundError:
        print(f"Error: Archivo {filename} no encontrado")
        sys.exit(1)

    print(f"[*] Iniciando escaneo de {len(proxies)} proxies...")
    print(f"[*] Destino de prueba: {DEST_ADDR}")
    print("-" * 50)

    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        results = list(executor.map(check_proxy, proxies))

    working = []
    for res in results:
        if res:
            print(res)
            if "FUNCIONA" in res:
                working.append(res.split("->")[0].strip())

    print("-" * 50)
    print(f"[*] Escaneo completado. Funcionan: {len(working)}/{len(proxies)}")
    
    if working:
        with open("out.txt", "w") as f:
            for p in working:
                f.write(p + "\n")
        print("[*] Proxies activos guardados en out.txt")

main()