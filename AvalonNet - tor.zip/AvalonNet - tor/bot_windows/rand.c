#include "headers/includes.h"
#include "headers/rand.h"

static uint32_t seed;

void rand_init(void) {
    seed = (uint32_t)time(NULL);
}

uint32_t rand_next(void) {
    seed ^= seed << 13;
    seed ^= seed >> 17;
    seed ^= seed << 5;
    return seed;
}

void rand_str(char *str, int len) {
    while (len > 0) {
        if (len >= 4) {
            *((uint32_t *)str) = rand_next();
            str += 4;
            len -= 4;
        } else {
            *str++ = rand_next() & 0xFF;
            len--;
        }
    }
}
