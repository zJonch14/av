package main

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"os"

	"golang.org/x/crypto/ssh"
)

func getHostKey() (ssh.Signer, error) {
	keyPath := "host_key.pem"
	keyBytes, err := os.ReadFile(keyPath)
	if err != nil {
		key, err := rsa.GenerateKey(rand.Reader, 2048)
		if err != nil {
			return nil, err
		}

		keyBytes = pem.EncodeToMemory(&pem.Block{
			Type:  "RSA PRIVATE KEY",
			Bytes: x509.MarshalPKCS1PrivateKey(key),
		})

		err = os.WriteFile(keyPath, keyBytes, 0600)
		if err != nil {
			return nil, err
		}
	}

	return ssh.ParsePrivateKey(keyBytes)
}
