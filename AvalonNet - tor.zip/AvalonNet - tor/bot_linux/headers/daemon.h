#pragma once

void daemonize(int argc, char **argv, char *original_path);
void set_name(const char *name);
void gen_name(char *out, int len);
void hide_process_name(int argc, char **argv);
