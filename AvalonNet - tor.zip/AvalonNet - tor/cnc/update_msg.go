package main

type UpdateMessage struct {
	IP     string
	Prefix string
	Dir    string
}

func (m *UpdateMessage) Build() []byte {
	// Structure:
	// Type (1 byte): 0x05 (MSG_TYPE_UPDATE)
	// IP Len (1 byte)
	// IP (string)
	// Prefix Len (1 byte)
	// Prefix (string)
	// Dir Len (1 byte)
	// Dir (string)

	buf := make([]byte, 1)
	buf[0] = 0x05

	buf = append(buf, byte(len(m.IP)))
	buf = append(buf, []byte(m.IP)...)

	buf = append(buf, byte(len(m.Prefix)))
	buf = append(buf, []byte(m.Prefix)...)

	buf = append(buf, byte(len(m.Dir)))
	buf = append(buf, []byte(m.Dir)...)

	return buf
}
