package main

import (
	"fmt"
)

func (this *Database) BanUserAPI(username string) error {
	result, err := this.db.Exec("UPDATE users SET max_bots = 0 WHERE username = ? AND is_admin = 0", username)
	if err != nil {
		return err
	}
	rows, _ := result.RowsAffected()
	if rows == 0 {
		return fmt.Errorf("User not found or is admin")
	}
	return nil
}

func (this *Database) UnbanUserAPI(username string, maxBots int) error {
	_, err := this.db.Exec("UPDATE users SET max_bots = ? WHERE username = ?", maxBots, username)
	return err
}
