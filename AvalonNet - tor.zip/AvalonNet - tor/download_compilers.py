import os
import tarfile
import urllib.request
import time
import shutil
from urllib.error import URLError, HTTPError

FILES = [
    "arc_gnu_2017.09_prebuilt_uclibc_le_arc700_linux_install.tar.gz",
    "cross-compiler-armv4l.tar.bz2",
    "cross-compiler-armv5l.tar.bz2",
    "cross-compiler-armv6l.tar.bz2",
    "cross-compiler-armv7l.tar.bz2",
    "cross-compiler-i486.tar.gz",
    "cross-compiler-i586.tar.bz2",
    "cross-compiler-i686.tar.bz2",
    "cross-compiler-m68k.tar.bz2",
    "cross-compiler-mips.tar.bz2",
    "cross-compiler-mipsel.tar.bz2",
    "cross-compiler-powerpc-440fp.tar.bz2",
    "cross-compiler-powerpc.tar.bz2",
    "cross-compiler-sh4.tar.bz2",
    "cross-compiler-sparc.tar.bz2",
    "cross-compiler-x86_64.tar.bz2"
]

BASE_URL = "http://mirailovers.io/HELL-ARCHIVE/COMPILERS/"
DOWNLOAD_DIR = "compilers"
EXTRACT_DIR = "/etc/xcompile"

os.makedirs(DOWNLOAD_DIR, exist_ok=True)
os.makedirs(EXTRACT_DIR, exist_ok=True)

def get_arch_name(filename):
    if filename.startswith("arc_gnu"):
        return "arc"
    
    name = filename.replace("cross-compiler-", "")
    name = name.replace(".tar.gz", "").replace(".tar.bz2", "")
    return name

def download_file(filename, max_retries=6):
    url = BASE_URL + filename
    output_path = os.path.join(DOWNLOAD_DIR, filename)
    
    if os.path.exists(output_path) and os.path.getsize(output_path) > 1_000_000:
        print(f"[ + ] Ya existe y esta completo: {filename}")
        return output_path
    
    print(f"[ i ] Descargando: {filename}")
    
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.9,es;q=0.8",
        "Accept-Encoding": "gzip, deflate",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Cache-Control": "max-age=0"
    }
    
    req = urllib.request.Request(url, headers=headers)
    
    for intento in range(1, max_retries + 1):
        try:
            with urllib.request.urlopen(req, timeout=40) as response:
                content_type = response.headers.get('Content-Type', '')
                content_length = int(response.headers.get('Content-Length', 0))
                
                if 'text/html' in content_type and content_length < 100_000:
                    print(f"[ ! ] Posible pagina de error HTML recibida")
                    if os.path.exists(output_path):
                        os.remove(output_path)
                    time.sleep(10)
                    continue
                
                downloaded = 0
                chunk_size = 1024 * 1024  # 1 MB
                
                with open(output_path, 'wb') as f:
                    while True:
                        chunk = response.read(chunk_size)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)
                        
                        if content_length > 0:
                            percent = (downloaded / content_length) * 100
                            print(f"\r    Progreso: {percent:.1f}% ({downloaded // (1024*1024)} MB)", end="", flush=True)
                
                print()
                final_size = os.path.getsize(output_path)
                
                if final_size > 1_000_000:
                    print(f"[ ✓ ] Descargado correctamente ({final_size // (1024*1024)} MB): {filename}")
                    return output_path
                else:
                    print(f"[ ! ] Archivo muy pequeño ({final_size} bytes). Posible error.")
                    if os.path.exists(output_path):
                        os.remove(output_path)
                        
        except HTTPError as e:
            print(f"[ ! ] Error HTTP {e.code}: {e.reason}")
        except URLError as e:
            print(f"[ ! ] Error de conexion: {e.reason}")
        except Exception as e:
            print(f"[ ! ] Error: {e}")
        
        print(f"    Reintentando {intento}/{max_retries} en 5 segundos...")
        time.sleep(5)
    
    print(f"[ X ] Fallo despues de {max_retries} intentos: {filename}")
    return None

def extract_file(file_path):
    file_name = os.path.basename(file_path)
    arch_name = get_arch_name(file_name)
    extract_path = os.path.join(EXTRACT_DIR, arch_name)
    
    if os.path.exists(extract_path) and os.listdir(extract_path):
        print(f"[ + ] Ya extraido: {arch_name}")
        return
    
    print(f"[ i ] Extraindo: {file_name} -> {arch_name}")
    
    temp_extract = os.path.join(EXTRACT_DIR, f"temp_{arch_name}_extract")
    if os.path.exists(temp_extract):
        shutil.rmtree(temp_extract)
    os.makedirs(temp_extract, exist_ok=True)
    
    try:
        mode = "r:gz" if file_name.endswith(".tar.gz") else "r:bz2"
        
        with tarfile.open(file_path, mode) as tar:
            tar.extractall(path=temp_extract)
        
        items = os.listdir(temp_extract)
        source_path = temp_extract
        
        if len(items) == 1:
            single_item = os.path.join(temp_extract, items[0])
            if os.path.isdir(single_item):
                source_path = single_item
        
        if os.path.exists(extract_path):
            shutil.rmtree(extract_path)
        
        shutil.move(source_path, extract_path)
        
        if os.path.exists(temp_extract):
            shutil.rmtree(temp_extract)
        
        print(f"[ ✓ ] Extraido en: {extract_path}")
        
    except Exception as e:
        print(f"[ ! ] Error al extraer {file_name}: {e}")
        if os.path.exists(temp_extract):
            shutil.rmtree(temp_extract)

def main():
    print(f"[ i ] Iniciando descarga de {len(FILES)} cross compilers")
    print(f"[ i ] Destino: {EXTRACT_DIR}\n")
    
    if not os.access('/etc', os.W_OK):
        print("[ ! ] usa: sudo python3 download_compilers.py\n")
    
    for filename in FILES:
        path = download_file(filename)
        if path:
            extract_file(path)
        print()

main()