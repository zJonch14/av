package main

import (
	"encoding/binary"
	"errors"
)

func rotl32(v uint32, c uint) uint32 {
	return (v << c) | (v >> (32 - c))
}

func quarterRound(x []uint32, a, b, c, d int) {
	x[a] = x[a] + x[b]; x[d] ^= x[a]; x[d] = rotl32(x[d], 16)
	x[c] = x[c] + x[d]; x[b] ^= x[c]; x[b] = rotl32(x[b], 12)
	x[a] = x[a] + x[b]; x[d] ^= x[a]; x[d] = rotl32(x[d], 8)
	x[c] = x[c] + x[d]; x[b] ^= x[c]; x[b] = rotl32(x[b], 7)
}

func chacha20Block(key []byte, nonce []byte, counter uint32) ([]byte, error) {
	if len(key) != 32 {
		return nil, errors.New("key must be 32 bytes")
	}
	if len(nonce) != 12 {
		return nil, errors.New("nonce must be 12 bytes")
	}

	constants := []uint32{0x61707865, 0x3320646e, 0x79622d32, 0x6b206574}
	state := make([]uint32, 16)
	copy(state[:4], constants)

	for i := 0; i < 8; i++ {
		state[4+i] = binary.LittleEndian.Uint32(key[i*4 : (i+1)*4])
	}
	state[12] = counter
	for i := 0; i < 3; i++ {
		state[13+i] = binary.LittleEndian.Uint32(nonce[i*4 : (i+1)*4])
	}

	workingState := make([]uint32, 16)
	copy(workingState, state)

	for i := 0; i < 10; i++ {
		quarterRound(workingState, 0, 4, 8, 12)
		quarterRound(workingState, 1, 5, 9, 13)
		quarterRound(workingState, 2, 6, 10, 14)
		quarterRound(workingState, 3, 7, 11, 15)
		quarterRound(workingState, 0, 5, 10, 15)
		quarterRound(workingState, 1, 6, 11, 12)
		quarterRound(workingState, 2, 7, 8, 13)
		quarterRound(workingState, 3, 4, 9, 14)
	}

	out := make([]byte, 64)
	for i := 0; i < 16; i++ {
		val := workingState[i] + state[i]
		binary.LittleEndian.PutUint32(out[i*4:], val)
	}
	return out, nil
}

func ChaCha20Encrypt(data []byte, key []byte, nonce []byte) ([]byte, error) {
	if len(key) != 32 {
		newKey := make([]byte, 32)
		copy(newKey, key)
		key = newKey
	}
	if len(nonce) != 12 {
		return nil, errors.New("Nonce must be 12 bytes")
	}

	encrypted := make([]byte, 0, len(data))
	counter := uint32(0)

	for i := 0; i < len(data); i += 64 {
		keystream, err := chacha20Block(key, nonce, counter)
		if err != nil {
			return nil, err
		}
		counter++

		blockLen := 64
		if len(data)-i < 64 {
			blockLen = len(data) - i
		}

		block := data[i : i+blockLen]
		encBlock := make([]byte, blockLen)
		for j := 0; j < blockLen; j++ {
			encBlock[j] = block[j] ^ keystream[j]
		}
		encrypted = append(encrypted, encBlock...)
	}

	return encrypted, nil
}
