#pragma once

#include <stdint.h>
#include <string.h>

#define CHACHA20_KEY_SIZE 32
#define CHACHA20_NONCE_SIZE 12
#define CHACHA20_BLOCK_SIZE 64

#define ROTL(a, b) (((a) << (b)) | ((a) >> (32 - (b))))

static void chacha20_quarterround(uint32_t *a, uint32_t *b, uint32_t *c, uint32_t *d) {
    *a += *b; *d ^= *a; *d = ROTL(*d, 16);
    *c += *d; *b ^= *c; *b = ROTL(*b, 12);
    *a += *b; *d ^= *a; *d = ROTL(*d, 8);
    *c += *d; *b ^= *c; *b = ROTL(*b, 7);
}

static uint32_t load32_le(const uint8_t *src) {
    return (uint32_t)src[0] | ((uint32_t)src[1] << 8) | ((uint32_t)src[2] << 16) | ((uint32_t)src[3] << 24);
}

static void store32_le(uint8_t *dst, uint32_t val) {
    dst[0] = (uint8_t)(val & 0xff);
    dst[1] = (uint8_t)((val >> 8) & 0xff);
    dst[2] = (uint8_t)((val >> 16) & 0xff);
    dst[3] = (uint8_t)((val >> 24) & 0xff);
}

static void chacha20_init(uint32_t state[16], const uint8_t key[32], const uint8_t nonce[12], uint32_t counter) {
    state[0] = 0x61707865; state[1] = 0x3320646e; state[2] = 0x79622d32; state[3] = 0x6b206574;
    state[4] = load32_le(key + 0);  state[5] = load32_le(key + 4);
    state[6] = load32_le(key + 8);  state[7] = load32_le(key + 12);
    state[8] = load32_le(key + 16); state[9] = load32_le(key + 20);
    state[10] = load32_le(key + 24); state[11] = load32_le(key + 28);
    state[12] = counter;
    state[13] = load32_le(nonce + 0); state[14] = load32_le(nonce + 4); state[15] = load32_le(nonce + 8);
}

static void chacha20_block(uint32_t out[16], const uint32_t in[16]) {
    uint32_t x[16];
    int i;
    for (i = 0; i < 16; i++) x[i] = in[i];
    for (i = 0; i < 10; i++) {
        chacha20_quarterround(&x[0], &x[4], &x[8], &x[12]);
        chacha20_quarterround(&x[1], &x[5], &x[9], &x[13]);
        chacha20_quarterround(&x[2], &x[6], &x[10], &x[14]);
        chacha20_quarterround(&x[3], &x[7], &x[11], &x[15]);
        chacha20_quarterround(&x[0], &x[5], &x[10], &x[15]);
        chacha20_quarterround(&x[1], &x[6], &x[11], &x[12]);
        chacha20_quarterround(&x[2], &x[7], &x[8], &x[13]);
        chacha20_quarterround(&x[3], &x[4], &x[9], &x[14]);
    }
    for (i = 0; i < 16; i++) out[i] = x[i] + in[i];
}

static void chacha20_encrypt(uint8_t *data, size_t data_len, const uint8_t key[32], const uint8_t nonce[12]) {
    uint32_t state[16], block[16];
    uint8_t keystream[64];
    uint32_t counter = 0;
    size_t i, j;
    for (i = 0; i < data_len; i += 64) {
        chacha20_init(state, key, nonce, counter++);
        chacha20_block(block, state);
        for (j = 0; j < 16; j++) store32_le(keystream + (j * 4), block[j]);
        for (j = 0; j < 64 && (i + j) < data_len; j++) data[i + j] ^= keystream[j];
    }
}
#define ENC_KEY "paolo_next_2025"
