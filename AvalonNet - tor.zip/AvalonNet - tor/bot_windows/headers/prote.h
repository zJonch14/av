#pragma once
#include "includes.h"

BOOL detect_vm(void);
