#pragma once

#include "includes.h"

struct attack_option;

int countcpu(void);

int util_strlen(const char *);
BOOL util_strncmp(const char *, const char *, int);
BOOL util_strcmp(const char *, const char *);
int util_strcpy(char *, const char *);
int util_strncpy(char *, const char *, int);
void util_strcat(char *, const char *);
void util_memcpy(void *, const void *, int);
void util_zero(void *, int);
int util_atoi(const char *, int);
char *util_itoa(int, int, char *);
int util_memsearch(const char *, int, const char *, int);
int util_stristr(const char *, int, const char *);
ipv4_t util_local_addr(void);
char *util_fdgets(char *, int, int);
int util_anti_debug(void);
int util_anti_analysis(void);
int util_snprintf(char *str, int size, const char *format, ...);
void get_bot_id(char *buf);

int attack_get_opt_int(uint8_t opts_len, struct attack_option *opts, uint8_t key, int default_val);
char *attack_get_opt_str(uint8_t opts_len, struct attack_option *opts, uint8_t key, char *default_val);

static inline int util_isupper(char c) { return (c >= 'A' && c <= 'Z'); }
static inline int util_isalpha(char c) { return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')); }
static inline int util_isspace(char c) { return (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f' || c == '\v'); }
static inline int util_isdigit(char c) { return (c >= '0' && c <= '9'); }
