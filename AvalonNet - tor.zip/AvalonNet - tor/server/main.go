package main

import (
	"crypto/tls"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"

	ftpserver "github.com/fclairamb/ftpserverlib"
	"github.com/pin/tftp/v3"
	"github.com/spf13/afero"
)

const (
	HTTP_PORT = 80
	FTP_PORT  = 21
	TFTP_PORT = 69
	DIRECTORY = "static"
)

type FTPDriver struct {
	BaseDir string
}

func (d *FTPDriver) GetSettings() (*ftpserver.Settings, error) {
	return &ftpserver.Settings{
		ListenAddr: fmt.Sprintf(":%d", FTP_PORT),
		PassiveTransferPortRange: &ftpserver.PortRange{
			Start: 30000,
			End:   30100,
		},
	}, nil
}

func (d *FTPDriver) GetTLSConfig() (*tls.Config, error) {
	return nil, nil
}

func (d *FTPDriver) ClientConnected(cc ftpserver.ClientContext) (string, error) {
	log.Printf("[ FTP ] Nueva conexión desde: %s", cc.RemoteAddr())
	return "Avalon FTP Server", nil
}

func (d *FTPDriver) ClientDisconnected(cc ftpserver.ClientContext) {
	log.Printf("[ FTP ] Desconectado: %s", cc.RemoteAddr())
}

func (d *FTPDriver) AuthUser(cc ftpserver.ClientContext, user, pass string) (ftpserver.ClientDriver, error) {
	if user == "anonymous" || user == "" {
		return afero.NewReadOnlyFs(afero.NewBasePathFs(afero.NewOsFs(), d.BaseDir)), nil
	}
	return nil, fmt.Errorf("Solo acceso anónimo permitido")
}

type CustomLogger struct {
	handler http.Handler
}

func (l *CustomLogger) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	log.Printf("[ HTTP ] %s %s desde %s", r.Method, r.URL.Path, r.RemoteAddr)
	l.handler.ServeHTTP(w, r)
}

type CustomFileSystem struct {
	fs http.FileSystem
}

func (cfs CustomFileSystem) Open(path string) (http.File, error) {
	f, err := cfs.fs.Open(path)
	if err != nil {
		return nil, err
	}

	s, err := f.Stat()
	if err != nil {
		return nil, err
	}

	if s.IsDir() {
		index := filepath.Join(path, "index.html")
		if _, err := cfs.fs.Open(index); err != nil {
			closeErr := f.Close()
			if closeErr != nil {
				return nil, closeErr
			}
			return nil, os.ErrPermission
		}
	}

	return f, nil
}

func main() {
	absDir, err := filepath.Abs(DIRECTORY)
	if err != nil {
		log.Fatalf("Error de ruta: %v", err)
	}

	if _, err := os.Stat(absDir); os.IsNotExist(err) {
		log.Fatalf("Error: '%s' no existe.", DIRECTORY)
	}

	// HTTP Server
	go func() {
		cfs := CustomFileSystem{fs: http.Dir(absDir)}
		fs := http.FileServer(cfs)
		logger := &CustomLogger{handler: fs}
		fmt.Printf("\033[1;32m[ HTTP ] Servidor activo en puerto %d\033[0m\n", HTTP_PORT)
		if err := http.ListenAndServe(fmt.Sprintf(":%d", HTTP_PORT), logger); err != nil {
			log.Printf("[ HTTP ] Error: %v", err)
		}
	}()

	// TFTP Server
	go func() {
		readHandler := func(filename string, rf io.ReaderFrom) error {
			path := filepath.Join(absDir, filename)
			file, err := os.Open(path)
			if err != nil {
				log.Printf("[ TFTP ] Error al abrir archivo %s: %v", filename, err)
				return err
			}
			defer file.Close()
			_, err = rf.ReadFrom(file)
			if err != nil {
				log.Printf("[ TFTP ] Error transmitiendo %s: %v", filename, err)
			} else {
				log.Printf("[ TFTP ] Transmisión completada: %s", filename)
			}
			return err
		}

		tftpServer := tftp.NewServer(readHandler, nil)
		fmt.Printf("\033[1;33m[ TFTP ] Servidor activo en puerto %d\033[0m\n", TFTP_PORT)
		if err := tftpServer.ListenAndServe(fmt.Sprintf(":%d", TFTP_PORT)); err != nil {
			log.Printf("[ TFTP ] Error: %v", err)
		}
	}()

	// FTP Server
	driver := &FTPDriver{BaseDir: absDir}
	ftpServer := ftpserver.NewFtpServer(driver)

	fmt.Printf("\033[1;36m[ FTP ] Servidor activo en puerto %d\033[0m\n", FTP_PORT)
	if err := ftpServer.ListenAndServe(); err != nil {
		log.Fatalf("[ FTP ] Error crítico: %v", err)
	}
}
