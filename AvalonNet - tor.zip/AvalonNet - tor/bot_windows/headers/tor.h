#pragma once

#include <stdint.h>

#define TOR_MAX_SOCKS 64

struct tor_proxy {
    uint32_t ip;
    uint16_t port;
    int working;
};

void tor_init(void);
struct tor_proxy *tor_get_random(void);
void tor_report_working(struct tor_proxy *proxy, int is_working);
int tor_socks5_handshake(int fd, const char *onion_addr, uint16_t port);
