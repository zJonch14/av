package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"io"
	"os"
)

var logKey []byte

func initLogger() error {
	keyPath := "logs/key.bin"
	logPath := "logs/commands.log"

	if _, err := os.Stat("logs"); os.IsNotExist(err) {
		os.Mkdir("logs", 0755)
	}

	if _, err := os.Stat(keyPath); err == nil {
		key, err := os.ReadFile(keyPath)
		if err != nil {
			return err
		}
		if len(key) != 32 {
			return fmt.Errorf("invalid key size in %s (must be 32 bytes)", keyPath)
		}
		logKey = key
		fmt.Printf("\n\033[1;32m[!] SECURITY: Master key loaded from disk.\033[0m\n")
	} else {
		if _, err := os.Stat(logPath); err == nil {
			fmt.Println("\n\033[1;31m[FATAL ERROR] logs/commands.log exists but logs/key.bin is missing!\033[0m")
			fmt.Println("\033[1;33mPlease place the 32-byte key file in logs/key.bin to decrypt logs.\033[0m")
			return fmt.Errorf("master key missing for existing logs")
		}

		key := make([]byte, 32)
		if _, err := io.ReadFull(rand.Reader, key); err != nil {
			return err
		}
		logKey = key

		// Save key automatically to keyPath
		if err := os.WriteFile(keyPath, key, 0600); err != nil {
			fmt.Printf("\033[1;31m[!] WARNING: Could not save master key to %s: %v\033[0m\n", keyPath, err)
		} else {
			fmt.Printf("\033[1;32m[!] SECURITY: New master key generated and saved to %s\033[0m\n", keyPath)
		}

		encodedKey := base64.StdEncoding.EncodeToString(key)
		fmt.Println("\n\033[1;33m[!!!] FIRST RUN: Generated a new Master Key [!!!]\033[0m")
		fmt.Printf("\033[1;36mBase64 Key:\033[0m %s\n", encodedKey)
		fmt.Println("\033[1;31mIMPORTANT: If you move the CNC, you MUST move logs/key.bin with it!\033[0m")
	}
	return nil
}

func encryptLog(text string) (string, error) {
	block, err := aes.NewCipher(logKey)
	if err != nil {
		return "", err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}

	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}

	ciphertext := gcm.Seal(nonce, nonce, []byte(text), nil)
	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

func decryptLog(cryptoText string) (string, error) {
	data, err := base64.StdEncoding.DecodeString(cryptoText)
	if err != nil {
		return "", err
	}

	block, err := aes.NewCipher(logKey)
	if err != nil {
		return "", err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}

	nonceSize := gcm.NonceSize()
	if len(data) < nonceSize {
		return "", fmt.Errorf("ciphertext too short")
	}

	nonce, ciphertext := data[:nonceSize], data[nonceSize:]
	plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return "", err
	}

	return string(plaintext), nil
}

func WriteLog(message string) {
	encrypted, err := encryptLog(message)
	if err != nil {
		fmt.Printf("[X] Error encrypting log: %v\n", err)
		return
	}

	f, err := os.OpenFile("logs/commands.log", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0600)
	if err != nil {
		fmt.Printf("[X] Error opening log file: %v\n", err)
		return
	}
	defer f.Close()

	if _, err := f.WriteString(encrypted + "\n"); err != nil {
		fmt.Printf("[X] Error writing to log file: %v\n", err)
	}
}
