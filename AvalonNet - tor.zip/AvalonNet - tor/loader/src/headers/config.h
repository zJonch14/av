#pragma once

#define SERVER_IP "151.243.109.99"

#define HTTP_SERVER SERVER_IP
#define HTTP_PORT   80

#define FTP_SERVER  SERVER_IP
#define FTP_PORT    21

#define TFTP_SERVER SERVER_IP
#define TFTP_PORT   69
