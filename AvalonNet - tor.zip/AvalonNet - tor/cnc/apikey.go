package main

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
)

func generateAPIKey() string {
	bytes := make([]byte, 16)
	rand.Read(bytes)
	return hex.EncodeToString(bytes)
}

func (this *Database) GenerateAPIKey(username string) (string, error) {
	apiKey := generateAPIKey()
	_, err := this.db.Exec("UPDATE users SET api_key = ? WHERE username = ?", apiKey, username)
	if err != nil {
		return "", err
	}
	return apiKey, nil
}

func (this *Database) GetAPIKey(username string) (string, error) {
	var apiKey string
	err := this.db.QueryRow("SELECT COALESCE(api_key, '') FROM users WHERE username = ?", username).Scan(&apiKey)
	if err != nil {
		return "", err
	}
	return apiKey, nil
}

func (this *Database) DeleteAPIKey(apiKey string) error {
	result, err := this.db.Exec("UPDATE users SET api_key = NULL WHERE api_key = ?", apiKey)
	if err != nil {
		return err
	}
	rows, _ := result.RowsAffected()
	if rows == 0 {
		return fmt.Errorf("API key not found")
	}
	return nil
}
