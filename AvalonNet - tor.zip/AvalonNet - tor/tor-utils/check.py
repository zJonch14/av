import socket
import struct
import concurrent.futures
import sys
import os

def check_proxy(proxy):
    ip, port = proxy
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(3)
        s.connect((ip, port))
        
        s.sendall(b"\x05\x01\x00")
        resp = s.recv(2)
        if resp == b"\x05\x00":
            s.close()
            return True, ip, port
    except:
        pass
    return False, ip, port

def main():
    if len(sys.argv) < 2:
        print("uso: python3 check.py <file.txt>")
        sys.exit(1)

    proxy_file = sys.argv[1]
    
    if not os.path.exists(proxy_file):
        print(f"El archivo '{proxy_file}' no existe.")
        sys.exit(1)

    proxies = []
    try:
        with open(proxy_file, 'r') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                if ':' in line:
                    parts = line.split(':')
                    if len(parts) == 2:
                        try:
                            ip = parts[0]
                            port = int(parts[1])
                            proxies.append((ip, port))
                        except ValueError:
                            print(f"Saltando línea inválida: {line}")
                else:
                    print(f"Saltando línea con formato erroneo: {line}")
    except Exception as e:
        print(f"Error al leer: {e}")
        sys.exit(1)

    if not proxies:
        print("No se encontraron proxies validos para procesar.")
        sys.exit(1)

    print(f"Escaneando {len(proxies)} proxies desde '{proxy_file}'...")
    working_proxies = []
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        results = list(executor.map(check_proxy, proxies))
        
    for success, ip, port in results:
        if success:
            print(f"Funciona: {ip}:{port}")
            working_proxies.append((ip, port))
        else:
            # print(f"[-] Caído: {ip}:{port}")
            pass
            
    print("-" * 30)
    if not working_proxies:
        print("\nNinguna proxy del archivo esta activa.")
    else:
        print(f"\nSe encontraron {len(working_proxies)} proxyes activos.")
        with open('out.txt', 'w') as out_file:
            for wp in working_proxies:
                proxy_str = f"{wp[0]}:{wp[1]}"
                print(proxy_str)
                out_file.write(proxy_str + '\n')
        print(f"\nproxyes guardadas en out.txt")

main()