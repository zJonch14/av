CREATE DATABASE IF NOT EXISTS botnet;
USE botnet;

CREATE TABLE `plans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL UNIQUE,
  `max_time` int(10) unsigned NOT NULL,
  `cooldown` int(10) unsigned NOT NULL,
  `max_bots` int(11) DEFAULT '-1',
  `is_admin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
);

INSERT INTO plans (name, max_time, cooldown, max_bots, is_admin) VALUES 
('admin', 3600, 0, -1, 1),
('lunar', 600, 15, -1, 0),
('vip', 300, 30, -1, 0),
('user', 120, 60, -1, 0),
('free', 60, 120, 50, 0);

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL UNIQUE,
  `password` varchar(32) NOT NULL,
  `plan_id` int(10) unsigned NOT NULL,
  `expiry` int(10) unsigned NOT NULL,
  `api_key` text,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`plan_id`) REFERENCES `plans`(`id`)
);

INSERT INTO users (username, password, plan_id, expiry) 
VALUES ('admin', 'root', (SELECT id FROM plans WHERE name='admin'), UNIX_TIMESTAMP() + 315360000);

CREATE TABLE `history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `time_sent` int(10) unsigned NOT NULL,
  `duration` int(10) unsigned NOT NULL,
  `command` text NOT NULL,
  `max_bots` int(11) DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
);

CREATE TABLE `whitelist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `prefix` varchar(16) DEFAULT NULL,
  `netmask` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prefix` (`prefix`)
);

CREATE TABLE `user_logins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `login_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ip_address` (`ip_address`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
);
