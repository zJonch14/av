#pragma once

#include "includes.h"

void watchdog_init(void);
void watchdog_kill(void);
