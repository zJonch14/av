#pragma once

#ifdef _WIN32
    #define _WINSOCK_DEPRECATED_NO_WARNINGS
    #define _CRT_SECURE_NO_WARNINGS
    #include <winsock2.h>
    #include <windows.h>
    #include <shellapi.h>
    #include <ws2tcpip.h>
    #define close closesocket
#else
    #include <unistd.h>
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>
    #include <netdb.h>
    #include <sys/select.h>
    #include <sys/time.h>
    #include <fcntl.h>
    #include <errno.h>
#endif

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdint.h>
#include <limits.h>

#ifdef DEBUG
#define PRINTF(...) { printf(__VA_ARGS__); fflush(stdout); }
#else
#define PRINTF(...)
#endif


#ifndef FALSE
#define FALSE   0
#endif
#ifndef TRUE
#define TRUE    1
#endif

#ifndef _WIN32
typedef char BOOL;
#endif

typedef uint32_t ipv4_t;
typedef uint16_t port_t;

#define SINGLE_INSTANCE_PORT 8345

void util_memset(void *dst, uint8_t val, uint32_t len);
void util_memcpy(void *dst, const void *src, uint32_t len);
int util_strlen(const char *str);
void util_strcpy(char *dst, const char *src);
void util_strncpy(char *dst, const char *src, uint32_t len);
int util_strcmp(const char *str1, const char *str2);
int util_atoi(const char *str);
char *util_strstr(const char *haystack, const char *needle);
char *util_strchr(const char *str, int c);
char *util_strtok(char *str, const char *delim);
#define util_zero(buf, len) util_memset(buf, 0, len)

